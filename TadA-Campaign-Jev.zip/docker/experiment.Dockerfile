FROM node:22-bookworm

ARG CODEX_VERSION=latest
ARG CLAUDE_CODE_VERSION=latest
ARG OPENCODE_VERSION=1.14.38

RUN apt-get update && \
    apt-get install -y --no-install-recommends \
      bash \
      ca-certificates \
      curl \
      git \
      iptables \
      jq \
      procps \
      python3 \
      python3-pip \
      python3-venv \
      ripgrep \
      unzip && \
    rm -rf /var/lib/apt/lists/*

ENV UV_INSTALL_DIR="/usr/local/bin"
ENV PATH="/root/.local/bin:/usr/local/bin:${PATH}"
RUN curl -LsSf https://astral.sh/uv/install.sh | sh && \
    command -v uv && \
    uv --version

RUN npm install -g "@openai/codex@${CODEX_VERSION}"
RUN npm install -g "@anthropic-ai/claude-code@${CLAUDE_CODE_VERSION}"
RUN npm install -g "opencode-ai@${OPENCODE_VERSION}"

RUN printf 'set -o pipefail\n' > /etc/profile.d/enable-pipefail.sh

WORKDIR /app
COPY pyproject.toml uv.lock README.md /app/
COPY src/TadACampaign/__init__.py /app/src/TadACampaign/__init__.py
COPY src/TadACampaign/models.py /app/src/TadACampaign/models.py
COPY src/TadACampaign/runner.py /app/src/TadACampaign/runner.py
COPY src/TadACampaign/backends.py /app/src/TadACampaign/backends.py
COPY src/TadACampaign/policies.py /app/src/TadACampaign/policies.py
COPY src/TadACampaign/jev_policy.py /app/src/TadACampaign/jev_policy.py
COPY src/TadACampaign/biology.py /app/src/TadACampaign/biology.py
COPY src/TadACampaign/runtime_entrypoints.py /app/src/TadACampaign/runtime_entrypoints.py
COPY src/TadACampaign/container_firewall.py /app/src/TadACampaign/container_firewall.py
COPY src/TadACampaign/reporting.py /app/src/TadACampaign/reporting.py
COPY src/TadACampaign/telemetry.py /app/src/TadACampaign/telemetry.py
COPY src/TadACampaign/skill_market.py /app/src/TadACampaign/skill_market.py
COPY src/TadACampaign/codex_resume.py /app/src/TadACampaign/codex_resume.py
COPY src/TadACampaign/judge/__init__.py /app/src/TadACampaign/judge/__init__.py
COPY src/TadACampaign/judge/client.py /app/src/TadACampaign/judge/client.py
RUN uv sync

COPY config/experiments /app/config/experiments
COPY docs/agent_playbook.md /app/docs/agent_playbook.md
COPY docs/biology_context.md /app/docs/biology_context.md
COPY scripts /app/scripts

CMD ["bash"]
