# Decision-model benchmark code

This standalone checkout contains the TadACampaign replay environment and
the adapters for Jev-family and liquid/d1 decision models.

## Prepare the data

Use Bash, Python 3.11 or later, and `uv` on Linux.

TadA-Bench is a publicly available dataset. Place the raw dataset archive at
`data/TadABench-1M.zip`, then prepare the benchmark tables:

```bash
uv sync --locked
uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared
```

## Run Jev

Model-backed runs need a running Docker daemon with Linux containers, network
access for the image build and model requests, and your own provider
credential. Use one of the following authentication setups:

- **Vercel AI Gateway.** Set `AI_GATEWAY_API_KEY` in your local environment,
  or set `TADACAMPAIGN_JEV_KEY_FILE` to the path of a Vercel key file stored
  outside the checkout. Set `JEV_BASE_URL=https://ai-gateway.vercel.sh/typesafe`
  in the same environment.
- **TypeSafe API.** Set `TYPESAFE_API_KEY` in your local environment.

Run a short smoke check, then launch the default paper condition:

```bash
bash scripts/run_TadACampaign_v2.sh smoke runs/supplement-smoke
bash scripts/run_TadACampaign_v2.sh formal runs/supplement-formal
```

The smoke preset uses Jev k=1 with a 60-day horizon. The formal preset uses
`reproduce/paper_conditions/jev_k1_default_100k.toml` with a 100k initial budget,
a 180-day horizon, and seed 601. Find the single-run results in
`results/summary.json` under the generated run directory.

To run another paper condition, set `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` to
its TOML path before launching `formal`. Use
`TADACAMPAIGN_SMOKE_CONFIG_OVERRIDE` for a custom smoke configuration.
See [paper-condition templates and seeds](reproduce/paper_conditions/README.md)
for the other settings and the ten replay seeds.
