"""Agent backend contracts."""

from __future__ import annotations

import json
import os
import random
import shlex
import signal
import subprocess
import textwrap
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from textwrap import dedent
from typing import Any

from .codex_resume import (
    CONTEXT_WINDOW_ERROR_MARKERS,
    NON_RETRYABLE_ERROR_MARKERS,
    RETRYABLE_ERROR_MARKERS,
    CodexEventError,
    CodexEventSnapshot,
    classify_failure as classify_codex_failure,
    inspect_event_stream,
    validate_event_stream,
)
from .models import ExperimentConfig
from .policies import make_policy_memory, policy_rng_seed, select_action, update_memory
from .telemetry import append_runtime_event, elapsed_seconds, monotonic_now, utc_now_iso

# Claude Code 后端默认通过 reclaude 调用：reclaude 是本机的 Claude Code 包装器，
# 负责拉起本地代理守护进程、注入 reclaude CA 与网关鉴权，并据此路由 Claude API 流量。
# 允许用环境变量覆盖，便于在已直接安装原生 `claude` 的环境（如容器镜像）中复用同一后端。
DEFAULT_CLAUDE_CLI_BIN = "reclaude"
CLAUDE_CLI_BIN_ENV = "TADACAMPAIGN_CLAUDE_BIN"
DEFAULT_CODEX_AUTO_RESUME_ENABLED = True
DEFAULT_CODEX_AUTO_RESUME_MAX_ATTEMPTS = 0
DEFAULT_CODEX_AUTO_RESUME_BACKOFF_SECONDS = 2.0
DEFAULT_CODEX_CONTEXT_WINDOW_HANDOFF_MAX_COUNT = -1
HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS_ENV = "TADACAMPAIGN_HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS"
HANDOFF_DRILL_MAX_TRIGGERS_ENV = "TADACAMPAIGN_HANDOFF_DRILL_MAX_TRIGGERS"
AGENT_PROMPT_APPEND_ENV = "TADACAMPAIGN_AGENT_PROMPT_APPEND"
HANDOFF_DRILL_META_FILENAME = "handoff_drill_meta.json"
_FINAL_RESULT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "status": {"type": "string", "enum": ["completed"]},
        "stop_reason": {"type": "string"},
        "action_count": {"type": "integer"},
        "summary": {"type": "string"},
    },
    "required": ["status", "stop_reason", "action_count", "summary"],
}
_BACKEND_LABELS = {
    "codex": "Codex",
    "claude": "Claude Code",
    "opencode": "OpenCode",
    "policy": "Policy",
}
CODEX_FINAL_RESULT_SCHEMA_FILENAME = "codex_final_result_schema.json"


class BackendError(RuntimeError):
    """Raised when a backend cannot return a valid decision."""

    def __init__(
        self,
        message: str,
        *,
        thread_id: str | None = None,
        session_id: str | None = None,
        backend: str | None = None,
    ) -> None:
        super().__init__(message)
        effective_session_id = session_id or thread_id
        self.thread_id = effective_session_id
        self.session_id = effective_session_id
        self.backend = backend


@dataclass(frozen=True)
class _HandoffDrillConfig:
    after_accepted_actions: int
    max_triggers: int


@dataclass
class _HandoffDrillState:
    config: _HandoffDrillConfig | None
    triggered_count: int = 0
    trigger_records: list[dict[str, Any]] | None = None

    def __post_init__(self) -> None:
        if self.trigger_records is None:
            self.trigger_records = []


@dataclass(frozen=True)
class _AttemptProcessResult:
    command: list[str]
    returncode: int
    stdout: str
    stderr: str
    error: str | None
    started_at: str
    finished_at: str
    duration_seconds: float


@dataclass(frozen=True)
class _AttemptInvocation:
    backend: str
    mode: str
    prompt: str
    prompt_path: str | None
    resume_session_id: str | None
    target_session_id: str | None
    source_session_id: str | None
    trigger: str | None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class _AttemptSnapshot:
    observed_session_id: str | None
    effective_session_id: str | None
    saw_completion: bool
    error_messages: tuple[str, ...]
    truncated_tail: bool
    provider_snapshot: Any = None


@dataclass(frozen=True)
class _FailureClassification:
    classification: str
    retryable: bool
    continuation_mode: str
    stop_reason: str
    reason_excerpt: str


def _backend_label(backend: str) -> str:
    return _BACKEND_LABELS.get(backend, backend)


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _write_text(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def _write_agent_logs(run_dir: Path, *, backend: str, stdout: str, stderr: str, command: list[str]) -> None:
    results_dir = run_dir / "results"
    _write_text(results_dir / "agent_stdout.log", stdout)
    _write_text(results_dir / "agent_stderr.log", stderr)
    _write_text(results_dir / "agent_command.txt", shlex.join(command) + "\n")

    if backend == "codex":
        _write_text(results_dir / "codex_events.jsonl", stdout)
        _write_text(results_dir / "codex_stderr.log", stderr)
        _write_text(results_dir / "codex_command.txt", shlex.join(command) + "\n")


def _write_final_result(results_dir: Path, *, backend: str, payload: dict[str, Any]) -> Path:
    agent_path = results_dir / "agent_final_result.json"
    _write_json(agent_path, payload)
    if backend == "codex":
        _write_json(results_dir / "codex_final_result.json", payload)
    return agent_path


def _write_codex_final_result_schema(results_dir: Path) -> Path:
    results_dir.mkdir(parents=True, exist_ok=True)
    path = results_dir / CODEX_FINAL_RESULT_SCHEMA_FILENAME
    _write_json(path, _FINAL_RESULT_SCHEMA)
    return path


def _archive_attempt_logs(results_dir: Path, *, backend: str, attempt_index: int) -> Path | None:
    src = results_dir / "agent_stdout.log"
    if not src.is_file():
        return None
    dest = results_dir / f"agent_stdout_attempt{attempt_index}.log"
    if dest.exists():
        dest.unlink()
    src.rename(dest)

    if backend == "codex":
        codex_src = results_dir / "codex_events.jsonl"
        codex_dest = results_dir / f"codex_events_attempt{attempt_index}.jsonl"
        if codex_dest.exists():
            codex_dest.unlink()
        if codex_src.exists():
            codex_src.rename(codex_dest)
    return dest


def _snapshot_attempt_result(results_dir: Path, *, backend: str, attempt_index: int) -> Path | None:
    src = results_dir / "agent_final_result.json"
    if backend == "codex" and not src.is_file():
        fallback_src = results_dir / "codex_final_result.json"
        if fallback_src.is_file():
            dest = results_dir / f"codex_final_result_attempt{attempt_index}.json"
            if dest.exists():
                dest.unlink()
            dest.write_text(fallback_src.read_text(encoding="utf-8"), encoding="utf-8")
            fallback_src.unlink()
            return dest
    if not src.is_file():
        return None
    dest = results_dir / f"agent_final_result_attempt{attempt_index}.json"
    if dest.exists():
        dest.unlink()
    dest.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    src.unlink()

    if backend == "codex":
        codex_src = results_dir / "codex_final_result.json"
        codex_dest = results_dir / f"codex_final_result_attempt{attempt_index}.json"
        if codex_dest.exists():
            codex_dest.unlink()
        if codex_src.exists():
            codex_dest.write_text(codex_src.read_text(encoding="utf-8"), encoding="utf-8")
            codex_src.unlink()
    return dest


def _persist_resume_meta(results_dir: Path, *, backend: str, payload: dict[str, Any]) -> Path:
    agent_path = results_dir / "agent_resume_meta.json"
    _write_json(agent_path, payload)
    if backend == "codex":
        _write_json(results_dir / "codex_resume_meta.json", payload)
    return agent_path


def _write_handoff_prompt(results_dir: Path, *, backend: str, attempt_index: int, prompt: str) -> Path:
    path = results_dir / f"agent_handoff_prompt_attempt{attempt_index}.txt"
    _write_text(path, prompt)
    if backend == "codex":
        codex_path = results_dir / f"codex_handoff_prompt_attempt{attempt_index}.txt"
        _write_text(codex_path, prompt)
        return codex_path
    return path


def _write_handoff_drill_meta(results_dir: Path, payload: dict[str, Any]) -> Path:
    path = results_dir / HANDOFF_DRILL_META_FILENAME
    _write_json(path, payload)
    return path


def _append_backend_event(run_dir: Path, *, backend: str, suffix: str, **payload: Any) -> None:
    append_runtime_event(run_dir, event=f"agent.{suffix}", backend=backend, **payload)
    if backend == "codex":
        append_runtime_event(run_dir, event=f"codex.{suffix}", **payload)


def _load_handoff_drill_config() -> _HandoffDrillConfig | None:
    raw_after_actions = os.environ.get(HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS_ENV)
    if raw_after_actions is None or not raw_after_actions.strip():
        return None
    try:
        after_accepted_actions = int(raw_after_actions)
    except ValueError as exc:
        raise BackendError(
            f"{HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS_ENV} must be a positive integer, got {raw_after_actions!r}"
        ) from exc
    if after_accepted_actions <= 0:
        raise BackendError(
            f"{HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS_ENV} must be a positive integer, got {after_accepted_actions}"
        )

    raw_max_triggers = os.environ.get(HANDOFF_DRILL_MAX_TRIGGERS_ENV, "1")
    try:
        max_triggers = int(raw_max_triggers)
    except ValueError as exc:
        raise BackendError(f"{HANDOFF_DRILL_MAX_TRIGGERS_ENV} must be an integer >= 0, got {raw_max_triggers!r}") from exc
    if max_triggers < 0:
        raise BackendError(f"{HANDOFF_DRILL_MAX_TRIGGERS_ENV} must be >= 0, got {max_triggers}")

    return _HandoffDrillConfig(
        after_accepted_actions=after_accepted_actions,
        max_triggers=max_triggers,
    )


def _accepted_step_snapshot(run_dir: Path) -> tuple[int, int | None]:
    process_dir = run_dir / "process"
    accepted_count = 0
    max_step_index: int | None = None
    for path in sorted(process_dir.glob("step_*/step_meta.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict) or payload.get("accepted") is not True:
            continue
        accepted_count += 1
        raw_step_index = payload.get("step_index")
        if isinstance(raw_step_index, int):
            max_step_index = raw_step_index if max_step_index is None else max(max_step_index, raw_step_index)
    return accepted_count, max_step_index


def _request_process_termination(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        return
    process.terminate()


def _run_handoff_drill_watch(
    *,
    run_dir: Path,
    process: subprocess.Popen[str],
    attempt_index: int,
    backend: str,
    config: _HandoffDrillConfig,
    stop_event: threading.Event,
    outcome: dict[str, Any],
) -> None:
    while not stop_event.is_set():
        accepted_action_count, trigger_step_index = _accepted_step_snapshot(run_dir)
        if accepted_action_count >= config.after_accepted_actions:
            triggered_at = utc_now_iso()
            outcome.update(
                {
                    "triggered": True,
                    "triggered_at": triggered_at,
                    "accepted_action_count": accepted_action_count,
                    "trigger_step_index": trigger_step_index,
                }
            )
            _append_backend_event(
                run_dir,
                backend=backend,
                suffix="handoff_drill.triggered",
                attempt=attempt_index,
                trigger_after_accepted_actions=config.after_accepted_actions,
                accepted_action_count=accepted_action_count,
                trigger_step_index=trigger_step_index,
                triggered_at=triggered_at,
            )
            _request_process_termination(process)
            return
        time.sleep(0.2)


def _terminate_process_tree(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return

    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                return
            process.communicate()
        return

    process.terminate()
    try:
        process.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.communicate()


def _is_completed_result_payload(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    if payload.get("status") != "completed":
        return False
    return "stop_reason" in payload and "action_count" in payload


def _decode_trailing_json_value(text: str) -> Any | None:
    decoder = json.JSONDecoder()
    for start_index, char in enumerate(text):
        if char not in "[{":
            continue
        try:
            value, end_index = decoder.raw_decode(text[start_index:])
        except json.JSONDecodeError:
            continue
        suffix = text[start_index + end_index :].strip()
        if suffix and suffix != "```":
            continue
        return value
    return None


def _find_completed_result_payload(candidate: Any) -> dict[str, Any] | None:
    if _is_completed_result_payload(candidate):
        return dict(candidate)
    if isinstance(candidate, dict):
        values = list(candidate.values())
        for value in reversed(values):
            result = _find_completed_result_payload(value)
            if result is not None:
                return result
        return None
    if isinstance(candidate, list):
        for value in reversed(candidate):
            result = _find_completed_result_payload(value)
            if result is not None:
                return result
        return None
    if isinstance(candidate, str):
        text = candidate.strip()
        if not text:
            return None
        decoded: Any | None = None
        if text[0] in "[{":
            try:
                decoded = json.loads(text)
            except json.JSONDecodeError:
                decoded = None
        if decoded is None:
            decoded = _decode_trailing_json_value(text)
        if decoded is None:
            return None
        return _find_completed_result_payload(decoded)
    return None


def _parse_json_stream(text: str) -> list[Any]:
    payloads: list[Any] = []
    stripped = text.strip()
    if not stripped:
        return payloads
    try:
        payloads.append(json.loads(stripped))
    except json.JSONDecodeError:
        pass
    for line in text.splitlines():
        candidate = line.strip()
        if not candidate:
            continue
        try:
            payloads.append(json.loads(candidate))
        except json.JSONDecodeError:
            continue
    return payloads


def _collect_error_messages_from_text(text: str) -> tuple[str, ...]:
    messages: list[str] = []

    def visit(candidate: Any) -> None:
        if isinstance(candidate, dict):
            for key, value in candidate.items():
                if key in {"error", "message"}:
                    if isinstance(value, str) and value.strip():
                        messages.append(value.strip())
                    elif isinstance(value, dict):
                        visit(value)
                elif isinstance(value, (dict, list)):
                    visit(value)
        elif isinstance(candidate, list):
            for item in candidate:
                visit(item)

    for payload in _parse_json_stream(text):
        visit(payload)
    return tuple(messages)


def _extract_generic_episode_result(*, backend: str, stdout: str, results_dir: Path) -> dict[str, Any]:
    for payload in reversed(_parse_json_stream(stdout)):
        result = _find_completed_result_payload(payload)
        if result is not None:
            _write_final_result(results_dir, backend=backend, payload=result)
            return result
    label = _backend_label(backend)
    raise BackendError(f"{label} output is missing a final JSON result", backend=backend)


def _load_episode_result(result_path: Path, *, backend: str) -> dict[str, Any]:
    label = _backend_label(backend)
    if not result_path.is_file():
        raise BackendError(f"{label} did not write the final result file: {result_path}", backend=backend)
    try:
        payload = json.loads(result_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise BackendError(f"{label} wrote invalid final JSON: {result_path}", backend=backend) from exc
    if not isinstance(payload, dict):
        raise BackendError(f"{label} final result must be a JSON object: {result_path}", backend=backend)
    if payload.get("status") != "completed":
        raise BackendError(f"{label} final result has unexpected status: {result_path}", backend=backend)
    if "stop_reason" not in payload or "action_count" not in payload:
        raise BackendError(f"{label} final result is missing required fields: {result_path}", backend=backend)
    return payload


def _load_workspace_state_from_results_dir(results_dir: Path) -> dict[str, Any] | None:
    state_path = results_dir.parent / "process" / "agent_workspace" / "state.json"
    if not state_path.is_file():
        return None
    try:
        payload = json.loads(state_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def _workspace_terminal_state_from_results_dir(results_dir: Path) -> bool | None:
    state = _load_workspace_state_from_results_dir(results_dir)
    if state is None:
        return None
    return bool(str(state.get("stop_code") or "").strip() or str(state.get("stop_reason") or "").strip())


def _extract_codex_episode_result(events_path: Path, result_path: Path) -> dict[str, Any]:
    final_text: str | None = None
    results_dir = result_path.parent
    try:
        payloads = inspect_event_stream(events_path, allow_incomplete_tail=False).payloads
    except CodexEventError as exc:
        raise BackendError(str(exc), backend="codex") from exc

    for payload in reversed(payloads):
        if str(payload.get("type") or "").strip() != "item.completed":
            continue
        item = payload.get("item")
        if not isinstance(item, dict):
            continue
        item_type = str(item.get("type") or "").strip()
        if item_type not in {"agent_message", "assistant_message"}:
            continue
        candidate = item.get("text")
        if isinstance(candidate, str) and candidate.strip():
            final_text = candidate.strip()
            break

    if final_text is None:
        raise BackendError(f"Codex event stream is missing a final text result: {events_path}", backend="codex")

    payload = _find_completed_result_payload(final_text)
    if payload is None:
        if _workspace_terminal_state_from_results_dir(results_dir) is False:
            raise BackendError(
                f"Codex turn completed before benchmark terminal state and did not provide valid final JSON: {events_path}",
                backend="codex",
            )
        raise BackendError(f"Codex final text result is not valid JSON: {events_path}", backend="codex")
    if _workspace_terminal_state_from_results_dir(results_dir) is False:
        raise BackendError(
            f"Codex final JSON result was emitted before benchmark terminal state: {events_path}",
            backend="codex",
        )
    if not isinstance(payload, dict):
        raise BackendError(f"Codex final text result must decode to a JSON object: {events_path}", backend="codex")

    _write_json(result_path, payload)
    return _load_episode_result(result_path, backend="codex")


def _skill_episode_file_lines(config: ExperimentConfig) -> str:
    if not config.skill_surface_enabled:
        return ""
    return "\n        - `skill_market.json`\n        - `owned_skills_index.json`"


def _skill_episode_guidance(config: ExperimentConfig) -> str:
    if not config.skill_surface_enabled:
        return ""
    return dedent(
        """

        如果 `owned_skills_index.json` 显示 `owned_skill_count > 0`，你已经拥有可用 skill。携带 skill 不代表每一步都必须使用；
        它是一组可选的决策支持能力。关键决策前至少检查相关 `owned_skills/<skill_id>/source/SKILL.md`。如果该 skill
        提供的说明、工具、脚本、安装步骤、检查清单、阈值或外部查询流程可能改善当前决策，你可以按 skill 文档在 workspace
        内调用它们，获得结果后进行分析，并基于这些结果选择下一步 benchmark 动作。开局 already-owned skill 是实验条件，
        不是 `purchase_skill` 动作，不扣购买价格或一天 burn。

        Skill 使用规则：
        - skill 的工具调用、分析和输出只用于决策支持；不能通过它们修改 benchmark 状态，状态变更仍只能通过 `./TadACampaign-agent-step`。
        - 如果 skill 建议安装依赖或运行脚本，只在当前 workspace 的 `.skill_tools/`、`.venv/` 或 skill 自己目录下操作；不要修改仓库源码或状态 JSON。
        - 如果使用 skill 产生了分析结果、报告、日志、图片、结构/序列/检索结果或其他 artifact，请保存在 `skill_analysis/` 下。
        - 若这些结果影响动作选择，请在 `--reasoning` 中引用 artifact 路径和具体发现，说明你如何根据结果做决策。
        - 如果当前没有适合调用的 skill、skill 与当前决策无关，或 setup 成本/风险不值得，允许跳过 skill 工具调用并继续按 benchmark 状态决策。
        """
    ).rstrip()


def _skill_episode_action_line(config: ExperimentConfig) -> str:
    if not config.skill_surface_enabled:
        return ""
    return '\n        - `./TadACampaign-agent-step --action purchase_skill --skill-id <skill_id> --reasoning "<短理由>"`'


def _skill_episode_rule_lines(config: ExperimentConfig) -> str:
    if not config.skill_surface_enabled:
        return ""
    return dedent(
        """
        - `skill_market.json` 只包含购买前卡片信息；购买成功后，完整内容会出现在 `owned_skills/<skill_id>/source/`。
        - 如果当前 `skill_market.json.cards` 为空但 `owned_skills_index.json` 非空，说明本轮是 forced-skill/no-market 条件；不要尝试购买 skill。
        - `purchase_skill` 只用于 market 条件下解锁尚未 owned 的离线 skill 文件。
        - 购买 skill 后，它会成为 owned skill；后续可选择调用其说明或工具获得结果、分析结果并辅助决策，但购买成功本身不强制每步都运行工具。
        """
    ).rstrip()


def _skill_episode_parameter_line(config: ExperimentConfig) -> str:
    if not config.skill_surface_enabled:
        return ""
    return "\n        - `purchase_skill` 只能使用当前 payload 中给出的 `skill_id`。"


def _handoff_read_file_lines(config: ExperimentConfig) -> str:
    if config.skill_surface_enabled:
        return dedent(
            """
              1. `agent_playbook.md`
              2. `available_actions.json`
              3. `skill_market.json`
              4. `owned_skills_index.json`
              5. `state.json`
              6. `history.json`
              7. 需要生物学或成本语境时，再读 `biology_context.md`
            """
        ).rstrip()
    return dedent(
        """
          1. `agent_playbook.md`
          2. `available_actions.json`
          3. `state.json`
          4. `history.json`
          5. 需要生物学或成本语境时，再读 `biology_context.md`
        """
    ).rstrip()


def _handoff_skill_guidance(config: ExperimentConfig) -> str:
    if not config.skill_surface_enabled:
        return ""
    return dedent(
        """
        - 如果当前已有 owned skill，必要时重新检查 `owned_skills/<skill_id>/source/SKILL.md`；若调用 skill 得到的结果会影响
          下一步决策，请把分析输出保存在 `skill_analysis/` 并在动作 reasoning 中引用具体发现。
        """
    ).rstrip()


def _episode_prompt(config: ExperimentConfig) -> str:
    prompt = dedent(
        f"""
        你是一名 AI 蛋白工程师，需要在当前 workspace 中完整执行一轮 TadACampaign 实验。
        这个 benchmark 被表述为一个真实的 TadA 定向进化项目，受到预算、时间和实验操作约束。
        你的最终目标是最大化终局 `cash_final`。

        行动前先按顺序阅读这些文件：
        - `agent_playbook.md`
        - `available_actions.json`
        {_skill_episode_file_lines(config)}
        - `state.json`
        - `history.json`
        - 可选：`biology_context.md`。当你需要动作的生物学依据、成本时间口径或 branch 解释时再读取它，不需要每一步重复打开。

        每一步都要有预算意识：
        - 先看 `state.economic_summary`，尤其是 `action_total_costs.confirm_hit`、`configured_minimum_mine_then_confirm_total_cost`、
          `available_mine_then_confirm_total_cost`、`has_available_mine_option` 和 `budget_regime`。
        - screening 发现的 hit 只有完成 `confirm_hit` 才会兑现；低预算时不要把钱全部花在探索和大 batch screening 上。
        - 选择 `mine_library` 的 batch size 时，优先选择 `available_actions.json` 中 `leaves_confirm_capacity=true` 的 batch option；
          如果某个 batch 会让后续 hit 无法确认，只有在你明确愿意承担“发现但无法兑现”的风险时才使用它，并在 reasoning 中说明。
        - 如果已有 `available_actions.confirm_hit` 候选且 `observed_activity` 高于当前 confirmed best，优先评估是否确认；不要继续探索到失去确认能力。
        {_skill_episode_guidance(config)}

        你作为当局者可以使用的信息：
        - 当前 visible seeds、prepared seeds、prepared libraries，以及你已经通过动作实际显露出来的探索路径。
        - visible seed 的 `start_sequence`，visible library 的 `library_id`、所属 `seed_id`、突变窗口、窗口长度和 prepared/locked 状态。
        - prepared library 的可筛序列总数、已筛数量、剩余数量和当前合法 batch options。
        - 当前现金、剩余天数、动作成本、mine 后确认余量、`economic_summary`、screening/confirmation 历史、pending hit、confirmed best 和 provisional best。
        - 可用 skill 或你自己分析得到的具体序列证据，例如 ORF/stop codon、motif、局部窗口、保守性、理化性质、alignment、结构或功能相关线索。
        - branch 显露的价值体现在它已经打开了哪些新的合法动作，以及这些动作与当前序列证据、实验历史和预算闭环是否匹配。

        你唯一允许的状态变更方式是调用本地工具脚本：
        - `./TadACampaign-agent-step --action prepare_seed --seed-id <seed_id> --reasoning "<短理由>"`
        - `./TadACampaign-agent-step --action prepare_library --seed-id <seed_id> --library-id <library_id> --reasoning "<短理由>"`
        - `./TadACampaign-agent-step --action mine_library --seed-id <seed_id> --library-id <library_id> --batch-size <int> --reasoning "<短理由>"`
        - `./TadACampaign-agent-step --action confirm_hit --screen-record-id <int> --reasoning "<短理由>"`
        {_skill_episode_action_line(config)}
        - `./TadACampaign-agent-step --action stop --reasoning "<短理由>"`

        操作规则：
        - 不要手工修改仓库文件或 benchmark 状态文件。
        - 每次工具脚本调用后，都要检查返回 JSON 和刷新后的 workspace 文件。
        - 读取 JSON 文件时优先用 `jq` 查看需要的字段；不要把完整大文件反复整段打印进上下文。
        - 如果工具脚本返回 `"accepted": false`，说明权威 judge 拒绝了这一步；先读 `rejection_reason`，再重新选择合法动作。
        - 只根据 `available_actions.json` 和刷新后的 `state.json` 判断当前哪些动作与参数合法。
        - `prepare_seed` 只会把一个已 visible 的 seed 变成 prepared，不会显露下游 seed。
        - `prepare_library` 只会准备当前 library；如果它打开了下游路径，返回 JSON 的 `newly_visible_seed_ids` 和刷新后的 `visible_seed_ids` 会显示新的 visible seed。
        - `mine_library` 是 screening 动作，不会直接发放 reward，也不会显露新的 seed。
        - screening 结果只会先暴露带噪声的 `observed_activity`，不会在这一刻揭示真实活性。
        - `confirm_hit` 是把 provisional screen 结果转成 confirmed 结果、揭示 `confirmed_activity` 并可能触发 reward 的唯一动作。
        {_skill_episode_rule_lines(config)}
        - prepared library 会在 `state.json` 和 `available_actions.json` 中提供 `screenable_sequence_count`、`screened_sequence_count` 和 `remaining_screenable_sequence_count`。
        - `mine_library` 只能使用当前 payload 中给出的离散 `batch_options`。
        - `confirm_hit` 只能使用当前 payload 中给出的 `screen_record_id`。
        {_skill_episode_parameter_line(config)}
        - 强的 provisional hit 值得认真评估，但在 confirm 之前它不会自动改善 `cash_final`。
        - 在合适的预算和时间范围内，更多探索可能发现活性更高的蛋白；更高的 confirmed activity 可以带来显著更高的 reward 并改善终局 `cash_final`。
        - 每一步都要在继续探索、确认候选和停止之间做经济选择；当剩余动作已没有可信的风险调整后现金提升路径时，应主动 `stop`。
        - 本轮实验的固定时间上限是 {config.max_experiment_days:g} 个 `elapsed_day`。
        - `step_index` 和 `request_count` 是审计计数，不代表实验天数。
        - 当实验终局时，只输出一行 JSON，不要附带额外说明文字。
        - 最终 JSON 必须包含：
          - `status` 设为 `"completed"`
          - `stop_reason` 为当前会话的最终停止原因
          - `action_count` 为最终动作数
          - `summary` 为一句简短总结
        """
    ).strip()
    extra_instructions = str(os.environ.get(AGENT_PROMPT_APPEND_ENV, "")).strip()
    if extra_instructions:
        prompt += "\n\n附加运营指令：\n" + extra_instructions
    return prompt + "\n"


def _load_workspace_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _history_lines(items: list[dict[str, Any]], *, fields: tuple[str, ...]) -> list[str]:
    lines: list[str] = []
    for item in items[-3:]:
        if not isinstance(item, dict):
            continue
        parts = []
        for field_name in fields:
            value = item.get(field_name)
            if value in {None, ""}:
                continue
            parts.append(f"{field_name}={value}")
        if parts:
            lines.append("- " + ", ".join(parts))
    return lines


def _build_handoff_prompt(
    config: ExperimentConfig,
    *,
    backend: str,
    agent_workspace: Path,
    source_session_id: str | None,
    trigger: str,
    stop_reason: str,
) -> str:
    state = _load_workspace_json(agent_workspace / "state.json")
    history = _load_workspace_json(agent_workspace / "history.json")
    recent_actions = history.get("recent_actions", [])
    recent_rejections = history.get("recent_rejections", [])
    action_lines = _history_lines(
        recent_actions if isinstance(recent_actions, list) else [],
        fields=("action", "seed_id", "library_id", "batch_size", "elapsed_day_after", "cash_after"),
    )
    rejection_lines = _history_lines(
        recent_rejections if isinstance(recent_rejections, list) else [],
        fields=("action", "seed_id", "library_id", "batch_size", "rejection_reason"),
    )
    action_block = "\n".join(action_lines) if action_lines else "- 无"
    rejection_block = "\n".join(rejection_lines) if rejection_lines else "- 无"
    brief = textwrap.dedent(
        f"""
        续跑交接说明：
        - 上一个 {_backend_label(backend)} 会话因上下文窗口耗尽而停止。
        - 上一个会话 id：{source_session_id or "unknown"}
        - 触发原因：{trigger}
        - 后端停止原因摘录：{stop_reason[:400]}
        - 权威 benchmark 状态仍在 judge server 上继续存活；请基于当前 workspace 状态续跑，不要重启实验。
        - 当前 `elapsed_day`：{state.get("elapsed_day")}
        - 当前 `remaining_days`：{state.get("remaining_days")}
        - 当前 `current_cash`：{state.get("current_cash")}
        - 当前 `confirmed_best_activity`：{state.get("confirmed_best_activity")}
        - 当前 `action_count`：{state.get("action_count")}
        - 当前 `request_count`：{state.get("request_count")}
        - 采取任何动作前，重新按顺序读取这些文件：
        {_handoff_read_file_lines(config)}
        {_handoff_skill_guidance(config)}

        最近接受的动作：
        {action_block}

        最近拒绝的动作：
        {rejection_block}
        """
    ).strip()
    return _episode_prompt(config) + "\n" + brief + "\n"


def _build_resume_prompt(config: ExperimentConfig, *, agent_workspace: Path, trigger: str, stop_reason: str) -> str:
    state = _load_workspace_json(agent_workspace / "state.json")
    history = _load_workspace_json(agent_workspace / "history.json")
    recent_actions = history.get("recent_actions", [])
    recent_rejections = history.get("recent_rejections", [])
    action_lines = _history_lines(
        recent_actions if isinstance(recent_actions, list) else [],
        fields=("action", "seed_id", "library_id", "batch_size", "screen_record_id", "elapsed_day_after", "cash_after"),
    )
    rejection_lines = _history_lines(
        recent_rejections if isinstance(recent_rejections, list) else [],
        fields=("action", "seed_id", "library_id", "batch_size", "screen_record_id", "rejection_reason"),
    )
    action_block = "\n".join(action_lines) if action_lines else "- 无"
    rejection_block = "\n".join(rejection_lines) if rejection_lines else "- 无"
    return textwrap.dedent(
        f"""
        继续当前 TadACampaign 实验，不要重启实验。
        上一次 OpenCode attempt 结束原因：{trigger}; {stop_reason[:300]}

        当前权威状态文件已经刷新。下一步必须：
        1. 读取 `available_actions.json`、`state.json`、`history.json`。
        2. 如果实验尚未 terminal，基于合法动作继续调用 `./TadACampaign-agent-step`。
        3. 每次工具脚本调用后检查返回 JSON 并刷新状态文件。
        4. 如果实验已经 terminal，或者你决定 stop 且 stop 被接受，只输出一行最终 JSON。

        当前摘要：
        - elapsed_day: {state.get("elapsed_day")}
        - remaining_days: {state.get("remaining_days")}
        - current_cash: {state.get("current_cash")}
        - confirmed_best_activity: {state.get("confirmed_best_activity")}
        - provisional_best_activity: {state.get("provisional_best_activity")}
        - pending_confirmation_count: {state.get("pending_confirmation_count")}
        - action_count: {state.get("action_count")}

        最近接受动作：
        {action_block}

        最近拒绝动作：
        {rejection_block}

        终局时最终 JSON 必须只占一行，至少包含：
        {{"status":"completed","stop_reason":"...","action_count":<int>,"summary":"..."}}
        """
    ).strip() + "\n"


def _build_codex_command(
    config: ExperimentConfig,
    *,
    run_dir: Path,
    agent_workspace: Path,
    invocation: _AttemptInvocation,
) -> list[str]:
    command = [
        "codex",
        "exec",
        "--skip-git-repo-check",
        "--color",
        "never",
        "-C",
        str(agent_workspace),
        "--add-dir",
        str(run_dir),
    ]
    if config.agent_model:
        command.extend(["-m", config.agent_model])
    if config.agent_profile:
        command.extend(["-p", config.agent_profile])
    if config.agent_reasoning_effort:
        command.extend(["-c", f"model_reasoning_effort={json.dumps(config.agent_reasoning_effort)}"])
    if config.agent_verbosity:
        command.extend(["-c", f"model_verbosity={json.dumps(config.agent_verbosity)}"])
    schema_path = _write_codex_final_result_schema(run_dir / "results")
    command.extend(["--output-schema", str(schema_path)])
    command.append("--json")
    if invocation.resume_session_id:
        command.extend(["resume", invocation.resume_session_id, "-"])
    else:
        command.append("-")
    return command


def _claude_cli_bin() -> str:
    """返回 Claude Code 后端使用的 CLI 可执行文件名（默认 ``reclaude``，可经环境变量覆盖）。"""
    override = str(os.environ.get(CLAUDE_CLI_BIN_ENV, "")).strip()
    return override or DEFAULT_CLAUDE_CLI_BIN


def _build_claude_command(
    config: ExperimentConfig,
    *,
    run_dir: Path,
    invocation: _AttemptInvocation,
) -> list[str]:
    command = [
        _claude_cli_bin(),
        "-p",
        "--dangerously-skip-permissions",
        "--output-format",
        "json",
        "--add-dir",
        str(run_dir),
        "--json-schema",
        json.dumps(_FINAL_RESULT_SCHEMA, ensure_ascii=False),
    ]
    if config.agent_model:
        command.extend(["--model", config.agent_model])
    if config.agent_reasoning_effort:
        command.extend(["--effort", config.agent_reasoning_effort])
    if invocation.resume_session_id:
        command.extend(["--resume", invocation.resume_session_id])
    if invocation.mode == "handoff":
        command.append("--fork-session")
    if invocation.target_session_id and (invocation.mode != "resume" or invocation.target_session_id != invocation.resume_session_id):
        command.extend(["--session-id", invocation.target_session_id])
    command.append(invocation.prompt)
    return command


def _build_opencode_command(
    config: ExperimentConfig,
    *,
    agent_workspace: Path,
    invocation: _AttemptInvocation,
) -> list[str]:
    command = [
        "opencode",
        "run",
        "--pure",
        "--format",
        "json",
        "--dir",
        str(agent_workspace),
    ]
    if config.agent_model:
        command.extend(["--model", config.agent_model])
    if config.agent_reasoning_effort:
        command.append("--thinking")
        command.extend(["--variant", config.agent_reasoning_effort])
    if invocation.resume_session_id:
        command.extend(["--session", invocation.resume_session_id])
    if invocation.mode == "handoff":
        command.append("--fork")
    session_title = str(invocation.metadata.get("session_title") or "").strip()
    if session_title:
        command.extend(["--title", session_title])
    command.append(invocation.prompt)
    return command


def _build_backend_command(
    config: ExperimentConfig,
    *,
    run_dir: Path,
    agent_workspace: Path,
    invocation: _AttemptInvocation,
) -> list[str]:
    if invocation.backend == "codex":
        return _build_codex_command(config, run_dir=run_dir, agent_workspace=agent_workspace, invocation=invocation)
    if invocation.backend == "claude":
        return _build_claude_command(config, run_dir=run_dir, invocation=invocation)
    if invocation.backend == "opencode":
        return _build_opencode_command(config, agent_workspace=agent_workspace, invocation=invocation)
    raise BackendError(f"Unsupported agent backend {invocation.backend!r}")


def _attempt_stdin(invocation: _AttemptInvocation) -> str | None:
    if invocation.backend == "codex":
        return invocation.prompt
    return None


def _should_arm_handoff_drill(backend: str, handoff_drill_state: _HandoffDrillState | None) -> bool:
    return (
        handoff_drill_state is not None
        and handoff_drill_state.config is not None
        and handoff_drill_state.triggered_count < handoff_drill_state.config.max_triggers
    )


def _run_attempt_process(
    config: ExperimentConfig,
    *,
    run_dir: Path,
    agent_workspace: Path,
    invocation: _AttemptInvocation,
    attempt_index: int,
    handoff_drill_state: _HandoffDrillState | None = None,
) -> _AttemptProcessResult:
    results_dir = run_dir / "results"
    command = _build_backend_command(
        config,
        run_dir=run_dir,
        agent_workspace=agent_workspace,
        invocation=invocation,
    )

    popen_kwargs: dict[str, object] = {}
    if os.name == "posix":
        popen_kwargs["start_new_session"] = True
    child_env = dict(os.environ)
    child_env.pop("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", None)
    child_env["TADACAMPAIGN_AGENT_BACKEND"] = invocation.backend
    if invocation.target_session_id:
        child_env["TADACAMPAIGN_AGENT_SESSION_ID"] = invocation.target_session_id

    process = subprocess.Popen(
        command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(agent_workspace),
        text=True,
        env=child_env,
        **popen_kwargs,
    )
    started_at = utc_now_iso()
    started_monotonic = monotonic_now()
    _append_backend_event(
        run_dir,
        backend=invocation.backend,
        suffix="attempt.started",
        attempt=attempt_index,
        mode=invocation.mode,
        started_at=started_at,
        resume_session_id=invocation.resume_session_id,
        target_session_id=invocation.target_session_id,
        source_session_id=invocation.source_session_id,
        trigger=invocation.trigger,
        prompt_path=invocation.prompt_path,
        command=command,
    )

    handoff_drill_watch_thread: threading.Thread | None = None
    handoff_drill_stop_event: threading.Event | None = None
    handoff_drill_outcome = {
        "triggered": False,
        "triggered_at": None,
        "accepted_action_count": None,
        "trigger_step_index": None,
    }
    if _should_arm_handoff_drill(invocation.backend, handoff_drill_state):
        assert handoff_drill_state is not None and handoff_drill_state.config is not None
        _append_backend_event(
            run_dir,
            backend=invocation.backend,
            suffix="handoff_drill.armed",
            attempt=attempt_index,
            trigger_after_accepted_actions=handoff_drill_state.config.after_accepted_actions,
            max_triggers=handoff_drill_state.config.max_triggers,
            triggered_count=handoff_drill_state.triggered_count,
        )
        handoff_drill_stop_event = threading.Event()
        handoff_drill_watch_thread = threading.Thread(
            target=_run_handoff_drill_watch,
            kwargs={
                "run_dir": run_dir,
                "process": process,
                "attempt_index": attempt_index,
                "backend": invocation.backend,
                "config": handoff_drill_state.config,
                "stop_event": handoff_drill_stop_event,
                "outcome": handoff_drill_outcome,
            },
            daemon=True,
        )
        handoff_drill_watch_thread.start()

    try:
        stdout, stderr = process.communicate(_attempt_stdin(invocation), timeout=config.agent_timeout_seconds)
    except subprocess.TimeoutExpired as exc:
        if handoff_drill_stop_event is not None:
            handoff_drill_stop_event.set()
        if handoff_drill_watch_thread is not None:
            handoff_drill_watch_thread.join(timeout=1)
        _terminate_process_tree(process)
        stdout = exc.stdout if isinstance(exc.stdout, str) else (exc.stdout or b"").decode("utf-8", errors="replace")
        stderr = exc.stderr if isinstance(exc.stderr, str) else (exc.stderr or b"").decode("utf-8", errors="replace")
        _write_agent_logs(run_dir, backend=invocation.backend, stdout=stdout, stderr=stderr, command=command)
        finished_at = utc_now_iso()
        duration_seconds = elapsed_seconds(started_monotonic)
        timeout_message = f"{_backend_label(invocation.backend)} timed out after {config.agent_timeout_seconds}s"
        _append_backend_event(
            run_dir,
            backend=invocation.backend,
            suffix="attempt.finished",
            attempt=attempt_index,
            mode=invocation.mode,
            started_at=started_at,
            finished_at=finished_at,
            duration_seconds=duration_seconds,
            ok=False,
            returncode=-1,
            error=timeout_message,
            resume_session_id=invocation.resume_session_id,
            target_session_id=invocation.target_session_id,
            source_session_id=invocation.source_session_id,
            trigger=invocation.trigger,
            prompt_path=invocation.prompt_path,
        )
        return _AttemptProcessResult(
            command=command,
            returncode=-1,
            stdout=stdout,
            stderr=stderr,
            error=f"{timeout_message}; see {results_dir / 'agent_stderr.log'}",
            started_at=started_at,
            finished_at=finished_at,
            duration_seconds=duration_seconds,
        )
    finally:
        if handoff_drill_stop_event is not None:
            handoff_drill_stop_event.set()
        if handoff_drill_watch_thread is not None:
            handoff_drill_watch_thread.join(timeout=1)

    if handoff_drill_outcome["triggered"]:
        synthetic_error = (
            "context_window_exceeded (handoff drill after "
            f"{handoff_drill_outcome['accepted_action_count']} accepted actions)"
        )
        stderr = f"{stderr.rstrip()}\n{synthetic_error}\n" if stderr.strip() else synthetic_error
        if handoff_drill_state is not None:
            handoff_drill_state.triggered_count += 1
            assert handoff_drill_state.trigger_records is not None
            handoff_drill_state.trigger_records.append(
                {
                    "attempt": attempt_index,
                    "triggered_at": handoff_drill_outcome["triggered_at"],
                    "accepted_action_count": handoff_drill_outcome["accepted_action_count"],
                    "trigger_step_index": handoff_drill_outcome["trigger_step_index"],
                }
            )

    _write_agent_logs(run_dir, backend=invocation.backend, stdout=stdout, stderr=stderr, command=command)
    error: str | None = None
    if handoff_drill_outcome["triggered"]:
        error = stderr.strip()
    elif process.returncode != 0:
        error = (
            f"{_backend_label(invocation.backend)} returned non-zero exit code {process.returncode}; "
            f"see {results_dir / 'agent_stderr.log'}"
        )
    finished_at = utc_now_iso()
    duration_seconds = elapsed_seconds(started_monotonic)
    _append_backend_event(
        run_dir,
        backend=invocation.backend,
        suffix="attempt.finished",
        attempt=attempt_index,
        mode=invocation.mode,
        started_at=started_at,
        finished_at=finished_at,
        duration_seconds=duration_seconds,
        ok=process.returncode == 0 and not handoff_drill_outcome["triggered"],
        returncode=int(process.returncode),
        error=error,
        resume_session_id=invocation.resume_session_id,
        target_session_id=invocation.target_session_id,
        source_session_id=invocation.source_session_id,
        trigger=invocation.trigger,
        prompt_path=invocation.prompt_path,
    )
    return _AttemptProcessResult(
        command=command,
        returncode=int(process.returncode),
        stdout=stdout,
        stderr=stderr,
        error=error,
        started_at=started_at,
        finished_at=finished_at,
        duration_seconds=duration_seconds,
    )


def _lookup_opencode_session_id(agent_workspace: Path, session_title: str) -> str | None:
    if not session_title.strip():
        return None
    child_env = dict(os.environ)
    child_env.pop("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", None)
    result = subprocess.run(
        ["opencode", "session", "list", "--format", "json", "-n", "200"],
        cwd=str(agent_workspace),
        capture_output=True,
        text=True,
        env=child_env,
        check=False,
    )
    if result.returncode != 0:
        return None
    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, list):
        return None
    directory = str(agent_workspace.resolve())
    candidates: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        if str(item.get("title") or "") != session_title:
            continue
        if str(item.get("directory") or "") != directory:
            continue
        candidates.append(item)
    if not candidates:
        return None
    candidates.sort(key=lambda item: (int(item.get("updated", 0)), int(item.get("created", 0))), reverse=True)
    session_id = candidates[0].get("id")
    return str(session_id) if isinstance(session_id, str) and session_id.strip() else None


def _inspect_codex_attempt(invocation: _AttemptInvocation, stdout_path: Path) -> tuple[_AttemptSnapshot, Exception | None]:
    try:
        provider_snapshot = inspect_event_stream(
            stdout_path,
            expected_thread_id=invocation.resume_session_id,
            allow_incomplete_tail=True,
        )
    except CodexEventError as exc:
        snapshot = _AttemptSnapshot(
            observed_session_id=None,
            effective_session_id=invocation.resume_session_id,
            saw_completion=False,
            error_messages=(),
            truncated_tail=False,
        )
        return snapshot, exc

    snapshot = _AttemptSnapshot(
        observed_session_id=provider_snapshot.observed_thread_id,
        effective_session_id=provider_snapshot.effective_thread_id,
        saw_completion=provider_snapshot.saw_turn_completed,
        error_messages=provider_snapshot.error_messages,
        truncated_tail=provider_snapshot.truncated_tail,
        provider_snapshot=provider_snapshot,
    )
    if (
        invocation.resume_session_id is not None
        and provider_snapshot.observed_thread_id is not None
        and provider_snapshot.observed_thread_id != invocation.resume_session_id
    ):
        return snapshot, CodexEventError(
            f"Codex resumed with unexpected thread id: expected {invocation.resume_session_id}, got {provider_snapshot.observed_thread_id}"
        )
    return snapshot, None


def _inspect_generic_attempt(
    invocation: _AttemptInvocation,
    *,
    process_result: _AttemptProcessResult,
    agent_workspace: Path,
) -> _AttemptSnapshot:
    observed_session_id = invocation.target_session_id or invocation.resume_session_id
    if invocation.backend == "opencode":
        looked_up_session_id = _lookup_opencode_session_id(
            agent_workspace,
            str(invocation.metadata.get("session_title") or ""),
        )
        if looked_up_session_id:
            observed_session_id = looked_up_session_id
    saw_completion = _find_completed_result_payload(process_result.stdout) is not None
    error_messages = _collect_error_messages_from_text(process_result.stdout)
    return _AttemptSnapshot(
        observed_session_id=observed_session_id,
        effective_session_id=observed_session_id or invocation.resume_session_id,
        saw_completion=saw_completion,
        error_messages=error_messages,
        truncated_tail=False,
    )


def _inspect_attempt(
    invocation: _AttemptInvocation,
    *,
    process_result: _AttemptProcessResult,
    agent_workspace: Path,
    results_dir: Path,
) -> tuple[_AttemptSnapshot, Exception | None]:
    stdout_path = results_dir / "agent_stdout.log"
    if invocation.backend == "codex":
        return _inspect_codex_attempt(invocation, stdout_path)
    return _inspect_generic_attempt(invocation, process_result=process_result, agent_workspace=agent_workspace), None


def _validate_success(invocation: _AttemptInvocation, snapshot: _AttemptSnapshot, *, results_dir: Path) -> str | None:
    if invocation.backend == "codex":
        provider_snapshot = snapshot.provider_snapshot
        if not isinstance(provider_snapshot, CodexEventSnapshot):
            raise BackendError("Codex attempt snapshot is missing provider state", backend="codex")
        return validate_event_stream(results_dir / "codex_events.jsonl", expected_thread_id=invocation.resume_session_id)

    effective_session_id = snapshot.effective_session_id
    if effective_session_id is None:
        raise BackendError(
            f"{_backend_label(invocation.backend)} did not expose a recoverable session id",
            backend=invocation.backend,
        )
    return effective_session_id


def _extract_episode_result(
    invocation: _AttemptInvocation,
    *,
    process_result: _AttemptProcessResult,
    results_dir: Path,
) -> dict[str, Any]:
    if invocation.backend == "codex":
        payload = _extract_codex_episode_result(results_dir / "codex_events.jsonl", results_dir / "codex_final_result.json")
        _write_final_result(results_dir, backend="codex", payload=payload)
        return payload
    payload = _extract_generic_episode_result(
        backend=invocation.backend,
        stdout=process_result.stdout,
        results_dir=results_dir,
    )
    return _load_episode_result(results_dir / "agent_final_result.json", backend=invocation.backend)


def _classify_generic_failure(
    *,
    snapshot: _AttemptSnapshot,
    process_error: str | None,
    stdout: str,
    stderr: str,
    validation_error: Exception | None,
) -> _FailureClassification:
    diagnostic_candidates = [
        str(validation_error) if validation_error is not None else "",
        *(str(item) for item in snapshot.error_messages),
        stderr,
        process_error or "",
    ]
    normalized = "\n".join(item for item in diagnostic_candidates if item).lower()
    stop_reason = next(
        (
            item.strip()
            for item in [*diagnostic_candidates, stdout]
            if isinstance(item, str) and item.strip()
        ),
        "unknown backend failure",
    )
    reason_excerpt = stop_reason[:400]

    if snapshot.saw_completion:
        return _FailureClassification(
            classification="completed_without_valid_result",
            retryable=False,
            continuation_mode="terminal",
            stop_reason=stop_reason,
            reason_excerpt=reason_excerpt,
        )
    if any(marker in normalized for marker in CONTEXT_WINDOW_ERROR_MARKERS):
        return _FailureClassification(
            classification="fresh_handoff_required",
            retryable=True,
            continuation_mode="handoff",
            stop_reason=stop_reason,
            reason_excerpt=reason_excerpt,
        )
    if any(marker in normalized for marker in NON_RETRYABLE_ERROR_MARKERS):
        return _FailureClassification(
            classification="terminal_non_retryable_error",
            retryable=False,
            continuation_mode="terminal",
            stop_reason=stop_reason,
            reason_excerpt=reason_excerpt,
        )
    if snapshot.effective_session_id is not None and any(marker in normalized for marker in RETRYABLE_ERROR_MARKERS):
        return _FailureClassification(
            classification="retryable_interruption",
            retryable=True,
            continuation_mode="resume",
            stop_reason=stop_reason,
            reason_excerpt=reason_excerpt,
        )
    if snapshot.effective_session_id is not None and validation_error is not None:
        return _FailureClassification(
            classification="retryable_missing_final_result",
            retryable=True,
            continuation_mode="handoff",
            stop_reason=stop_reason,
            reason_excerpt=reason_excerpt,
        )
    return _FailureClassification(
        classification="terminal_backend_error",
        retryable=False,
        continuation_mode="terminal",
        stop_reason=stop_reason,
        reason_excerpt=reason_excerpt,
    )


def _classify_failure(
    invocation: _AttemptInvocation,
    *,
    snapshot: _AttemptSnapshot,
    process_error: str | None,
    stdout: str,
    stderr: str,
    validation_error: Exception | None,
) -> _FailureClassification:
    if invocation.backend == "codex":
        provider_snapshot = snapshot.provider_snapshot
        if not isinstance(provider_snapshot, CodexEventSnapshot):
            provider_snapshot = CodexEventSnapshot(
                payloads=(),
                observed_thread_id=None,
                effective_thread_id=invocation.resume_session_id,
                saw_turn_completed=False,
                error_messages=(),
                truncated_tail=False,
            )
        failure = classify_codex_failure(
            snapshot=provider_snapshot,
            process_error=process_error,
            stdout=stdout,
            stderr=stderr,
            validation_error=validation_error,
        )
        return _FailureClassification(
            classification=failure.classification,
            retryable=failure.retryable,
            continuation_mode=failure.continuation_mode,
            stop_reason=failure.stop_reason,
            reason_excerpt=failure.reason_excerpt,
        )

    return _classify_generic_failure(
        snapshot=snapshot,
        process_error=process_error,
        stdout=stdout,
        stderr=stderr,
        validation_error=validation_error,
    )


def _new_claude_session_id() -> str:
    return str(uuid.uuid4())


def _new_opencode_session_title(run_dir: Path, *, mode: str) -> str:
    return f"TadACampaign-{run_dir.name}-{mode}-{uuid.uuid4().hex[:12]}"


def _initial_invocation(config: ExperimentConfig, *, run_dir: Path) -> _AttemptInvocation:
    backend = config.agent_backend
    prompt = _episode_prompt(config)
    if backend == "codex":
        return _AttemptInvocation(
            backend=backend,
            mode="initial",
            prompt=prompt,
            prompt_path=None,
            resume_session_id=None,
            target_session_id=None,
            source_session_id=None,
            trigger="run_start",
        )
    if backend == "claude":
        return _AttemptInvocation(
            backend=backend,
            mode="initial",
            prompt=prompt,
            prompt_path=None,
            resume_session_id=None,
            target_session_id=_new_claude_session_id(),
            source_session_id=None,
            trigger="run_start",
        )
    if backend == "opencode":
        return _AttemptInvocation(
            backend=backend,
            mode="initial",
            prompt=prompt,
            prompt_path=None,
            resume_session_id=None,
            target_session_id=None,
            source_session_id=None,
            trigger="run_start",
            metadata={"session_title": _new_opencode_session_title(run_dir, mode="initial")},
        )
    raise BackendError(f"Unsupported agent backend {backend!r}")


def _resume_invocation(
    current: _AttemptInvocation,
    *,
    config: ExperimentConfig,
    run_dir: Path,
    session_id: str,
    trigger: str,
) -> _AttemptInvocation:
    if current.backend == "codex":
        return _AttemptInvocation(
            backend=current.backend,
            mode="resume",
            prompt=_episode_prompt(config),
            prompt_path=None,
            resume_session_id=session_id,
            target_session_id=session_id,
            source_session_id=session_id,
            trigger=trigger,
        )
    if current.backend == "claude":
        return _AttemptInvocation(
            backend=current.backend,
            mode="resume",
            prompt=_episode_prompt(config),
            prompt_path=None,
            resume_session_id=session_id,
            target_session_id=session_id,
            source_session_id=session_id,
            trigger=trigger,
        )
    if current.backend == "opencode":
        return _AttemptInvocation(
            backend=current.backend,
            mode="resume",
            prompt=_build_resume_prompt(
                config,
                agent_workspace=run_dir / "process" / "agent_workspace",
                trigger=trigger,
                stop_reason="OpenCode did not emit the required final JSON in the previous attempt.",
            ),
            prompt_path=None,
            resume_session_id=session_id,
            target_session_id=session_id,
            source_session_id=session_id,
            trigger=trigger,
        )
    raise BackendError(f"Unsupported agent backend {current.backend!r}")


def _handoff_invocation(
    current: _AttemptInvocation,
    *,
    config: ExperimentConfig,
    run_dir: Path,
    agent_workspace: Path,
    session_id: str,
    trigger: str,
    stop_reason: str,
    prompt_path: str,
) -> _AttemptInvocation:
    prompt = _build_handoff_prompt(
        config,
        backend=current.backend,
        agent_workspace=agent_workspace,
        source_session_id=session_id,
        trigger=trigger,
        stop_reason=stop_reason,
    )
    if current.backend == "codex":
        return _AttemptInvocation(
            backend=current.backend,
            mode="handoff",
            prompt=prompt,
            prompt_path=prompt_path,
            resume_session_id=None,
            target_session_id=None,
            source_session_id=session_id,
            trigger=trigger,
        )
    if current.backend == "claude":
        return _AttemptInvocation(
            backend=current.backend,
            mode="handoff",
            prompt=prompt,
            prompt_path=prompt_path,
            resume_session_id=session_id,
            target_session_id=_new_claude_session_id(),
            source_session_id=session_id,
            trigger=trigger,
        )
    if current.backend == "opencode":
        return _AttemptInvocation(
            backend=current.backend,
            mode="handoff",
            prompt=prompt,
            prompt_path=prompt_path,
            resume_session_id=session_id,
            target_session_id=None,
            source_session_id=session_id,
            trigger=trigger,
            metadata={"session_title": _new_opencode_session_title(run_dir, mode="handoff")},
        )
    raise BackendError(f"Unsupported agent backend {current.backend!r}")


def _attempt_record(
    invocation: _AttemptInvocation,
    *,
    snapshot: _AttemptSnapshot,
    process_result: _AttemptProcessResult,
    attempt_index: int,
    classification: str,
    retryable: bool,
    continuation_mode: str,
    stop_reason: str,
    reason_excerpt: str,
    events_path: str,
    result_snapshot_path: str,
) -> dict[str, Any]:
    record = {
        "attempt": int(attempt_index),
        "backend": invocation.backend,
        "mode": invocation.mode,
        "trigger": invocation.trigger,
        "prompt_path": invocation.prompt_path,
        "resume_session_id": invocation.resume_session_id,
        "target_session_id": invocation.target_session_id,
        "source_session_id": invocation.source_session_id,
        "observed_session_id": snapshot.observed_session_id,
        "effective_session_id": snapshot.effective_session_id,
        "result_session_id": snapshot.observed_session_id or snapshot.effective_session_id,
        "started_at": process_result.started_at,
        "ended_at": process_result.finished_at,
        "duration_seconds": process_result.duration_seconds,
        "returncode": int(process_result.returncode),
        "classification": classification,
        "retryable": bool(retryable),
        "continuation_mode": continuation_mode,
        "stop_reason": stop_reason,
        "reason_excerpt": reason_excerpt,
        "events_path": events_path,
        "result_snapshot_path": result_snapshot_path,
        "command": list(process_result.command),
    }
    if invocation.backend == "codex":
        record.update(
            {
                "resume_thread_id": invocation.resume_session_id,
                "source_thread_id": invocation.source_session_id,
                "observed_thread_id": snapshot.observed_session_id,
                "effective_thread_id": snapshot.effective_session_id,
                "result_thread_id": snapshot.observed_session_id or snapshot.effective_session_id,
            }
        )
    return record


def _run_policy_episode(
    config: ExperimentConfig,
    *,
    run_dir: Path,
    agent_workspace: Path,
) -> dict[str, Any]:
    if not config.agent_policy:
        raise BackendError("Policy backend requires [agent].policy", backend="policy")

    from .runner import run_agent_step

    agent_workspace.mkdir(parents=True, exist_ok=True)
    results_dir = run_dir / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(policy_rng_seed(config, config.agent_policy))
    memory = make_policy_memory()
    stdout_lines: list[str] = []
    final_result: dict[str, Any] | None = None
    session_id = f"policy:{config.agent_policy}:{run_dir.name}"
    max_steps = int(config.agent_policy_params.get("max_steps", 512))

    for loop_index in range(1, max_steps + 1):
        observation = {
            "state": _load_workspace_json(agent_workspace / "state.json"),
            "history": _load_workspace_json(agent_workspace / "history.json"),
            "available_actions": _load_workspace_json(agent_workspace / "available_actions.json"),
        }
        decision = select_action(
            config.agent_policy,
            config=config,
            observation=observation,
            memory=memory,
            rng=rng,
        )
        stdout_lines.append(
            json.dumps(
                {
                    "loop_index": loop_index,
                    "policy": config.agent_policy,
                    "decision": decision.__dict__,
                },
                ensure_ascii=False,
            )
        )
        result = run_agent_step(run_dir, decision)
        update_memory(memory, result=result)
        stdout_lines.append(
            json.dumps(
                {
                    "loop_index": loop_index,
                    "accepted": result.get("accepted"),
                    "terminal": result.get("terminal"),
                    "stop_code": result.get("stop_code"),
                    "stop_reason": result.get("stop_reason"),
                    "action_count": result.get("action_count"),
                    "request_count": result.get("request_count"),
                    "cash": result.get("cash"),
                    "day": result.get("day"),
                },
                ensure_ascii=False,
            )
        )
        if result.get("terminal") is True:
            final_result = {
                "status": "completed",
                "stop_reason": str(result.get("stop_reason") or ""),
                "action_count": int(result.get("action_count", 0) or 0),
                "summary": f"Policy {config.agent_policy} completed the benchmark.",
                "backend": "policy",
                "policy": config.agent_policy,
                "session_id": session_id,
            }
            break

    if final_result is None:
        raise BackendError(
            f"Policy {config.agent_policy} exceeded max_steps={max_steps} without reaching terminal state",
            session_id=session_id,
            backend="policy",
        )

    jev_runtime = getattr(memory, "jev_runtime", None)
    if jev_runtime is not None:
        jev_runtime.close()
        (results_dir / "jev_decisions.jsonl").write_text(
            "".join(json.dumps(item, ensure_ascii=False) + "\n" for item in jev_runtime.traces),
            encoding="utf-8",
        )
        append_runtime_event(
            run_dir,
            event="jev.episode.completed",
            calls=jev_runtime.calls,
            estimated_cost=jev_runtime.estimated_cost,
            policy=config.agent_policy,
        )

    _write_agent_logs(
        run_dir,
        backend="policy",
        stdout="\n".join(stdout_lines) + ("\n" if stdout_lines else ""),
        stderr="",
        command=["TadACampaign-policy", str(config.agent_policy)],
    )
    _write_final_result(results_dir, backend="policy", payload=final_result)
    return {
        "backend": "policy",
        "session_id": session_id,
        "thread_id": None,
        "final_result": final_result,
        "stdout_path": str(results_dir / "agent_stdout.log"),
        "final_result_path": str(results_dir / "agent_final_result.json"),
        "resume_meta_path": None,
        "handoff_drill_meta_path": None,
        "resume_count": 0,
        "handoff_count": 0,
        "attempt_count": 1,
    }


def run_backend_episode(
    config: ExperimentConfig,
    *,
    run_dir: Path,
    agent_workspace: Path,
) -> dict[str, Any]:
    if config.agent_backend == "policy":
        return _run_policy_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    if config.agent_backend not in {"codex", "claude", "opencode"}:
        raise BackendError(f"Unsupported agent backend {config.agent_backend!r}")

    agent_workspace.mkdir(parents=True, exist_ok=True)
    results_dir = run_dir / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    handoff_drill_state = _HandoffDrillState(config=_load_handoff_drill_config())

    raw_max_resume_attempts = max(int(DEFAULT_CODEX_AUTO_RESUME_MAX_ATTEMPTS), 0)
    auto_resume_enabled = bool(DEFAULT_CODEX_AUTO_RESUME_ENABLED)
    max_total_resume_attempts = None if raw_max_resume_attempts == 0 else raw_max_resume_attempts
    raw_max_handoff_count = int(DEFAULT_CODEX_CONTEXT_WINDOW_HANDOFF_MAX_COUNT)
    max_handoff_count = None if raw_max_handoff_count < 0 else raw_max_handoff_count

    current_invocation = _initial_invocation(config, run_dir=run_dir)
    attempts: list[dict[str, Any]] = []
    retryable_failure_count = 0
    resume_count = 0
    handoff_count = 0
    final_session_id: str | None = None
    final_result: dict[str, Any] | None = None
    final_error: str | None = None

    attempt_index = 0
    while True:
        attempt_index += 1
        process_result = _run_attempt_process(
            config,
            run_dir=run_dir,
            agent_workspace=agent_workspace,
            invocation=current_invocation,
            attempt_index=attempt_index,
            handoff_drill_state=handoff_drill_state,
        )
        snapshot, snapshot_error = _inspect_attempt(
            current_invocation,
            process_result=process_result,
            agent_workspace=agent_workspace,
            results_dir=results_dir,
        )
        validation_error: Exception | None = snapshot_error
        effective_session_id = snapshot.effective_session_id

        if process_result.returncode == 0 and process_result.error is None and snapshot_error is None:
            try:
                effective_session_id = _validate_success(current_invocation, snapshot, results_dir=results_dir)
                final_result = _extract_episode_result(current_invocation, process_result=process_result, results_dir=results_dir)
            except (BackendError, CodexEventError) as exc:
                validation_error = exc
            else:
                final_session_id = effective_session_id
                attempts.append(
                    _attempt_record(
                        current_invocation,
                        snapshot=_AttemptSnapshot(
                            observed_session_id=snapshot.observed_session_id,
                            effective_session_id=effective_session_id,
                            saw_completion=snapshot.saw_completion,
                            error_messages=snapshot.error_messages,
                            truncated_tail=snapshot.truncated_tail,
                            provider_snapshot=snapshot.provider_snapshot,
                        ),
                        process_result=process_result,
                        attempt_index=attempt_index,
                        classification="success",
                        retryable=False,
                        continuation_mode="terminal",
                        stop_reason=str(final_result.get("stop_reason") or ""),
                        reason_excerpt=str(final_result.get("stop_reason") or "")[:400],
                        events_path="agent_stdout.log",
                        result_snapshot_path="",
                    )
                )
                break

        failure = _classify_failure(
            current_invocation,
            snapshot=snapshot,
            process_error=process_result.error,
            stdout=process_result.stdout,
            stderr=process_result.stderr,
            validation_error=validation_error,
        )
        should_resume = (
            failure.continuation_mode == "resume"
            and auto_resume_enabled
            and effective_session_id is not None
            and (max_total_resume_attempts is None or resume_count < max_total_resume_attempts)
        )
        should_handoff = (
            failure.continuation_mode == "handoff"
            and effective_session_id is not None
            and (max_handoff_count is None or handoff_count < max_handoff_count)
        )
        archived_path: Path | None = None
        result_snapshot_path: Path | None = None
        next_invocation: _AttemptInvocation | None = None
        if should_resume or should_handoff:
            retryable_failure_count += 1
            result_snapshot_path = _snapshot_attempt_result(results_dir, backend=current_invocation.backend, attempt_index=attempt_index)
            archived_path = _archive_attempt_logs(results_dir, backend=current_invocation.backend, attempt_index=attempt_index)
            if should_resume:
                resume_count += 1
                next_invocation = _resume_invocation(
                    current_invocation,
                    config=config,
                    run_dir=run_dir,
                    session_id=effective_session_id,
                    trigger=failure.classification,
                )
                _append_backend_event(
                    run_dir,
                    backend=current_invocation.backend,
                    suffix="resume.scheduled",
                    source_session_id=effective_session_id,
                    trigger=failure.classification,
                    stop_reason=failure.stop_reason,
                    next_attempt=attempt_index + 1,
                )
            elif should_handoff:
                handoff_count += 1
                handoff_prompt = _build_handoff_prompt(
                    config,
                    backend=current_invocation.backend,
                    agent_workspace=agent_workspace,
                    source_session_id=effective_session_id,
                    trigger=failure.classification,
                    stop_reason=failure.stop_reason,
                )
                handoff_prompt_path = _write_handoff_prompt(
                    results_dir,
                    backend=current_invocation.backend,
                    attempt_index=attempt_index + 1,
                    prompt=handoff_prompt,
                )
                _append_backend_event(
                    run_dir,
                    backend=current_invocation.backend,
                    suffix="handoff.prompt_written",
                    source_session_id=effective_session_id,
                    trigger=failure.classification,
                    prompt_path=str(handoff_prompt_path),
                    next_attempt=attempt_index + 1,
                )
                _append_backend_event(
                    run_dir,
                    backend=current_invocation.backend,
                    suffix="handoff.scheduled",
                    source_session_id=effective_session_id,
                    trigger=failure.classification,
                    stop_reason=failure.stop_reason,
                    prompt_path=str(handoff_prompt_path),
                    next_attempt=attempt_index + 1,
                )
                next_invocation = _handoff_invocation(
                    current_invocation,
                    config=config,
                    run_dir=run_dir,
                    agent_workspace=agent_workspace,
                    session_id=effective_session_id,
                    trigger=failure.classification,
                    stop_reason=failure.stop_reason,
                    prompt_path=str(handoff_prompt_path),
                )

        attempts.append(
            _attempt_record(
                current_invocation,
                snapshot=snapshot,
                process_result=process_result,
                attempt_index=attempt_index,
                classification=failure.classification,
                retryable=failure.retryable,
                continuation_mode=failure.continuation_mode,
                stop_reason=failure.stop_reason,
                reason_excerpt=failure.reason_excerpt,
                events_path=str((archived_path or (results_dir / "agent_stdout.log")).name),
                result_snapshot_path=str(result_snapshot_path.name) if result_snapshot_path else "",
            )
        )

        if next_invocation is not None:
            current_invocation = next_invocation
            backoff_seconds = max(float(DEFAULT_CODEX_AUTO_RESUME_BACKOFF_SECONDS), 0.0)
            if current_invocation.mode == "resume" and backoff_seconds > 0:
                time.sleep(backoff_seconds)
            continue

        final_session_id = effective_session_id
        if failure.continuation_mode == "handoff" and max_handoff_count is not None and handoff_count >= max_handoff_count:
            final_error = (
                "context_window_handoff_limit_reached: "
                f"hit max fresh handoffs ({max_handoff_count}) after {failure.stop_reason}"
            )
        else:
            final_error = failure.stop_reason if validation_error is not None else (process_result.error or failure.stop_reason)
        break

    resume_meta_path: Path | None = None
    if (
        len(attempts) > 1
        or retryable_failure_count > 0
        or resume_count > 0
        or handoff_count > 0
        or any(str(item.get("continuation_mode") or "") in {"resume", "handoff"} for item in attempts)
    ):
        payload: dict[str, Any] = {
            "version": 2,
            "enabled": bool(auto_resume_enabled),
            "backend": config.agent_backend,
            "max_resume_attempts": int(raw_max_resume_attempts),
            "backoff_seconds": float(max(DEFAULT_CODEX_AUTO_RESUME_BACKOFF_SECONDS, 0.0)),
            "max_context_window_handoffs": int(raw_max_handoff_count),
            "attempts_total": int(len(attempts)),
            "resume_count": int(resume_count),
            "handoff_count": int(handoff_count),
            "retryable_failure_count": int(retryable_failure_count),
            "success": bool(final_result is not None),
            "final_session_id": final_session_id,
            "attempts": attempts,
        }
        if config.agent_backend == "codex":
            payload["final_thread_id"] = final_session_id
        resume_meta_path = _persist_resume_meta(results_dir, backend=config.agent_backend, payload=payload)

    handoff_drill_meta_path: Path | None = None
    if handoff_drill_state.config is not None:
        trigger_records = handoff_drill_state.trigger_records or []
        payload: dict[str, Any] = {
            "version": 2,
            "backend": config.agent_backend,
            "enabled": True,
            "trigger_after_accepted_actions": handoff_drill_state.config.after_accepted_actions,
            "max_triggers": handoff_drill_state.config.max_triggers,
            "triggered": bool(trigger_records),
            "trigger_count": len(trigger_records),
            "triggers": trigger_records,
            "pre_handoff_session_id": (
                attempts[0].get("result_session_id")
                if attempts and str(attempts[0].get("classification") or "") == "fresh_handoff_required"
                else None
            ),
            "post_handoff_session_id": (
                attempts[1].get("result_session_id")
                if len(attempts) > 1 and str(attempts[1].get("mode") or "") == "handoff"
                else None
            ),
            "completed": bool(final_result is not None),
            "final_session_id": final_session_id,
            "final_stop_reason": (
                str(final_result.get("stop_reason") or "")
                if final_result is not None
                else (final_error or "")
            ),
        }
        if config.agent_backend == "codex":
            payload.update(
                {
                    "pre_handoff_thread_id": payload.get("pre_handoff_session_id"),
                    "post_handoff_thread_id": payload.get("post_handoff_session_id"),
                    "final_thread_id": final_session_id,
                }
            )
        handoff_drill_meta_path = _write_handoff_drill_meta(results_dir, payload)

    if final_result is None:
        raise BackendError(
            final_error or f"{_backend_label(config.agent_backend)} failed without a final result",
            session_id=final_session_id,
            backend=config.agent_backend,
        )

    return {
        "backend": config.agent_backend,
        "session_id": final_session_id,
        "thread_id": final_session_id if config.agent_backend == "codex" else None,
        "final_result": final_result,
        "stdout_path": str(results_dir / "agent_stdout.log"),
        "final_result_path": str(results_dir / "agent_final_result.json"),
        "resume_meta_path": str(resume_meta_path) if resume_meta_path is not None else None,
        "handoff_drill_meta_path": str(handoff_drill_meta_path) if handoff_drill_meta_path is not None else None,
        "resume_count": int(resume_count),
        "handoff_count": int(handoff_count),
        "attempt_count": int(len(attempts)),
    }
