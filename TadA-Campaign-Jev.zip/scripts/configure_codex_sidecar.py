#!/usr/bin/env python3
"""Internal runner helper: bind a staged Codex home to the current sidecar."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo_root", type=Path)
    parser.add_argument("codex_home", type=Path)
    parser.add_argument("scheme", choices=("http",))
    parser.add_argument("relay_host")
    parser.add_argument("relay_port", type=int)
    parser.add_argument("--env-file", required=True, type=Path)
    args = parser.parse_args()

    sys.path.insert(0, str(args.repo_root.resolve() / "src"))
    from TadACampaign.codex_home import drop_table_sections, resolve_codex_home, set_root_key, set_table_key

    staged_home = args.codex_home.expanduser().resolve()
    if staged_home in {resolve_codex_home(), (Path.home() / ".codex").resolve()}:
        raise SystemExit("Refusing to modify the host Codex home")
    config_path = staged_home / "config.toml"
    if config_path.is_symlink() or (staged_home / "auth.json").exists():
        raise SystemExit("Sidecar staging must not link host config or contain OAuth credentials")
    token = os.environ.get("NUROUTER_PROCESS_SIDECAR_TOKEN", "")
    if not token or any(c in token for c in "\r\n\0"):
        raise SystemExit("A valid current-process NuRouter sidecar token is required")
    if not 1 <= args.relay_port <= 65535:
        raise SystemExit("Invalid relay port")

    text = config_path.read_text(encoding="utf-8") if config_path.is_file() else ""
    base_url = f"{args.scheme}://{args.relay_host}:{args.relay_port}"
    text = set_root_key(text, "model_provider", json.dumps("nurouter"))
    text = set_root_key(text, "chatgpt_base_url", json.dumps(f"{base_url}/proxy/backend-api"))
    # The local sidecar authenticates its Bearer token. It is not a ChatGPT
    # OAuth workspace; importing auth.json triggers incompatible discovery.
    text = drop_table_sections(text, "model_providers.nurouter")
    for key, value in {
        "name": json.dumps("NuRouter sidecar"),
        "base_url": json.dumps(f"{base_url}/proxy/backend-api/codex"),
        "wire_api": json.dumps("responses"),
        "env_key": json.dumps("NUROUTER_PROCESS_SIDECAR_TOKEN"),
        "requires_openai_auth": "false",
        "supports_websockets": "false",
        "request_max_retries": "2",
        "stream_max_retries": "2",
    }.items():
        text = set_table_key(text, "model_providers.nurouter", key, value)
    config_path.write_text(text, encoding="utf-8")
    config_path.chmod(0o600)
    # The runner supplies a mktemp path outside the repo and deletes it on exit.
    fd = os.open(args.env_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        os.fchmod(stream.fileno(), 0o600)
        stream.write(f"NUROUTER_PROCESS_SIDECAR_TOKEN={token}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
