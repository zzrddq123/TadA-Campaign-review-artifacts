#!/usr/bin/env python3
"""Small TCP relay for a host-loopback NuRouter sidecar and Docker bridge clients."""

from __future__ import annotations

import argparse
import json
import os
import select
import socket
import socketserver
import tempfile
from pathlib import Path
from urllib.parse import urlsplit


class RelayHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server = self.server
        try:
            upstream = socket.create_connection(server.target, timeout=10)
        except OSError:
            return
        sockets = (self.request, upstream)
        for sock in sockets:
            sock.settimeout(None)
        try:
            while True:
                readable, _, _ = select.select(sockets, (), (), 60)
                if not readable:
                    continue
                for source in readable:
                    data = source.recv(65536)
                    if not data:
                        return
                    destination = upstream if source is self.request else self.request
                    destination.sendall(data)
        except (OSError, ValueError):
            return
        finally:
            upstream.close()


class RelayServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target-url", required=True)
    parser.add_argument("--bind-host", required=True)
    parser.add_argument("--info-path", required=True, type=Path)
    args = parser.parse_args()

    target_url = urlsplit(args.target_url)
    if target_url.scheme != "http" or target_url.hostname not in {"127.0.0.1", "localhost", "::1"} or target_url.port is None:
        raise SystemExit("--target-url must be an http loopback URL with a port")
    target = (target_url.hostname, target_url.port)
    args.info_path.parent.mkdir(parents=True, exist_ok=True)

    with RelayServer((args.bind_host, 0), RelayHandler) as server:
        server.target = target
        fd, temp_name = tempfile.mkstemp(prefix="sidecar-relay-", dir=args.info_path.parent)
        os.close(fd)
        temp_path = Path(temp_name)
        try:
            temp_path.write_text(
                json.dumps({"bind_host": args.bind_host, "port": server.server_address[1]}) + "\n",
                encoding="utf-8",
            )
            os.replace(temp_path, args.info_path)
            args.info_path.chmod(0o600)
            server.serve_forever(poll_interval=0.2)
        finally:
            temp_path.unlink(missing_ok=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
