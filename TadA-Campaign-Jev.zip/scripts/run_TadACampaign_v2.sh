#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
INVOKE_CWD="$(pwd)"
DOCKERFILE="${REPO_ROOT}/docker/experiment.Dockerfile"
DEFAULT_IMAGE_TAG="tadacampaign-jev:latest"
DEFAULT_CODEX_TEMPLATE="${HOME}/.codex"
CONFIG_AGENTS_FILE="${REPO_ROOT}/config/AGENTS.md"
DEFAULT_CLAUDE_DIR="${HOME}/.claude"
DEFAULT_CLAUDE_STATE_FILE="${HOME}/.claude.json"
DEFAULT_OPENCODE_CONFIG_DIR="${HOME}/.config/opencode"
DEFAULT_OPENCODE_DATA_DIR="${HOME}/.local/share/opencode"
DEFAULT_SKILLS_MODE="planning-with-files"
DEFAULT_JEV_KEY_FILE="${REPO_ROOT}/provider_key.txt"
PROXY_ENV_VARS=(HTTP_PROXY HTTPS_PROXY http_proxy https_proxy NO_PROXY no_proxy)
INTERNAL_AGENT_ENV_VARS=(
  TADACAMPAIGN_HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS
  TADACAMPAIGN_HANDOFF_DRILL_MAX_TRIGGERS
  TADACAMPAIGN_AGENT_PROMPT_APPEND
)
# Codex workspace-write sandbox needs user namespaces and mount propagation inside the container.
FIXED_AGENT_DOCKER_ARGS=(--cap-add SYS_ADMIN --cap-add NET_ADMIN --security-opt seccomp=unconfined --security-opt apparmor=unconfined)

usage() {
  cat <<EOF
用法：
  bash scripts/run_TadACampaign_v2.sh <smoke|formal> [output-root]

说明：
  - 这是仓库唯一支持的运行入口
  - 固定执行模型：Docker 内运行 agent，host 侧运行 authoritative judge server
  - smoke 为短程预检 preset（60 days）
  - formal 为正式长程 preset（180 days）
  - 第二个参数可选，表示外层输出根目录；最终 run 会创建在该目录下
EOF
}

require_command() {
  local command_name="$1"
  if ! command -v "${command_name}" >/dev/null 2>&1; then
    echo "错误：缺少必需命令 '${command_name}'" >&2
    exit 1
  fi
}

require_file() {
  local file_path="$1"
  if [[ ! -f "${file_path}" ]]; then
    echo "错误：缺少必需文件 '${file_path}'" >&2
    exit 1
  fi
}

resolve_prepared_host_dir() {
  local config_path="$1"
  uv run --isolated python - "${REPO_ROOT}" "${config_path}" <<'PY'
from pathlib import Path
import sys
import tomllib

repo_root = Path(sys.argv[1]).resolve()
config_arg = Path(sys.argv[2])
config_path = config_arg if config_arg.is_absolute() else (repo_root / config_arg)
config_path = config_path.resolve()
payload = tomllib.loads(config_path.read_text(encoding="utf-8"))
prepared_root = Path(str(payload["prepared_root"])).expanduser()
if prepared_root.is_absolute():
    prepared_root = prepared_root.absolute()
else:
    prepared_root = (config_path.parent / prepared_root).absolute()
try:
    relative = prepared_root.relative_to(repo_root)
except ValueError as exc:
    raise SystemExit(f"prepared_root must stay under repo root: {prepared_root}") from exc
print(relative.as_posix())
PY
}

resolve_agent_backend() {
  local config_path="$1"
  uv run --isolated python - "${REPO_ROOT}" "${config_path}" <<'PY'
from pathlib import Path
import sys
import tomllib

repo_root = Path(sys.argv[1]).resolve()
config_arg = Path(sys.argv[2])
config_path = config_arg if config_arg.is_absolute() else (repo_root / config_arg)
config_path = config_path.resolve()
payload = tomllib.loads(config_path.read_text(encoding="utf-8"))
agent = payload.get("agent", {})
backend = str(agent.get("backend", "codex"))
print(backend)
PY
}

config_has_skill_surface() {
  local config_path="$1"
  uv run --isolated python - "${REPO_ROOT}" "${config_path}" <<'PY'
from pathlib import Path
import sys
import tomllib

repo_root = Path(sys.argv[1]).resolve()
config_arg = Path(sys.argv[2])
config_path = config_arg if config_arg.is_absolute() else (repo_root / config_arg)
config_path = config_path.resolve()
payload = tomllib.loads(config_path.read_text(encoding="utf-8"))
judge_payload = payload.get("judge", {})
raw_manifest = judge_payload.get("skill_market_manifest", payload.get("skill_market_manifest"))
print("1" if raw_manifest else "0")
PY
}

resolve_backend_egress_policy() {
  local backend="$1"
  local codex_home="$2"
  local judge_url="${3:-}"
  python3 - "${REPO_ROOT}" "${backend}" "${codex_home}" "${judge_url}" <<'PY'
from pathlib import Path
import json
import os
import sys

repo_root = Path(sys.argv[1]).resolve()
backend = sys.argv[2]
codex_home = Path(sys.argv[3]).resolve()
judge_url = sys.argv[4].strip()
sys.path.insert(0, str(repo_root / "src"))

from TadACampaign.network_policy import resolve_backend_egress_allowlist

payload = {"enforce": backend == "codex", "endpoints": []}
if backend == "codex":
    payload["endpoints"] = [
        {"host": endpoint.host, "port": endpoint.port}
        for endpoint in resolve_backend_egress_allowlist(
            backend,
            codex_home=codex_home,
            env=os.environ,
            extra_urls=[judge_url] if judge_url else None,
        )
    ]
print(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
PY
}

resolve_backend_proxy_bypass_hosts() {
  local backend="$1"
  local codex_home="$2"
  python3 - "${REPO_ROOT}" "${backend}" "${codex_home}" <<'PY'
from pathlib import Path
import sys

repo_root = Path(sys.argv[1]).resolve()
backend = sys.argv[2]
codex_home = Path(sys.argv[3]).resolve()
sys.path.insert(0, str(repo_root / "src"))

from TadACampaign.network_policy import resolve_backend_proxy_bypass_hosts

for host in resolve_backend_proxy_bypass_hosts(backend, codex_home=codex_home):
    print(host)
PY
}

merge_no_proxy_value() {
  local existing_value="${1:-}"
  shift || true
  python3 - "${REPO_ROOT}" "${existing_value}" "$@" <<'PY'
from pathlib import Path
import sys

repo_root = Path(sys.argv[1]).resolve()
existing_value = sys.argv[2]
hosts = sys.argv[3:]
sys.path.insert(0, str(repo_root / "src"))

from TadACampaign.network_policy import merge_no_proxy

print(merge_no_proxy(existing_value, *hosts))
PY
}

require_current_checkout_prepared_dir() {
  local relative_path="$1"
  local candidate="${REPO_ROOT}/${relative_path}"
  if [[ -d "${candidate}" ]]; then
    printf '%s\n' "${candidate}"
    return 0
  fi
  echo "错误：当前 checkout 缺少 prepared 数据目录 '${candidate}'" >&2
  echo "请先在当前仓库运行：uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared" >&2
  exit 1
}

write_runtime_config() {
  local source_config="$1"
  local prepared_root="$2"
  local judge_url="$3"
  local target_config="$4"
  local skill_market_manifest="${5:-}"
  python3 - "${source_config}" "${prepared_root}" "${judge_url}" "${target_config}" "${skill_market_manifest}" <<'PY'
from pathlib import Path
import json
import re
import sys

source_config = Path(sys.argv[1]).resolve()
prepared_root = Path(sys.argv[2]).resolve()
judge_url = sys.argv[3]
target_config = Path(sys.argv[4]).resolve()
skill_market_manifest = sys.argv[5].strip()

config_text = source_config.read_text(encoding="utf-8")
config_text, prepared_replacements = re.subn(
    r"(?m)^prepared_root\s*=.*$",
    f"prepared_root = {json.dumps(str(prepared_root))}",
    config_text,
    count=1,
)
if prepared_replacements != 1:
    raise SystemExit(f"Missing required config key 'prepared_root' in {source_config}")

judge_header = re.search(r"(?m)^\[judge\]\s*$", config_text)
if judge_header:
    if re.search(r"(?m)^server_url\s*=.*$", config_text):
        config_text = re.sub(
            r"(?m)^server_url\s*=.*$",
            f"server_url = {json.dumps(judge_url)}",
            config_text,
            count=1,
        )
    else:
        insert_at = judge_header.end()
        config_text = config_text[:insert_at] + f"\nserver_url = {json.dumps(judge_url)}" + config_text[insert_at:]
else:
    config_text = config_text.rstrip() + f"\n\n[judge]\nserver_url = {json.dumps(judge_url)}\n"

if skill_market_manifest:
    if re.search(r"(?m)^skill_market_manifest\s*=.*$", config_text):
        config_text = re.sub(
            r"(?m)^skill_market_manifest\s*=.*$",
            f"skill_market_manifest = {json.dumps(skill_market_manifest)}",
            config_text,
            count=1,
        )
    else:
        config_text = config_text.rstrip() + f"\nskill_market_manifest = {json.dumps(skill_market_manifest)}\n"

target_config.write_text(config_text if config_text.endswith("\n") else config_text + "\n", encoding="utf-8")
PY
}

resolve_run_dir_from_container_log() {
  local container_log="$1"
  local output_root="$2"
  python3 - "${container_log}" "${output_root}" <<'PY'
from pathlib import Path
import sys

container_log = Path(sys.argv[1]).resolve()
output_root = Path(sys.argv[2]).resolve()
lines = [line.strip() for line in container_log.read_text(encoding="utf-8").splitlines() if line.strip()]
for line in reversed(lines):
    if not line.startswith("/workspace/output/"):
        continue
    host_run_dir = output_root / Path(line).name
    if not host_run_dir.is_dir():
        raise SystemExit(f"Container reported run dir {line}, but host path is missing: {host_run_dir}")
    print(host_run_dir)
    raise SystemExit(0)
raise SystemExit(f"Could not resolve run dir from container log: {container_log}")
PY
}

chown_host_tree_to_host_user() {
  local host_dir="$1"
  local mount_path="$2"
  [[ -e "${host_dir}" ]] || return 0
  docker run --rm \
    -v "${host_dir}:${mount_path}" \
    "${DEFAULT_IMAGE_TAG}" \
    bash -lc "chown -R $(id -u):$(id -g) ${mount_path}"
}

chown_run_dir_to_host_user() {
  local run_dir="$1"
  chown_host_tree_to_host_user "${run_dir}" "/workspace/run"
}

validate_run() {
  local run_dir="$1"
  uv run python - "${run_dir}" <<'PY'
import sys
from pathlib import Path

from TadACampaign.runner import assert_run_succeeded

run_dir = Path(sys.argv[1]).resolve()
summary = assert_run_succeeded(run_dir)
print(summary.get("stop_reason", "unknown"))
PY
}

wait_for_container_judge_health() {
  local judge_url="$1"
  local max_attempts="${2:-30}"
  local probe_url="${judge_url%/}/healthz"
  local attempt
  for attempt in $(seq 1 "${max_attempts}"); do
    if docker run --rm \
      --add-host="${JUDGE_ADVERTISE_HOST}:host-gateway" \
      "${DOCKER_RUN_PROXY_ARGS[@]+"${DOCKER_RUN_PROXY_ARGS[@]}"}" \
      "${DEFAULT_IMAGE_TAG}" \
      bash -lc "curl -fsS --max-time 2 '${probe_url}' >/dev/null" \
      >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.2
  done
  echo "错误：judge-server 已就绪，但 experiment container 无法访问 ${probe_url}" >&2
  return 1
}

resolve_output_root() {
  local raw_path="$1"
  python3 - "${INVOKE_CWD}" "${raw_path}" <<'PY'
from pathlib import Path
import sys

invoke_cwd = Path(sys.argv[1]).resolve()
raw_path = Path(sys.argv[2]).expanduser()
if raw_path.is_absolute():
    print(raw_path.resolve())
else:
    print((invoke_cwd / raw_path).resolve())
PY
}

resolve_optional_file_path() {
  local raw_path="${1:-}"
  if [[ -z "${raw_path}" ]]; then
    return 0
  fi
  python3 - "${INVOKE_CWD}" "${raw_path}" <<'PY'
from pathlib import Path
import sys

invoke_cwd = Path(sys.argv[1]).resolve()
raw_path = Path(sys.argv[2]).expanduser()
resolved = raw_path.resolve() if raw_path.is_absolute() else (invoke_cwd / raw_path).resolve()
print(resolved)
PY
}

write_runtime_agents_file() {
  local source_path="$1"
  local output_path="$2"
  local skill_surface_enabled="$3"
  if [[ "${skill_surface_enabled}" == "1" ]]; then
    cp "${source_path}" "${output_path}"
    return
  fi
  cat >"${output_path}" <<'EOF'
# AGENTS.md - TadACampaign Runtime Codex Protocol

## 1. Language
- User interaction: Simplified Chinese only
- Internal work: English allowed for code, comments, and `.agent_record/` docs

## 2. Core Mandate
Use file-based planning and progress records for traceability.

Create `.agent_record/<THREAD_ID>/` where `<THREAD_ID>` is `CODEX_THREAD_ID`, or `main` if it is unavailable. Keep these files there:

| File | Purpose |
|------|---------|
| `task_plan.md` | Goals, phases, status |
| `progress.md` | Operation log and errors |
| `findings.md` | Key discoveries and decisions |

## 3. TadACampaign Runtime Rules
- You are running one full TadACampaign experiment, not returning a single-step JSON.
- Read `agent_playbook.md`, `available_actions.json`, `state.json`, and `history.json` before acting.
- The only supported way to change benchmark state is `./TadACampaign-agent-step`.
- Apart from maintaining `.agent_record/<THREAD_ID>/`, do not manually edit repository files, benchmark state files, or benchmark output artifacts.
- If `./TadACampaign-agent-step` returns `accepted=false`, read the rejection reason and choose a new legal move.
- In a suitable budget/time range, additional exploration can discover higher-activity proteins; higher confirmed activity can produce substantially higher reward and improve final cash.
- Prefer economically justified exploration that preserves a plausible path to `confirm_hit`; stop when the remaining actions no longer offer a credible risk-adjusted path to higher `cash_final`.

## 4. Completion
1. Finalize the docs in your specific `.agent_record/<THREAD_ID>` directory.
2. When the benchmark reaches terminal state, output exactly one JSON object on a single line with at least `status`, `stop_reason`, `action_count`, and `summary`.
3. Report in Simplified Chinese, referencing your specific `progress.md` or `findings.md`.
EOF
}

write_jev_env_file() {
  local target_path="$1"
  local key_file="$2"
  local variable_name=""
  if [[ -n "${AI_GATEWAY_API_KEY:-}" ]]; then
    variable_name="AI_GATEWAY_API_KEY"
  elif [[ -n "${TYPESAFE_API_KEY:-}" ]]; then
    variable_name="TYPESAFE_API_KEY"
  elif [[ -f "${key_file}" ]]; then
    variable_name="AI_GATEWAY_API_KEY"
  else
    return 0
  fi
  python3 - "${target_path}" "${key_file}" "${variable_name}" <<'PY'
from pathlib import Path
import os
import sys

output_path = Path(sys.argv[1])
key_file = Path(sys.argv[2])
variable_name = sys.argv[3]
value = os.environ.get(variable_name, "").strip()
if not value and variable_name == "AI_GATEWAY_API_KEY" and key_file.is_file():
    value = key_file.read_text(encoding="utf-8-sig").strip()
if not value or not value.isascii() or any(char.isspace() for char in value):
    raise SystemExit(f"Invalid {variable_name}: expected one nonempty ASCII token")
base_url = os.environ.get("JEV_BASE_URL", "").strip()
if base_url and (not base_url.isascii() or any(char.isspace() for char in base_url)):
    raise SystemExit("Invalid JEV_BASE_URL: expected an ASCII URL without whitespace")
lines = [f"{variable_name}={value}"]
if base_url:
    lines.append(f"JEV_BASE_URL={base_url}")
output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
output_path.chmod(0o600)
PY
}

start_nurouter_relay() {
  local target_url="$1"
  local bind_host="$2"
  local info_path="$3"
  local log_path="$4"
  nohup python3 "${REPO_ROOT}/scripts/nurouter_relay.py" \
    --target-url "${target_url}" \
    --bind-host "${bind_host}" \
    --info-path "${info_path}" \
    >"${log_path}" 2>&1 &
  SIDECAR_RELAY_PID=$!
  for _ in $(seq 1 100); do
    if [[ -s "${info_path}" ]]; then
      return 0
    fi
    if ! kill -0 "${SIDECAR_RELAY_PID}" >/dev/null 2>&1; then
      echo "错误：NuRouter sidecar relay 启动失败，日志见 ${log_path}" >&2
      return 1
    fi
    sleep 0.1
  done
  echo "错误：NuRouter sidecar relay 未及时就绪，日志见 ${log_path}" >&2
  return 1
}

write_agents_copy_proof() {
  local source_path="$1"
  local staged_path="$2"
  local output_path="$3"
  python3 - "${source_path}" "${staged_path}" "${output_path}" <<'PY'
from pathlib import Path
import hashlib
import json
import sys

source_path = Path(sys.argv[1]).resolve()
staged_path = Path(sys.argv[2]).resolve()
output_path = Path(sys.argv[3]).resolve()

source_bytes = source_path.read_bytes()
staged_bytes = staged_path.read_bytes()

payload = {
    "source_path": str(source_path),
    "staged_path": str(staged_path),
    "source_sha256": hashlib.sha256(source_bytes).hexdigest(),
    "staged_sha256": hashlib.sha256(staged_bytes).hexdigest(),
    "source_size_bytes": len(source_bytes),
    "staged_size_bytes": len(staged_bytes),
    "byte_identical": source_bytes == staged_bytes,
}
if not payload["byte_identical"]:
    raise SystemExit(f"Staged AGENTS differs from source: {source_path} != {staged_path}")
output_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY
}

capture_container_agents_inventory() {
  local output_path="$1"
  {
    printf '[container-visible]\n'
    docker run --rm \
      "${FIXED_AGENT_DOCKER_ARGS[@]}" \
      "${DOCKER_RUN_PROXY_ARGS[@]+"${DOCKER_RUN_PROXY_ARGS[@]}"}" \
      "${DOCKER_RUN_AGENT_ARGS[@]+"${DOCKER_RUN_AGENT_ARGS[@]}"}" \
      -v "${CONTAINER_OUTPUT_ROOT}:/workspace/output" \
      -v "${RUNTIME_CONFIG_PATH}:/workspace/runtime/runtime-config.toml:ro" \
      "${DEFAULT_IMAGE_TAG}" \
      bash -lc 'for base in /root/.codex /workspace/agent-home /root/.config/opencode /root/.local/share/opencode /app /workspace/runtime /workspace/output; do
        if [[ -e "$base" ]]; then
          find "$base" -type f -name AGENTS.md -print
        fi
      done | sort -u'
  } >"${output_path}"
}

append_run_agents_inventory() {
  local run_dir="$1"
  local output_path="$2"
  {
    printf '\n[run-dir]\n'
    find "${run_dir}" -type f -name AGENTS.md -print | sort -u
  } >>"${output_path}"
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -lt 1 || $# -gt 2 ]]; then
  usage >&2
  exit 1
fi

PRESET="$1"
OUTPUT_ROOT="$(resolve_output_root "${2:-${REPO_ROOT}/runs/TadACampaign-v2-$(date +%Y%m%d-%H%M%S)}")"
case "${PRESET}" in
  smoke)
    CONFIG_PATH="${REPO_ROOT}/config/experiments/TadACampaign_v2_jev_smoke.toml"
    ;;
  formal)
    CONFIG_PATH="${REPO_ROOT}/reproduce/paper_conditions/jev_k1_default_100k.toml"
    ;;
  *)
    echo "错误：未知 preset '${PRESET}'，只支持 smoke 或 formal" >&2
    exit 1
    ;;
esac
if [[ "${PRESET}" == "formal" && -n "${TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE:-}" ]]; then
  CONFIG_PATH="$(resolve_optional_file_path "${TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE}")"
  require_file "${CONFIG_PATH}"
elif [[ "${PRESET}" == "smoke" && -n "${TADACAMPAIGN_SMOKE_CONFIG_OVERRIDE:-}" ]]; then
  CONFIG_PATH="$(resolve_optional_file_path "${TADACAMPAIGN_SMOKE_CONFIG_OVERRIDE}")"
  require_file "${CONFIG_PATH}"
elif [[ "${PRESET}" == "smoke" && -n "${TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE:-}" ]]; then
  echo "错误：TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE 只支持 formal preset" >&2
  exit 1
fi

require_command docker
require_command python3
require_command uv
require_file "${CONFIG_AGENTS_FILE}"

cd "${REPO_ROOT}"
OUTPUT_ROOT="$(python3 - "${OUTPUT_ROOT}" <<'PY'
from pathlib import Path
import sys

print(Path(sys.argv[1]).expanduser().resolve())
PY
)"
mkdir -p "${OUTPUT_ROOT}"

RUN_ID="$(date +%Y%m%d-%H%M%S)-${PRESET}-$RANDOM"
RUNTIME_ROOT="${REPO_ROOT}/.runtime/TadACampaign_v2/${RUN_ID}"
CONTAINER_OUTPUT_ROOT="${RUNTIME_ROOT}/output"
AGENT_BACKEND="$(resolve_agent_backend "${CONFIG_PATH}")"
AGENT_STAGE_ROOT="${RUNTIME_ROOT}/agent_home"
CODEX_STAGE_DIR="${AGENT_STAGE_ROOT}/.codex"
CLAUDE_STAGE_DIR="${AGENT_STAGE_ROOT}/.claude"
CLAUDE_STAGE_STATE_FILE="${AGENT_STAGE_ROOT}/.claude.json"
OPENCODE_STAGE_CONFIG_DIR="${AGENT_STAGE_ROOT}/.config/opencode"
OPENCODE_STAGE_DATA_DIR="${AGENT_STAGE_ROOT}/.local/share/opencode"
CLAUDE_CONTAINER_HOME="/workspace/agent-home"
JUDGE_LOG="${RUNTIME_ROOT}/judge.log"
CONTAINER_LOG="${RUNTIME_ROOT}/container.log"
READY_FILE="${RUNTIME_ROOT}/judge-ready.json"
RUNTIME_CONFIG_PATH="${RUNTIME_ROOT}/runtime-config.toml"
AGENTS_COPY_PROOF_PATH="${RUNTIME_ROOT}/agents_copy_proof.json"
AGENTS_INVENTORY_PATH="${RUNTIME_ROOT}/agents_inventory.txt"
RUNTIME_AGENTS_FILE="${RUNTIME_ROOT}/AGENTS.md"
JEV_ENV_FILE=""
JEV_ENV_ARGS=()
SIDECAR_RELAY_PID=""
SIDECAR_ENV_FILE=""
SIDECAR_ENV_ARGS=()
SIDECAR_RELAY_INFO="${RUNTIME_ROOT}/sidecar-relay.json"
SIDECAR_RELAY_LOG="${RUNTIME_ROOT}/sidecar-relay.log"
SKILL_MARKET_MANIFEST_OVERRIDE="$(resolve_optional_file_path "${TADACAMPAIGN_SKILL_MARKET_MANIFEST:-}")"
SUCCESS=0
CONTAINER_NAME="TadACampaign-${RUN_ID}"
JUDGE_BIND_HOST="0.0.0.0"
JUDGE_ADVERTISE_HOST="host.docker.internal"
CONTAINER_RUNNER_PY=$'from pathlib import Path\nfrom TadACampaign.runner import run_experiment\nprint(run_experiment(Path("/workspace/runtime/runtime-config.toml"), output_root_override=Path("/workspace/output")))\n'

mkdir -p "${RUNTIME_ROOT}" "${CONTAINER_OUTPUT_ROOT}"
chmod 700 "${RUNTIME_ROOT}"

cleanup() {
  if docker ps --format '{{.Names}}' | grep -Fxq "${CONTAINER_NAME}" >/dev/null 2>&1; then
    docker rm -f "${CONTAINER_NAME}" >/dev/null 2>&1 || true
  fi
  if [[ -n "${JUDGE_PID:-}" ]] && kill -0 "${JUDGE_PID}" >/dev/null 2>&1; then
    kill "${JUDGE_PID}" >/dev/null 2>&1 || true
    wait "${JUDGE_PID}" >/dev/null 2>&1 || true
  fi
  rm -f "${JEV_ENV_FILE}" >/dev/null 2>&1 || true
  if [[ -n "${SIDECAR_RELAY_PID}" ]] && kill -0 "${SIDECAR_RELAY_PID}" >/dev/null 2>&1; then
    kill "${SIDECAR_RELAY_PID}" >/dev/null 2>&1 || true
    wait "${SIDECAR_RELAY_PID}" >/dev/null 2>&1 || true
  fi
  rm -f "${SIDECAR_ENV_FILE}" >/dev/null 2>&1 || true
  if [[ "${SUCCESS}" == "1" ]]; then
    rm -rf "${RUNTIME_ROOT}" >/dev/null 2>&1 || true
  else
    # Codex can create root-owned cache directories even on a failed run.
    chown_host_tree_to_host_user "${AGENT_STAGE_ROOT}" "/workspace/agent-home" >/dev/null 2>&1 || true
    rm -rf "${AGENT_STAGE_ROOT}" >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

JUDGE_ADMIN_TOKEN="$(python3 - <<'PY'
import secrets

print(secrets.token_hex(16))
PY
)"

PORT="$(python3 - <<'PY'
import socket

sock = socket.socket()
sock.bind(("0.0.0.0", 0))
print(sock.getsockname()[1])
sock.close()
PY
)"
JUDGE_URL="http://${JUDGE_ADVERTISE_HOST}:${PORT}"

PREPARED_RELATIVE_PATH="$(resolve_prepared_host_dir "${CONFIG_PATH}")"
PREPARED_HOST_DIR="$(require_current_checkout_prepared_dir "${PREPARED_RELATIVE_PATH}")"
if [[ -n "${SKILL_MARKET_MANIFEST_OVERRIDE}" ]]; then
  require_file "${SKILL_MARKET_MANIFEST_OVERRIDE}"
fi

write_runtime_config "${CONFIG_PATH}" "${PREPARED_HOST_DIR}" "${JUDGE_URL}" "${RUNTIME_CONFIG_PATH}" "${SKILL_MARKET_MANIFEST_OVERRIDE}"
SKILL_SURFACE_ENABLED="$(config_has_skill_surface "${RUNTIME_CONFIG_PATH}")"
CODEX_SKILLS_MODE="none"
if [[ "${SKILL_SURFACE_ENABLED}" == "1" ]]; then
  CODEX_SKILLS_MODE="${DEFAULT_SKILLS_MODE}"
fi
write_runtime_agents_file "${CONFIG_AGENTS_FILE}" "${RUNTIME_AGENTS_FILE}" "${SKILL_SURFACE_ENABLED}"

STAGE_ARGS=(
  --backend "${AGENT_BACKEND}"
  --target-root "${AGENT_STAGE_ROOT}"
  --clean-target
)
case "${AGENT_BACKEND}" in
  codex)
    CODEX_SNAPSHOT_CREDENTIALS=1
    if [[ -n "${NUROUTER_PROCESS_SIDECAR_URL:-}" ]]; then
      if [[ -z "${NUROUTER_PROCESS_SIDECAR_TOKEN:-}" ]]; then
        echo "错误：设置了 NuRouter sidecar URL，但缺少当前会话的 token" >&2
        exit 1
      fi
      CODEX_SNAPSHOT_CREDENTIALS=0
    fi
    STAGE_ARGS+=(
      --codex-source-dir "${DEFAULT_CODEX_TEMPLATE}"
      --snapshot-credentials "${CODEX_SNAPSHOT_CREDENTIALS}"
      --skills-mode "${CODEX_SKILLS_MODE}"
      --mcp-server-filter drop_all
      --global-agents-file "${RUNTIME_AGENTS_FILE}"
    )
    ;;
  claude)
    STAGE_ARGS+=(
      --claude-source-dir "${DEFAULT_CLAUDE_DIR}"
      --claude-state-file "${DEFAULT_CLAUDE_STATE_FILE}"
    )
    ;;
  opencode)
    STAGE_ARGS+=(
      --opencode-config-dir "${DEFAULT_OPENCODE_CONFIG_DIR}"
      --opencode-data-dir "${DEFAULT_OPENCODE_DATA_DIR}"
    )
    ;;
  policy)
    ;;
  *)
    echo "错误：未知 agent backend '${AGENT_BACKEND}'" >&2
    exit 1
    ;;
esac

uv run --isolated python "${REPO_ROOT}/scripts/stage_agent_cli_home.py" "${STAGE_ARGS[@]}"

# This machine's Codex may use a host-loopback NuRouter sidecar. A normal
# Docker bridge cannot reach 127.0.0.1, so relay only that TCP port through
# the Docker bridge and patch the staged config (never the user's ~/.codex).
if [[ "${AGENT_BACKEND}" == "codex" && -n "${NUROUTER_PROCESS_SIDECAR_URL:-}" ]]; then
  DOCKER_BRIDGE_GATEWAY="$(docker network inspect bridge --format '{{(index .IPAM.Config 0).Gateway}}')"
  if [[ -z "${DOCKER_BRIDGE_GATEWAY}" ]]; then
    echo "错误：无法解析 Docker bridge gateway，不能连接本机 NuRouter sidecar" >&2
    exit 1
  fi
  start_nurouter_relay "${NUROUTER_PROCESS_SIDECAR_URL}" "${DOCKER_BRIDGE_GATEWAY}" "${SIDECAR_RELAY_INFO}" "${SIDECAR_RELAY_LOG}"
  SIDECAR_RELAY_PORT="$(python3 - "${SIDECAR_RELAY_INFO}" <<'PY'
import json
import sys
print(json.loads(open(sys.argv[1], encoding="utf-8").read())["port"])
PY
)"
  SIDECAR_ENV_FILE="$(mktemp /tmp/TadACampaign-sidecar.XXXXXX)"
  python3 "${REPO_ROOT}/scripts/configure_codex_sidecar.py" \
    "${REPO_ROOT}" "${CODEX_STAGE_DIR}" http \
    "${JUDGE_ADVERTISE_HOST}" "${SIDECAR_RELAY_PORT}" --env-file "${SIDECAR_ENV_FILE}"
  SIDECAR_ENV_ARGS=(--env-file "${SIDECAR_ENV_FILE}")
fi
if [[ "${AGENT_BACKEND}" == "codex" ]]; then
  write_agents_copy_proof "${RUNTIME_AGENTS_FILE}" "${CODEX_STAGE_DIR}/AGENTS.md" "${AGENTS_COPY_PROOF_PATH}"
else
  python3 - "${AGENTS_COPY_PROOF_PATH}" "${AGENT_BACKEND}" <<'PY'
from pathlib import Path
import json
import sys

payload = {
    "source_path": None,
    "staged_path": None,
    "source_sha256": None,
    "staged_sha256": None,
    "source_size_bytes": None,
    "staged_size_bytes": None,
    "byte_identical": None,
    "backend": sys.argv[2],
    "note": "config/AGENTS.md is staged only for codex backend",
}
Path(sys.argv[1]).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY
fi

if [[ "${AGENT_BACKEND}" == "policy" ]]; then
  JEV_KEY_FILE="$(resolve_optional_file_path "${TADACAMPAIGN_JEV_KEY_FILE:-${DEFAULT_JEV_KEY_FILE}}")"
  JEV_ENV_FILE="$(mktemp /tmp/TadACampaign-jev.XXXXXX)"
  write_jev_env_file "${JEV_ENV_FILE}" "${JEV_KEY_FILE}"
  JEV_ENV_ARGS=(--env-file "${JEV_ENV_FILE}")
fi

DOCKER_BUILD_PROXY_ARGS=()
DOCKER_RUN_PROXY_ARGS=()
for env_name in "${PROXY_ENV_VARS[@]}"; do
  env_value="${!env_name:-}"
  if [[ -n "${env_value}" ]]; then
    container_value="${env_value}"
    case "${env_name}" in
      HTTP_PROXY|HTTPS_PROXY|http_proxy|https_proxy)
        # Host-side commands use 127.0.0.1/localhost; inside a container those
        # refer to the container itself, so rewrite to the Docker host alias.
        container_value="${container_value//127.0.0.1/host.docker.internal}"
        container_value="${container_value//localhost/host.docker.internal}"
        ;;
    esac
    DOCKER_BUILD_PROXY_ARGS+=(--build-arg "${env_name}=${container_value}")
    DOCKER_RUN_PROXY_ARGS+=(-e "${env_name}=${container_value}")
  fi
done
BACKEND_PROXY_BYPASS_HOSTS=()
while IFS= read -r bypass_host; do
  [[ -n "${bypass_host}" ]] || continue
  BACKEND_PROXY_BYPASS_HOSTS+=("${bypass_host}")
done < <(resolve_backend_proxy_bypass_hosts "${AGENT_BACKEND}" "${CODEX_STAGE_DIR}")
if [[ ${#BACKEND_PROXY_BYPASS_HOSTS[@]} -gt 0 ]]; then
  CONTAINER_NO_PROXY="$(merge_no_proxy_value "${NO_PROXY:-${no_proxy:-}}" "127.0.0.1" "localhost" "::1" "${JUDGE_ADVERTISE_HOST}" "${BACKEND_PROXY_BYPASS_HOSTS[@]}")"
else
  CONTAINER_NO_PROXY="$(merge_no_proxy_value "${NO_PROXY:-${no_proxy:-}}" "127.0.0.1" "localhost" "::1" "${JUDGE_ADVERTISE_HOST}")"
fi
DOCKER_RUN_PROXY_ARGS+=(-e "NO_PROXY=${CONTAINER_NO_PROXY}" -e "no_proxy=${CONTAINER_NO_PROXY}")
NETWORK_POLICY_JSON="$(resolve_backend_egress_policy "${AGENT_BACKEND}" "${CODEX_STAGE_DIR}" "${JUDGE_URL}")"
for env_name in "${INTERNAL_AGENT_ENV_VARS[@]}"; do
  env_value="${!env_name:-}"
  if [[ -n "${env_value}" ]]; then
    DOCKER_RUN_PROXY_ARGS+=(-e "${env_name}=${env_value}")
  fi
done
docker build \
  "${DOCKER_BUILD_PROXY_ARGS[@]+"${DOCKER_BUILD_PROXY_ARGS[@]}"}" \
  --build-arg "CODEX_VERSION=latest" \
  --build-arg "CLAUDE_CODE_VERSION=latest" \
  --build-arg "OPENCODE_VERSION=1.14.38" \
  -f "${DOCKERFILE}" \
  -t "${DEFAULT_IMAGE_TAG}" \
  "${REPO_ROOT}"

if [[ "${AGENT_BACKEND}" == "policy" ]]; then
  docker run --rm "${DEFAULT_IMAGE_TAG}" bash -lc '
  for tool in rg ps python3 uv; do
    command -v "$tool" >/dev/null 2>&1 || exit 1
  done
  '
else
  docker run --rm "${DEFAULT_IMAGE_TAG}" bash -lc '
  for tool in rg ps python3 uv codex claude opencode; do
    command -v "$tool" >/dev/null 2>&1 || exit 1
  done
  '
fi

nohup uv run python -m TadACampaign.runtime_entrypoints judge-server \
  --config "${RUNTIME_CONFIG_PATH}" \
  --host "${JUDGE_BIND_HOST}" \
  --advertise-host "${JUDGE_ADVERTISE_HOST}" \
  --port "${PORT}" \
  --audit-root "${RUNTIME_ROOT}/audit" \
  --admin-token "${JUDGE_ADMIN_TOKEN}" \
  --ready-file "${READY_FILE}" \
  >"${JUDGE_LOG}" 2>&1 &
JUDGE_PID=$!

for _ in $(seq 1 100); do
  if [[ -f "${READY_FILE}" ]]; then
    break
  fi
  if ! kill -0 "${JUDGE_PID}" >/dev/null 2>&1; then
    echo "错误：judge-server 提前退出，日志见 ${JUDGE_LOG}" >&2
    exit 1
  fi
  sleep 0.1
done

if [[ ! -f "${READY_FILE}" ]]; then
  echo "错误：judge-server 未在预期时间内就绪，日志见 ${JUDGE_LOG}" >&2
  exit 1
fi

wait_for_container_judge_health "${JUDGE_URL}"

DOCKER_RUN_AGENT_ARGS=()
case "${AGENT_BACKEND}" in
  codex)
    DOCKER_RUN_AGENT_ARGS+=(
      -v "${CODEX_STAGE_DIR}:/root/.codex:rw"
      -e CODEX_HOME=/root/.codex
      "${SIDECAR_ENV_ARGS[@]}"
    )
    ;;
  claude)
    DOCKER_RUN_AGENT_ARGS+=(
      --user "$(id -u):$(id -g)"
      -e "HOME=${CLAUDE_CONTAINER_HOME}"
      -v "${AGENT_STAGE_ROOT}:${CLAUDE_CONTAINER_HOME}:rw"
    )
    ;;
  opencode)
    DOCKER_RUN_AGENT_ARGS+=(
      -v "${OPENCODE_STAGE_CONFIG_DIR}:/root/.config/opencode:rw"
      -v "${OPENCODE_STAGE_DATA_DIR}:/root/.local/share/opencode:rw"
    )
    ;;
  policy)
    ;;
esac
capture_container_agents_inventory "${AGENTS_INVENTORY_PATH}"

if ! docker run --rm \
  --name "${CONTAINER_NAME}" \
  --add-host="${JUDGE_ADVERTISE_HOST}:host-gateway" \
  "${FIXED_AGENT_DOCKER_ARGS[@]}" \
  "${DOCKER_RUN_PROXY_ARGS[@]+"${DOCKER_RUN_PROXY_ARGS[@]}"}" \
  "${JEV_ENV_ARGS[@]+"${JEV_ENV_ARGS[@]}"}" \
  "${DOCKER_RUN_AGENT_ARGS[@]+"${DOCKER_RUN_AGENT_ARGS[@]}"}" \
  -v "${CONTAINER_OUTPUT_ROOT}:/workspace/output" \
  -v "${RUNTIME_CONFIG_PATH}:/workspace/runtime/runtime-config.toml:ro" \
  -e TADACAMPAIGN_JUDGE_ADMIN_TOKEN="${JUDGE_ADMIN_TOKEN}" \
  -e TADACAMPAIGN_EGRESS_POLICY_JSON="${NETWORK_POLICY_JSON}" \
  "${DEFAULT_IMAGE_TAG}" \
  bash -lc "cd /app && ./.venv/bin/python -m TadACampaign.container_firewall --policy-json \"\${TADACAMPAIGN_EGRESS_POLICY_JSON}\" && ./.venv/bin/python -c $(printf '%q' "${CONTAINER_RUNNER_PY}")" \
  >"${CONTAINER_LOG}" 2>&1; then
  echo "错误：experiment container 执行失败，日志见 ${CONTAINER_LOG}" >&2
  exit 1
fi

if [[ -n "${JUDGE_PID:-}" ]] && kill -0 "${JUDGE_PID}" >/dev/null 2>&1; then
  kill "${JUDGE_PID}" >/dev/null 2>&1 || true
  wait "${JUDGE_PID}" >/dev/null 2>&1 || true
fi

STAGED_RUN_DIR="$(resolve_run_dir_from_container_log "${CONTAINER_LOG}" "${CONTAINER_OUTPUT_ROOT}")"
RUN_DIR="${OUTPUT_ROOT}/$(basename "${STAGED_RUN_DIR}")"
if [[ -e "${RUN_DIR}" ]]; then
  echo "错误：目标 run 目录已存在 ${RUN_DIR}" >&2
  exit 1
fi
chown_run_dir_to_host_user "${STAGED_RUN_DIR}"
mv "${STAGED_RUN_DIR}" "${RUN_DIR}"
cp "${CONFIG_PATH}" "${RUN_DIR}/setting.toml"
validate_run "${RUN_DIR}" >/dev/null
append_run_agents_inventory "${RUN_DIR}" "${AGENTS_INVENTORY_PATH}"

mkdir -p "${RUN_DIR}/results/host_runtime"
cp "${JUDGE_LOG}" "${RUN_DIR}/results/host_runtime/judge.log"
cp "${CONTAINER_LOG}" "${RUN_DIR}/results/host_runtime/container.log"
cp "${RUNTIME_CONFIG_PATH}" "${RUN_DIR}/results/host_runtime/runtime-config.toml"
cp "${CONFIG_PATH}" "${RUN_DIR}/results/host_runtime/source-config.toml"
cp "${READY_FILE}" "${RUN_DIR}/results/host_runtime/judge-ready.json"
cp "${AGENTS_COPY_PROOF_PATH}" "${RUN_DIR}/results/host_runtime/agents_copy_proof.json"
cp "${AGENTS_INVENTORY_PATH}" "${RUN_DIR}/results/host_runtime/agents_inventory.txt"
chown_host_tree_to_host_user "${RUNTIME_ROOT}" "/workspace/runtime"

SUCCESS=1
printf '%s\n' "${RUN_DIR}"
