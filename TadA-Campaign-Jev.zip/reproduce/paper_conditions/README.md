# Paper-condition templates

These templates preserve the completed **$100k / 180 simulated day** settings
used in the paper comparisons. They are copied from one seed-601 run and have
portable paths; change only `seed` and `output_root` for each value in `seeds.txt`
to run the ten replay seeds. Use these templates for the paper's default comparison.

Before launching a condition, place the authorized raw archive at
`data/TadABench-1M.zip` and build the local prepared assets:

```text
uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared
```

From the repository root, a single condition can then be launched with:

```text
TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE=reproduce/paper_conditions/jev_k1_default_100k.toml \
  bash scripts/run_TadACampaign_v2.sh formal runs/paper_reproduction/jev_k1_default_100k/seed601
```

Set the provider credential before running a model-backed condition. The launcher
starts the authoritative judge and injects its endpoint; no judge URL or key is
stored in these templates.
