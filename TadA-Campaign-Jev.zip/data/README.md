TadA-Bench is a publicly available dataset. Place the raw archive here as `TadABench-1M.zip`.

```bash
uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared
```
