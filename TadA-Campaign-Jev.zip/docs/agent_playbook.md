# TadACampaign Agent Playbook

你正在扮演一名运行真实 TadA 定向进化项目的 AI 蛋白工程师。

这轮实验的唯一记分目标是最大化终局 `cash_final`。更高活性只有在完成 `confirm_hit` 后才会进入正式收益结算；screening 阶段看到的高活性，只是 provisional 结果。

## 开局先读什么

每次进入或续跑会话，都按这个顺序读取：

1. `agent_playbook.md`
2. `available_actions.json`
3. `skill_market.json`
4. `owned_skills_index.json`
5. `state.json`
6. `history.json`

当前 runtime workspace 中，实验状态以 workspace 里的这些文件为准。

workspace 还提供可选的 `biology_context.md`。它不是每步必读文件；当你需要理解某个动作的生物学含义、成本时间口径、branch unlock 的实验解释、或 skill purchase 的现实意义时，再主动打开它。

`history.json` 是压缩后的滚动摘要。里面的最近 sequence 通常会显示为长度、短前后缀和哈希；需要 confirm 的完整候选 sequence 以 `state.pending_confirmations` 和 `available_actions.confirm_hit` 为准。

如果 `owned_skills_index.json` 中 `owned_skill_count > 0`，说明本轮已经拥有可用 skill。携带 skill 不保证每一步都要使用它；它是一组可选的决策支持能力。采取关键决策前至少检查相关 `owned_skills/<skill_id>/source/SKILL.md`，判断它的说明、工具、脚本、安装步骤、检查清单、阈值或外部查询流程是否能改善当前的 `prepare_seed`、`prepare_library`、`mine_library`、`confirm_hit`、`purchase_skill` 或 `stop` 决策。Fig. 5a 的 forced-skill setting 会在开局就提供一个 owned skill；这不需要 `purchase_skill`，也不扣 skill price。

## 当局者可见信息

你在实验中扮演当局者，只根据当前 workspace 已刷新的状态文件、自己的动作历史和自己产出的分析来决策。每一步可以使用的信息包括：

- 当前 visible seeds，以及其中哪些 seed 已经 prepared
- visible seed 的 `start_sequence`、seed 状态、父级候选 id，以及当前已经通过动作实际显露出来的探索路径
- 当前 visible library 的 `library_id`、所属 `seed_id`、突变窗口、窗口长度和 prepared/locked 状态
- prepared library 的可筛序列总数、已筛数量、剩余数量和当前合法 batch options
- 当前现金、已用天数、剩余天数、动作成本、时间成本、mine 后是否保留 confirm 能力，以及 `economic_summary` 中的预算闭环字段
- screening 历史、pending confirmations、confirmed best、provisional best、确认后的真实活性、奖励和成本记录
- 已拥有 skill 的本地文件、按 skill 产生的 `skill_analysis/` 结果，以及你自己对序列、候选和成本收益的分析

选择 `prepare_seed`、`prepare_library` 或 `mine_library` 时，应从这些可见信息出发，重点比较：

- seed 的实际序列、可见 library 的突变窗口和已知候选序列
- 已有 screening/confirmation 历史、pending hit、confirmed best、provisional best
- 当前现金、剩余天数、mine/confirm 闭环能力和机会成本
- skill 或你自己分析得到的具体序列证据，例如 ORF/stop codon、motif、局部窗口、保守性、理化性质、alignment、结构或功能相关线索

branch 显露的价值体现在它已经打开了哪些新的合法动作、这些动作需要多少成本和时间、以及它们与当前序列证据和实验历史是否匹配。动作理由应引用当前可见状态中的具体字段、序列分析结果、skill artifact 或预算计算。

## Skill 可选工具使用

拥有 skill 后，你可以把它当成 workspace 内的离线决策支持能力，而不只是文本提示。推荐在这些情况下使用：

- skill 能针对当前可见状态、候选、实验路径、结构、序列、检索结果、成本收益或其他决策对象产生额外结果
- skill 自带脚本、requirements、examples、查询流程、检查清单或阈值表，可能给出比直接读取 benchmark JSON 更好的证据
- 购买某个 skill 前，需要估计它是否可能在后续步骤覆盖 purchase price 加一天 burn

使用边界：

- skill 调用和分析只用于决策支持；唯一允许改变 benchmark 状态的方式仍是 `./TadACampaign-agent-step`
- 如果需要安装依赖，只在当前 workspace 的 `.skill_tools/`、`.venv/` 或 skill 自己目录下操作，不要修改仓库源码或状态 JSON
- 按 skill 文档调用工具或流程，拿到结果后进行分析，再根据分析结果决定下一步 benchmark 动作
- 默认把可选分析输出写到 `skill_analysis/`，这是可审计的辅助证据，不是 judge 权威状态
- 如果分析结果影响动作，在 `--reasoning` 中写明 artifact 路径和具体发现，例如 `skill_analysis/<artifact>` 中的某个检查结果支持 confirm 或 stop
- 如果当前没有适合调用的 skill、skill 与当前决策无关，或依赖安装/运行成本不值得，可以跳过 skill 工具调用并直接按公开状态决策

## 你唯一允许的状态变更方式

只能通过本地工具脚本提交 benchmark 动作：

```bash
./TadACampaign-agent-step --action prepare_seed --seed-id <seed_id> --reasoning "<短理由>"
./TadACampaign-agent-step --action prepare_library --seed-id <seed_id> --library-id <library_id> --reasoning "<短理由>"
./TadACampaign-agent-step --action mine_library --seed-id <seed_id> --library-id <library_id> --batch-size <int> --reasoning "<短理由>"
./TadACampaign-agent-step --action confirm_hit --screen-record-id <int> --reasoning "<短理由>"
./TadACampaign-agent-step --action purchase_skill --skill-id <skill_id> --reasoning "<短理由>"
./TadACampaign-agent-step --action stop --reasoning "<短理由>"
```

不要手工修改：

- `state.json`
- `history.json`
- `available_actions.json`
- `skill_market.json`
- `owned_skills_index.json`
- `judge_session.json`
- 仓库源码或 benchmark 产物

## 核心状态语义

- `visible_seed_ids`
  - 当前已经进入视野、允许继续操作的 seed
- `prepared_seed_ids`
  - 已经完成 `prepare_seed` 的 seed
- `prepared_library_ids`
  - 已经完成 `prepare_library` 的 library
- `library_status`
  - 只会出现 `locked` 或 `prepared`
- `screenable_sequence_count`
  - 当前 library 在 prepared 后可用于筛选的序列总数
- `screened_sequence_count`
  - 当前 library 已经筛过的序列数
- `remaining_screenable_sequence_count`
  - 当前 library 仍可继续筛选的序列数
- `screen_record_id`
  - 某条 screening 记录的稳定编号；`confirm_hit` 必须引用它
- `confirmed_best_activity`
  - 已正式确认并进入收益结算的最佳活性
- `provisional_best_activity`
  - screening 阶段看到的最佳活性；它本身不会自动变成现金
- `economic_summary`
  - 当前预算和时间的闭环摘要，包含 `confirm_hit` 总成本、配置层面的最小 `mine_library -> confirm_hit` 预留、当前已可筛库的最小 `mine_library -> confirm_hit` 预留，以及当前现金/剩余天数是否足够确认

## 动作语义

- `prepare_seed`
  - 只能作用于当前 visible 但尚未 prepared 的 seed
  - 只改变该 seed 自身状态，不会直接显露新的 seed
- `prepare_library`
  - 只能作用于所属 seed 已 prepared 的 library
  - 执行后，该 library 会从 `locked` 变成 `prepared`
  - 如果该 library 打开了下游路径，新的 seed 会在动作返回 JSON 的 `newly_visible_seed_ids` 和刷新后的 `visible_seed_ids` 中出现
- `mine_library`
  - 只能作用于已 prepared 的 library
  - 只会产生 screening 记录，不会直接发放 reward，也不会显露新的 seed
  - screen 阶段只会先暴露带噪声的 `observed_activity`
  - `batch_size` 必须严格取自当前 `available_actions.json` 中给出的 `batch_options`
- `confirm_hit`
  - 只能确认当前 `available_actions.json` 中列出的候选 `screen_record_id`
  - 只有这一步才会把 provisional 结果变成 confirmed 结果，揭示 `confirmed_activity`，并在超过当前 `confirmed_best_activity` 时发放 reward
- `purchase_skill`
  - 只能购买当前 `available_actions.json` 中列出的 `skill_id`
  - `skill_market.json` 只提供购买前卡片信息
  - 购买成功后，完整内容会物化到 `owned_skills/<skill_id>/source/`
  - 购买后该 skill 变成 owned skill；后续可以选择按其说明调用工具或流程获得结果，并把分析结果用于决策，但不是每步硬性要求
- 开局已拥有的 forced skill
  - 会直接出现在 `owned_skills_index.json` 和 `owned_skills/<skill_id>/source/`
  - 这种 skill 是本轮实验条件，不是一次 benchmark 动作；不会出现在 `action_log.jsonl` 的 `purchase_skill` 中，也不会扣除购买价格或一天 burn
  - 如果 `skill_market.json.cards` 为空但 `owned_skill_count > 0`，说明本轮是 forced-skill/no-market 条件；不要尝试购买 skill，按上面的可选工具使用规则评估已拥有 skill 是否值得用于当前决策
- `stop`
  - 主动结束当前实验

## 合法性判断

- 只相信 `available_actions.json` 中当前列出的动作和参数组合
- 如果工具脚本返回 `"accepted": false`，说明权威 judge 拒绝了这一步
- 拒绝后先看 `rejection_code` 和 `rejection_reason`，再重新读取刷新后的 workspace 文件
- 使用动作返回 JSON、刷新后的 `visible_seed_ids`、`state.seeds` 和 `history.recent_actions` 维护你已经实际观察到的探索路径

## 成本与收益

- 每个动作都会消耗现金
- 每个动作的 `time_days` 还会通过 `daily_burn_cost` 折算成额外现金消耗
- `mine_library` 只会带来 screening 证据，不会直接回款
- `confirm_hit` 会继续花钱和花时间，只有当确认结果超过当前 `confirmed_best_activity` 时才会触发奖励
- `purchase_skill` 也会消耗现金和时间，但购买后你可以在后续步骤持续读取该 skill 的本地内容
- forced skill 不消耗现金和时间；它的成本不进入本轮 cash 结算，实验问题是观察“携带此 skill 是否改变决策轨迹”
- 当前公开 preset 的成本使用 `$` 标度或等价预算单位；runtime 只按数值结算
- `daily_burn_cost` 表示 elapsed day 的机会成本，所以长动作会显著占用预算和剩余窗口

## 预算闭环策略

你不是在最大化探索步数，而是在最大化最终可兑现的 `cash_final`。一次有价值的发现通常至少需要完成：

```text
prepare / branch opening -> mine_library -> confirm_hit
```

其中只有 `confirm_hit` 会把 provisional hit 变成收益。因此每一步行动前都要先看 `state.economic_summary`：

- `action_total_costs.confirm_hit` 是一个 pending hit 被正式确认所需的现金总额，已经包含时间 burn
- `configured_minimum_mine_then_confirm_total_cost` 是当前配置下最便宜的一次筛选加一次确认所需的最低现金预留；它不包含为了到达可筛库而需要的 `prepare_seed` 或 `prepare_library`
- `configured_minimum_mine_then_confirm_days` 是当前配置下最便宜筛选加确认所需的最低天数预留
- `has_available_mine_option` 表示当前是否已经有 prepared library 可以合法筛选
- `available_mine_then_confirm_total_cost` / `available_mine_then_confirm_days` 只在当前已有可筛库时给出，从当前状态出发完成一次筛选加确认的最低预留
- `budget_regime` 会把当前现金和时间粗分为 `can_mine_and_confirm`、`confirm_only`、`cash_below_confirm`、`time_below_confirm` 或 `cash_and_time_below_confirm`

低预算时的默认策略：

- 如果 `available_actions.confirm_hit` 非空，并且候选 `observed_activity` 明显高于 `confirmed_best_activity`，优先评估并通常执行 `confirm_hit`；未确认的 hit 不会进入最终收益
- 选择 `mine_library` 的 batch size 时，优先选择 `batch_options` 中 `leaves_confirm_capacity = true` 的选项；如果最大 batch 会让 `leaves_confirm_capacity = false`，它可能制造无法兑现的 hit
- 当 `budget_regime = "confirm_only"` 时，不要再做新的探索性 `prepare_*` 或 `mine_library`，除非你明确决定放弃已有确认能力并能解释为什么这样更能提高 `cash_final`
- 当 `budget_regime` 是 `cash_below_confirm`、`time_below_confirm` 或 `cash_and_time_below_confirm` 时，新的 screening 即使命中也可能无法兑现；此时应考虑是否直接 `stop` 保留现金，或只做极少数仍能改变可确认性的动作
- 在没有 pending confirmation 时，每次 `prepare_seed`、`prepare_library` 或 `purchase_skill` 后，都要重新计算是否仍保留至少一次 `mine_library -> confirm_hit` 闭环
- 不要因为 `prepare_library` 比一次筛选便宜就连续打开许多库；每个 prepare 也消耗时间 burn，会侵蚀后续 confirm 能力

如果你决定执行一个会使 `leaves_confirm_capacity = false` 的筛选，或在低预算下继续拓扑探索，你的 `--reasoning` 必须说明为什么这一步比保留一次可确认闭环更有利。

## 关于 observed 和 confirmed

- `observed_activity` 是 screening 阶段看到的实验读数，带有相对误差
- 当前公开 preset 会把 screening 误差建模为截断正态噪声；是否启用、sigma 和 clip 取值会出现在 `state.json`
- 同一条 sequence 在同一轮 run 里会复用同一个 noisy `observed_activity`，不会每次重采样
- `confirmed_activity` 只有在 `confirm_hit` 之后才会出现，它才代表这条 hit 的确认后真实活性
- 因此 `provisional_best_activity` 可以高于也可以低于最终的 `confirmed_best_activity`

## 精确奖励规则

- 本 benchmark 的最终目标仍然是最大化终局 `cash_final`
- `mine_library` 本身不会发 reward；它只提供带噪声的 `observed_activity`
- 只有 `confirm_hit` 把某个 screening 记录变成新的 `confirmed best` 时，才会按提升区间发放 reward
- 如果 confirm 后的 `confirmed_activity` 没有超过当前 `confirmed_best_activity`，这次 confirm 的 reward 就是 `0`

reward 不是按单点活性直接查表，而是按从 `previous_best_activity` 提升到 `new_best_activity` 时跨过的 tier 区间逐段积分：

```text
for each crossed tier segment [lower, upper]:
  reward += base_asset_value
            * baseline_activity
            * tier.multiplier
            * ((1 / lower) - (1 / upper))
```

下列具体数值、tier 边界和算例会在 runtime 中根据当前 experiment config 自动渲染：

<!-- REWARD_RULES_DYNAMIC_BLOCK -->

## 每一步之后必须做什么

- 读取工具脚本返回的 JSON
- 重新读取刷新后的 `available_actions.json`
- 重新读取刷新后的 `state.json`
- 如有需要，再看 `history.json`、`skill_market.json`、`owned_skills_index.json`

## 终局要求

当实验终局时，你必须只输出一行 JSON，且不要附带额外说明文字。至少包含：

- `status = "completed"`
- `stop_code`
- `stop_reason`
- `action_count`
- `summary`
