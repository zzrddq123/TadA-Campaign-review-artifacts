# Operator Playbook

## 1. 准备数据

```bash
uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared
```

这一步必须在当前 checkout 执行。公开启动脚本不会回退到其他 worktree 或其他 checkout 去寻找 `prepared/`。

## 2. 准备本地 skill market（可选）

如果你要启用离线 skill market，先基于本机上的上游 clone 构建本地 launch market：

```bash
uv run TadACampaign prepare-skill-market \
  --source-root /tmp/TadACampaign_skill_scout \
  --output-dir /tmp/TadACampaign_skill_market/launch21 \
  --force
```

这一步只会把最终 launch shortlist 复制到本地 market 目录，不会把上游 repo 暴露到 runtime 游戏面。当前 shortlist 包含 protein-design、structure/sequence analysis，以及 life-science-research 插件中的 routing、protein lookup、structure lookup、sequence similarity support。

简单手动运行时，可以通过环境变量把本地 market 注入公开启动脚本：

```bash
export TADACAMPAIGN_SKILL_MARKET_MANIFEST=/tmp/TadACampaign_skill_market/launch21/skill_market.json
```

不设置这个环境变量时，公开 preset 会按“无 market”运行。

正式论文 setting 更推荐把 manifest 写进 per-setting TOML。Fig. 5a forced-skill setting 会使用同一份 market manifest 作为 skill package 来源，但设置 `skill_market_enabled = false` 和 `initial_owned_skill_ids = ["<skill_id>"]`；agent 开局就能读取 `owned_skills/<skill_id>/source/SKILL.md`，不会出现 `purchase_skill` 动作，也不会扣购买成本。

无论是 forced skill 还是 market purchase，skill 的工具化使用都是可选行为。agent 可以按 `SKILL.md` 调用本地工具、脚本、检查流程或查询流程，分析返回结果并把输出放到 `process/agent_workspace/skill_analysis/`；没有该目录不自动判定为失败，但 operator 应记录“未观察到 tool-backed skill artifact”。

## 3. 运行公开 preset

短程预检：

```bash
bash scripts/run_TadACampaign_v2.sh smoke runs/quickstart-smoke
```

正式长程：

```bash
bash scripts/run_TadACampaign_v2.sh formal runs/quickstart-formal
```

脚本会自动完成以下编排：

1. 在 host 上启动 authoritative judge server
2. 按 `[agent].backend` stage 对应的安全 agent CLI home
3. 构建 experiment Docker 镜像
4. 在容器内运行 agent
5. 在隔离 staging 输出空间内完成本轮运行
6. 将最终 run 目录发布到你指定的输出根目录

## 4. 长程运行建议

`formal` preset 现在是 `180` 天 horizon，真实 wall-clock 运行通常仍会超过 3 分钟。按仓库执行约束，建议放进 `tmux`：

```bash
tmux new -s TadACampaign-formal
bash scripts/run_TadACampaign_v2.sh formal runs/formal
```

常用操作：

- 分离：`Ctrl-b d`
- 重新进入：`tmux attach -t TadACampaign-formal`

## 5. 结果检查

优先检查这些文件：

1. `results/summary.json`
2. `results/action_log.jsonl`
3. `results/screen_record_history.jsonl`
4. `results/rejection_log.jsonl`
5. `results/judge_audit.jsonl`
6. `results/runtime_timeline.jsonl`
7. `results/agent_stdout.log`

如果 backend 为 Codex，再补看：

8. `results/codex_events.jsonl`

如果 backend 为 policy baseline，`results/agent_stdout.log` 是每步 algorithmic policy decision 与 judge response 摘要；不会生成 Codex/OpenCode/Claude 事件流。

这版机制里要特别区分两类动作：

- `mine_library`
  - 代表 screen，只会产出 provisional discovery
- `confirm_hit`
  - 代表正式确认，只有它才能把 high-activity hit 兑现为 reward
- `purchase_skill`
  - 代表买断一个离线 skill；购买成功后，完整内容会出现在 `owned_skills/<skill_id>/source/`
- forced skill
  - 代表开局已拥有的离线 skill；完整内容从第一步前就存在，不是购买动作，不扣价格或时间
- `skill_analysis/`
  - 代表 agent 主动生成的可选 skill 分析产物；这是决策证据和审计线索，不是 judge 状态

最常见的红旗：

- `stop_reason` 以 `backend_error:` 开头
- `rejection_log.jsonl` 很长，说明 agent 反复试非法动作
- `agent_stdout.log` 或 `codex_events.jsonl` 显示 agent 长时间只在总结文件、不真正行动
- `summary.json` 里 `provisional_best_activity` 明显高于 `confirmed_best_activity`，但 agent 没有去 confirm

如果脚本成功结束，标准输出最后一行就是最终 run 目录。

`agent_workspace/biology_context.md` 会随每轮 workspace 一起提供。它是可选背景材料，适合分析行动含义或成本时间口径；不要把它当成新的状态文件或额外入口。

## 6. 公开运行边界

公开运行只支持以下两条命令：

```bash
bash scripts/run_TadACampaign_v2.sh smoke [output-root]
bash scripts/run_TadACampaign_v2.sh formal [output-root]
```

如果继续调整 experiment 参数，也要保持公开入口仍然只有这两条命令，不要把额外配置文件名、额外启动脚本、或旁路运行链路写回公开文档。

## 7. 网络排查

如需临时代理，请只在当前命令作用域内设置，并保留 localhost 直连：

```bash
export NO_PROXY=127.0.0.1,localhost,::1,host.docker.internal
export no_proxy=127.0.0.1,localhost,::1,host.docker.internal
```

当实验需要重新访问本机 judge 时，记得清掉代理：

```bash
unset HTTP_PROXY HTTPS_PROXY http_proxy https_proxy
```

## 8. 调参建议

最常改的公开字段包括：

- `initial_cash`
- `base_asset_value`
- `prepare_seed_cost`
- `prepare_library_cost`
- `confirm_hit_cost`
- `daily_burn_cost`
- `max_experiment_days`
- `seed`
- `variant`

当前内置 preset 已按真实实验口径重标定：`mine_batch_menu` 的 batch size 是变体吞吐量，`daily_burn_cost` 是 elapsed day 机会成本，`confirm_hit` 是 per-candidate 验证口径。调参时保持这些字段的含义，不要把 batch size 与 cost 混用。

改完以后，先跑一轮 `smoke`，确认 run 目录和结果产物完整，再决定是否继续跑正式长程。
