# Config Reference

本仓库只保留两份公开 preset：

- `config/experiments/TadACampaign_v2_smoke.toml`
- `config/experiments/TadACampaign_v2_formal.toml`

启动方式固定为：

```bash
bash scripts/run_TadACampaign_v2.sh smoke [output-root]
bash scripts/run_TadACampaign_v2.sh formal [output-root]
```

运行开始后，runner 会把本次实际使用的配置快照写到 run 目录里的 `config.toml`。这份快照会把路径解析成绝对路径，并补入运行时注入的 judge URL。

如果设置了 `TADACAMPAIGN_SKILL_MARKET_MANIFEST`，公开启动脚本也会把本地 skill market manifest 注入到这份运行时配置快照里。正式实验更推荐把 manifest 写进 per-setting TOML，这样 `setting.toml`、`config.toml` 和 operator card 都能直接审计 skill 条件。

正式论文实验建议不要反复编辑内置 formal preset，而是从 baseline 模板生成独立 setting：

```bash
python3 scripts/create_formal_setting.py \
  --output runs/paper_main/fig3_budget/cash100000/setting.toml \
  --run-output-root runs/paper_main/fig3_budget/cash100000 \
  --name TadACampaign_v2_formal_fig3_budget_cash100000 \
  --initial-cash 100000.0 \
  --agent-backend codex

export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE="$PWD/runs/paper_main/fig3_budget/cash100000/setting.toml"
bash scripts/run_TadACampaign_v2.sh formal runs/paper_main/fig3_budget/cash100000
```

`TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` 只对 `formal` preset 生效。这样仍然使用同一个公开启动命令，但每个 setting 都有独立 source TOML；最终 run 目录会保存 `setting.toml`、`results/host_runtime/source-config.toml` 和运行时 `config.toml`。

## 顶层字段

| 字段 | 是否必须 | 说明 |
| --- | --- | --- |
| `name` | 必须 | run 名称前缀。 |
| `prepared_root` | 必须 | prepared 数据目录。可写相对路径。 |
| `variant` | 必须 | `dna` 或 `protein`。 |
| `output_root` | 必须 | 默认输出根目录。 |
| `seed` | 必须 | 隐藏序列顺序使用的随机种子。 |
| `initial_cash` | 必须 | 起始现金。 |
| `base_asset_value` | 必须 | reward 公式中的资产基值。 |
| `baseline_activity` | 必须 | reward tier 的活性基线。 |
| `screening_noise_enabled` | 否 | 是否启用 screening 噪声；默认 `true`。 |
| `screening_noise_sigma` | 否 | screening 相对误差的正态分布标准差；默认 `0.10`。 |
| `screening_noise_clip` | 否 | screening 相对误差的截断上限；默认 `0.20`。 |
| `prepare_seed_cost` | 否 | prepare 一个 seed 的直接成本；默认 `0.0`。 |
| `prepare_seed_days` | 否 | prepare 一个 seed 消耗的天数；默认 `0.0`。 |
| `prepare_library_cost` | 必须 | prepare 一个 library 的直接成本。 |
| `prepare_library_days` | 必须 | prepare 一个 library 消耗的天数。 |
| `confirm_hit_cost` | 否 | confirm 一个 provisional hit 的直接成本；默认 `0.0`。 |
| `confirm_hit_days` | 否 | confirm 一个 provisional hit 消耗的天数；默认 `0.0`。 |
| `purchase_skill_days` | 否 | 购买一个 skill 消耗的天数；默认 `1.0`。 |
| `daily_burn_cost` | 必须 | 每个 elapsed day 的机会成本。 |
| `initial_visible_seeds` | 必须 | 初始可见 seed 列表。 |
| `initial_prepared_seeds` | 必须 | 初始已 prepared seed 列表。 |
| `max_experiment_days` | 必须 | benchmark 的固定时间 horizon。 |
| `agent_timeout_seconds` | 否 | 单次 backend attempt 超时；默认 `300`。 |
| `linear_issue` | 否 | 仅作追踪元数据。 |

## Skill Market 与 Forced Skill 字段

Skill 相关字段可放在顶层，也可放在 `[judge]`；如果两边都存在，以 `[judge]` 为准。正式论文 setting 推荐写在 `[judge]`。

| 字段 | 是否必须 | 说明 |
| --- | --- | --- |
| `skill_market_manifest` | 否 | 本地 skill market manifest 路径。Codex backend 支持该字段；其他 backend 不支持。 |
| `skill_market_enabled` | 否 | 是否向 agent 暴露 market cards 和 `purchase_skill` 动作；默认 `true`。 |
| `initial_owned_skill_ids` | 否 | run 开始时直接拥有并物化到 workspace 的 skill id 列表；必须同时设置 `skill_market_manifest`。 |

两种主要实验语义：

- Skill market 条件：设置 `skill_market_manifest`，保持 `skill_market_enabled = true`，并让 `initial_owned_skill_ids = []`。agent 可通过 `purchase_skill` 买 skill，购买会扣 price 和 `purchase_skill_days * daily_burn_cost`。
- Fig. 5a forced-skill 条件：设置 `skill_market_manifest`、`skill_market_enabled = false`、`initial_owned_skill_ids = ["<skill_id>"]`。agent 开局就能读取 `owned_skills/<skill_id>/source/SKILL.md`；market cards 为空，`purchase_skill` 不可用，不扣购买价格和时间。

这些字段只定义 skill 是否可见、是否可购买、是否开局已拥有。它们不强制 agent 运行某个工具，也不改变 action legality。拥有或购买 skill 后，agent 可以按 skill 文档调用工具或流程获得结果，把可选分析产物写到 `skill_analysis/`，再把具体发现用于后续动作 `reasoning`。

## `[[reward_tiers]]`

每个 reward tier 需要提供：

- `min_activity`
- `max_activity`
- `multiplier`

这些区间必须连续、无重叠，并覆盖从 `baseline_activity` 开始的全部区间。`max_activity` 可以写成 `"inf"`。

reward 只在 `confirm_hit` 让 `confirmed_best_activity` 变高时发放。它不是按新活性的单点值查表，而是把 `previous_best_activity` 到 `new_best_activity` 之间跨过的 tier segment 分开计算：

```text
for each crossed tier segment [lower, upper]:
  reward += base_asset_value
            * baseline_activity
            * tier.multiplier
            * ((1 / lower) - (1 / upper))
```

因此，`reward_tiers` 定义的是不同活性区间的边际价值权重。一次 confirmation 如果跨过多个 tier，会在每个区间分别按该区间的 `multiplier` 计算后相加。`mine_library` 只产生 noisy provisional signal，不会直接发 reward。

公开 preset 当前使用的经验校准版 tiers 为：

- `[1.0, 1.314) -> x1.5`
- `[1.314, 3.78) -> x2.4`
- `[3.78, 7.44) -> x18.0`
- `[7.44, inf) -> x30.0`

## `[[mine_batch_menu]]`

每个离散 batch 选项需要提供：

- `batch_size`
- `cost`
- `time_days`

约束如下：

- `mine_batch_menu` 必须非空
- `batch_size` 必须为正整数且不能重复
- 实验运行时会按 `batch_size` 排序

内置 preset 使用真实吞吐量口径：`batch_size` 是本次 screen 的变体数，不是价格。当前菜单为 `780`、`880`、`1020`、`1280`。

## `[agent]`

公开保留的 agent 配置字段包括 CLI agent 模型选择项，以及 Fig. 2 policy baseline 所需的 algorithmic policy 字段：

| 字段 | 说明 |
| --- | --- |
| `backend` | `codex`、`claude`、`opencode`、`policy`；仓库内置 preset 默认仍为 `codex` |
| `model` | 可选 |
| `profile` | 可选 |
| `reasoning_effort` | 可选 |
| `verbosity` | 可选 |
| `policy` | 仅当 `backend = "policy"` 时必填；algorithmic baseline 使用 `stop_now`、`blind_random_legal`、`budgeted_static_ranker`、`scout_confirm_stop`、`upside_greedy_explorer`、`empirical_ev_planner`；JEV-family structured decision policy 使用 `jev_k1`、`d1_k1` |
| `policy_params` | 可选 table；JEV-family policy 支持 `model`、`k`、`packaging`、`hierarchical`、`sampling`、`include_biology_context` 和 `biology_context_mode`；`model` 可为 `typesafe-ai/jev`、`liquid/d1` |

`policy` backend 是纯 Python backend，不启动 Codex/OpenCode/Claude。JEV-family policy 通过 TypeSafe-compatible Choice 接口请求结构化决策，再通过同一个 authoritative judge 和 `run_agent_step` 路径提交动作；因此仍然产生常规 `process/step_*`、`results/action_log.jsonl`、`results/summary.json` 和 cash curve。所有 policy 必须保持 semi-blind：只能使用当前公开 observation、legal actions、公开 history 和已发生 action response。`liquid/d1` 不是 free-tier 模型。

其余 backend 控制项不属于公开调用面。

## `[judge]`

公开保留的 judge 配置字段只有：

| 字段 | 说明 |
| --- | --- |
| `request_timeout_seconds` | judge HTTP 请求超时 |

运行时注入字段：

- `server_url`

`server_url` 由公开启动脚本注入，不需要手工填写。

## 内置 preset

仓库内置的两份 preset 共享同一套经济学与状态语义：

- `initial_cash = 100000.0`
- `base_asset_value = 100000.0`
- `baseline_activity = 1.0`
- `screening_noise_enabled = true`
- `screening_noise_sigma = 0.10`
- `screening_noise_clip = 0.20`
- `prepare_seed_cost = 365.0`
- `prepare_seed_days = 3.0`
- `prepare_library_cost = 142.0`
- `prepare_library_days = 2.0`
- `confirm_hit_cost = 467.0`
- `confirm_hit_days = 12.0`
- `purchase_skill_days = 1.0`
- `daily_burn_cost = 800.0`
- `mine_batch_menu = 780/880/1020/1280`

成本字段使用 `$` 标度或等价预算单位；runtime 只按数值结算。

两者的主要区别如下：

| 项目 | `TadACampaign_v2_smoke` | `TadACampaign_v2_formal` |
| --- | --- | --- |
| `max_experiment_days` | `60.0` | `180.0` |
| `agent_timeout_seconds` | `1800` | `3600` |

因此，`smoke` 适合做链路预检，`formal` 用于正式长程实验。
