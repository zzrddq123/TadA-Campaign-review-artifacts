# Output Reference

`scripts/run_TadACampaign_v2.sh` 成功执行后，会输出最终 run 目录路径。该目录的固定结构如下：

```text
<run-dir>/
  setting.toml
  config.toml
  process/
  results/
```

## `setting.toml`

这是本轮 run 使用的 source setting 副本。正式论文实验通常先从 `templates/TadACampaign_v2_formal_baseline.toml` 生成 `<output-root>/setting.toml`，再通过 `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` 启动 `formal` preset；launcher 会把该 source setting 复制到最终 run 目录根部。

如果没有设置 `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE`，这里会保存内置 preset 对应的 source config。

## `config.toml`

这是本次运行的配置快照。

常见变化：

- `prepared_root` 和 `output_root` 会被解析成绝对路径
- `[judge].server_url` 会被写成实际使用的 judge URL
- 这份文件才是该 run 的最终配置证据

## `process/`

`process/` 保存运行过程中的 workspace 和逐步动作记录。

常见内容：

- `agent_workspace/`
- `step_001/`
- `step_002/`

其中 `agent_workspace/` 会持续刷新，通常包含：

- `agent_playbook.md`
- `biology_context.md`
- `available_actions.json`
- `skill_market.json`
- `owned_skills_index.json`
- `owned_skills/`
- `state.json`
- `history.json`

`biology_context.md` 是可选参考文件，包含 action-level 生物学语义、成本时间口径和 branch 解释。它不是权威状态源；判断当前合法动作仍以 `available_actions.json` 与 `state.json` 为准。

如果 setting 使用 forced skill，`owned_skills_index.json` 在第一步之前就会显示 `owned_skill_count > 0`，对应文件会出现在 `owned_skills/<skill_id>/source/`。这种 skill 是开局实验条件，不会出现在 `action_log.jsonl` 的 `purchase_skill` 记录里，也不会增加 `total_skill_purchase_price_paid`。

如果 agent 调用 owned skill 的工具、脚本、检查流程或查询流程并生成了辅助结果，推荐把输出保存在：

- `skill_analysis/`

`skill_analysis/` 是 decision-support/audit artifact，不是 judge 权威状态；没有该目录不自动表示 run 失败，只表示没有观察到这种工具化 skill 使用产物。

如果 agent policy 启用了文件化规划，`agent_workspace/` 下还可能出现：

- `.agent_record/`
- `skill_analysis/`

每个 `step_<N>/` 目录通常包含：

- `state.json`
- `history.json`
- `available_actions.json`
- `skill_market.json`
- `owned_skills_index.json`
- `chosen_action.json`
- `judge_response.json`
- `step_meta.json`

`process/agent_workspace/history.json` 是滚动决策摘要。它会把最近动作和最近 screening 记录中的完整 sequence 压缩为 `sequence_length`、`sequence_prefix`、`sequence_suffix` 和 `sequence_sha256`，以便长程 formal run 不会因为反复读取大批量序列而耗尽上下文。确认候选仍会在 `state.pending_confirmations` 与 `available_actions.confirm_hit` 中保留完整 sequence。

`state.json` 中的 `economic_summary` 是面向 agent 的预算闭环摘要。它会列出确认成本、配置层面的最便宜筛选加确认预留、当前已有可筛库时的最便宜筛选加确认预留、当前确认余量和 `budget_regime`。`available_actions.json` 的 `mine_library.batch_options` 还会标注执行该 batch 后是否仍然留有现金和时间完成一次 `confirm_hit`。

`step_meta.json` 是 step 级 wall-clock 审计文件，记录：

- `step_started_at`
- `step_finished_at`
- `step_duration_seconds`
- `observation_request`
- `action_request`
- `accepted`
- `rejection_code`
- `rejection_reason`
- `terminal`
- `stop_code`
- `codex_thread_id`（仅 Codex 兼容别名）
- `agent_backend`
- `agent_session_id`

## `results/`

### 核心结果

- `summary.json`
- `summary.md`
- `action_log.jsonl`
- `screen_record_history.jsonl`
- `rejection_log.jsonl`
- `judge_audit.jsonl`
- `runtime_timeline.jsonl`
- `seed_manifest.json`
- `cash_curve.csv`
- `cash_curve.png`
- `agent_stdout.log`
- `agent_stderr.log`
- `agent_command.txt`
- `agent_final_result.json`

如果 operator 按 `docs/formal_experiment_prompts.md` 的论文实验流程整理结果，还会额外看到：

- `../EXPERIMENT_CARD.md`
- `operator_summary.md`
- `operator_event_log.csv`
- `operator_run_summary.csv`

这些不是 judge 权威状态文件，而是基于 `summary.json`、`action_log.jsonl`、`config.toml` 和可选 `process/agent_workspace/skill_analysis/` 生成的实验追踪与作图辅助产物。

### continuation 相关结果

如果发生 retry / resume / handoff，通常还会看到：

- `agent_resume_meta.json`
- `agent_stdout_attempt<N>.log`
- `agent_final_result_attempt<N>.json`
- `agent_handoff_prompt_attempt<N>.txt`

### Codex 兼容结果

如果 backend 为 Codex，通常还会看到：

- `codex_events.jsonl`
- `codex_final_result.json`
- `codex_command.txt`
- `codex_stderr.log`

### Policy baseline 结果

如果 backend 为 policy baseline，通常会看到：

- `agent_stdout.log`：每步 semi-blind policy decision 与 judge response 摘要
- `agent_final_result.json`：policy backend 的终局 JSON
- `jev_decisions.jsonl`：JEV-family structured decision 的模型、Choice 概率、usage、延迟和估算费用

Policy baseline 不会生成 `codex_events.jsonl`、`codex_final_result.json`、`opencode` 或 `claude` 事件流。

launcher 还会把 host 侧编排证据复制到：

- `results/host_runtime/judge.log`
- `results/host_runtime/container.log`
- `results/host_runtime/runtime-config.toml`
- `results/host_runtime/source-config.toml`
- `results/host_runtime/judge-ready.json`
- `results/host_runtime/agents_copy_proof.json`
- `results/host_runtime/agents_inventory.txt`

如果发生 continuation，还可能看到：

- `codex_resume_meta.json`
- `codex_events_attempt<N>.jsonl`
- `codex_final_result_attempt<N>.json`
- `codex_handoff_prompt_attempt<N>.txt`

## `summary.json` 常见字段

常见字段包括：

- `run_name`
- `variant`
- `execution_model`
- `cash_final`
- `reward_earned_total`
- `cost_paid_total`
- `confirmed_best_activity`
- `confirmed_best_sequence`
- `provisional_best_activity`
- `provisional_best_sequence`
- `skill_market_enabled`
- `skill_market_size`
- `skill_catalog_size`
- `initial_owned_skill_ids`
- `owned_skill_count`
- `owned_skill_ids`
- `total_skill_purchase_price_paid`
- `screening_noise_enabled`
- `screening_noise_sigma`
- `screening_noise_clip`
- `day_final`
- `request_count`
- `action_count`
- `rejected_action_count`
- `stop_code`
- `stop_reason`
- `judge_session_id`
- `judge_server_url`
- `run_started_at`
- `run_completed_at`
- `wall_clock_duration_seconds`
- `agent_backend`
- `agent_policy`（仅 policy backend）
- `agent_session_id`
- `agent_attempt_count`
- `agent_resume_count`
- `agent_handoff_count`
- `codex_attempt_count`（仅 Codex 兼容别名）
- `codex_resume_count`（仅 Codex 兼容别名）
- `codex_handoff_count`（仅 Codex 兼容别名）
- `codex_thread_id`（仅 Codex 兼容别名）
- `artifacts`

## `screen_record_history.jsonl`

这里记录每条 screening 结果的公开可见版本：

- 在 confirm 前，常见字段是 `screen_record_id`、`sequence`、`observed_activity`、`is_confirmed`
- 在 confirm 后，还会出现 `confirmed_activity`、`noise_fraction`、`is_confirmed_best`
- 不会在 confirm 前直接暴露 latent `true_activity`

## `rejection_log.jsonl`

这是被 judge 拒绝的动作列表，每行一个 JSON 对象。`rejection_reason` 保留可读说明，`rejection_code` 是稳定统计字段。常见 `rejection_code` 包括：

- `terminal_session`
- `unsupported_action`
- `missing_seed_id`
- `missing_library_id`
- `missing_batch_size`
- `missing_screen_record_id`
- `missing_skill_id`
- `unknown_seed`
- `unknown_library`
- `unknown_screen_record`
- `unknown_skill`
- `seed_not_visible`
- `seed_not_prepared`
- `seed_already_prepared`
- `library_not_prepared`
- `library_already_prepared`
- `library_exhausted`
- `illegal_batch_size`
- `screen_record_not_pending`
- `screen_record_already_confirmed`
- `cash_insufficient`
- `time_insufficient`
- `skill_market_disabled`
- `skill_already_owned`
- `runtime_error`

同一个 code 会跨 action 复用。例如 `cash_insufficient` 可能来自 `prepare_seed`、`mine_library`、`confirm_hit` 或 `purchase_skill`。

## `stop_code`

`summary.json`、终局 `state.json`、终局 payload 和相关 audit response 会保留 `stop_reason` 的可读文本，同时给出稳定的 `stop_code`：

- `agent_stop`：agent 主动提交 `stop`
- `max_experiment_days`：达到时间上限
- `time_insufficient`：剩余时间不足以执行任何合法动作
- `no_visible_path`：当前已无可继续操作的可见实验路径
- `cash_insufficient`：现金不足以执行任何合法动作
- `backend_error`：agent/backend 故障触发 force stop
- `force_stop`：非 backend-error 的管理员强制停止

## `judge_audit.jsonl`

这是 judge 侧的审计轨迹。常见事件包括：

- `session.created`
- `observation.fetched`
- `action.accepted`
- `action.rejected`
- `session.force_stopped`
- `skill.bundle.fetched`

每条记录还会带上：

- `request_received_at`
- `response_sent_at`
- `duration_seconds`

## `runtime_timeline.jsonl`

这是 runner/backend 侧的统一 wall-clock 事件流。典型事件包括：

- `run.started`
- `run.finished`
- `judge.request.started`
- `judge.request.finished`
- `agent.attempt.started`
- `agent.attempt.finished`
- `agent.resume.scheduled`
- `agent.handoff.prompt_written`
- `agent.handoff.scheduled`
- `backend.force_stop`

如果 backend 为 Codex，同一 run 里还会额外保留 `codex.*` 兼容事件。

它补足了 judge 审计之外的 client-side timing 与 agent attempt 信息。

## continuation 产物

如果一次 run 发生了同线程继续或 fresh handoff，最重要的额外文件是：

- `agent_resume_meta.json`
- `runtime_timeline.jsonl`
- `agent_stdout_attempt<N>.log`

如果 backend 为 Codex，再额外结合：

- `codex_resume_meta.json`
- `codex_events_attempt<N>.jsonl`

必要时再结合对应 `step_<N>/step_meta.json` 复原 step 级时间线。

## 失败判定

如果 `summary.json` 中的 `stop_reason` 以 `backend_error:` 开头，说明实验因为 agent/backend 故障而提前结束，不应视为成功完成。
