# Trust Model

TadACampaign 只支持一个信任边界模型：

- host 侧 authoritative judge 持有 benchmark 数据和状态权威
- Docker 内 agent 通过 HTTP judge 接口推进实验
- agent 不直接读取 prepared benchmark 数据

## 1. Host Judge

host judge 负责：

- 加载 `prepared/` 数据
- 创建和维护 session
- 判定动作是否合法
- 结算时间、成本、奖励和终止条件
- 导出审计日志和最终 summary

judge 是唯一权威状态源。

## 2. Docker Agent

Docker 容器里的 agent 会接触到当前 run 的运行材料，包括：

- `/app` 下的仓库代码与运行时依赖
- `~/.codex/AGENTS.md`
- `agent_playbook.md`
- `state.json`
- `available_actions.json`
- `history.json`
- helper 脚本
- 当前 run 的 runtime staging
- 当前 run 的隔离输出工作区

agent 不应该也不需要直接接触：

- prepared parquet 数据
- host judge 内存态
- 同一 `output_root` 下的历史 run 结果目录
- 仓库源码中的旁路运行逻辑

## 3. Public Launch Script Responsibility

`scripts/run_TadACampaign_v2.sh` 负责把两侧安全地连起来：

1. 选择公开 preset
2. 启动 host judge
3. 注入运行时 `server_url`
4. 按 `[agent].backend` stage 安全的 CLI home；当 backend 为 `codex` 时，还会将 `config/AGENTS.md` 原样 stage 到容器内 `~/.codex/AGENTS.md`
5. 为当前 run 创建隔离 staging 输出目录
6. 启动 Docker agent
7. 将当前 run 的最终产物发布回用户指定的 `output_root`

这也是仓库唯一支持的公开运行路径。

## 4. 安全收益

这个固定模型解决的核心问题是：

- agent 无法依赖 host 上的 benchmark 数据文件做旁路读取
- judge 侧状态演化可完整审计
- 结果不再取决于“是本地模式还是 server 模式”
- 文档、脚本、测试和配置都只指向同一条链路，避免使用者误以为存在多个等价入口
