# TadACampaign 游戏规则

## 一句话版本

TadACampaign V2 把 TadA 定向进化项目抽象成一个带预算、时间、分支显露、screening 成本、确认成本和 skill 购买成本的长期实验经营 benchmark。最终分数只看 `cash_final`。

## 1. 基本对象

canonical V2 把源实验数据重组为一个通过 library action 逐步显露的探索图。实验从一个可见背景开始；每个新显露的背景都有自己的起始序列和突变窗口。更下游、更深的背景来自改良变体，因此相对于祖先背景具有更高的活性潜力先验，但不保证一定最好。每次 `prepare_library` 后，动作返回 JSON 的 `newly_visible_seed_ids` 和刷新后的 `visible_seed_ids` 会记录这一步实际打开的新背景；agent 用已经发生的动作结果维护当前探索树。

Agent 作为当局者，应根据当前可见序列、突变窗口、screening/confirmation 历史、预算闭环能力、已经通过动作显露出来的探索路径和可用 skill 分析来决定下一步。

fresh session 的默认初始状态是：

- `initial_visible_seeds = ["seed1"]`
- `initial_prepared_seeds = []`

## 2. Agent 作为当局者知道什么

authoritative judge 会在 workspace 中持续刷新这些文件：

- `state.json`
- `available_actions.json`
- `history.json`
- `skill_market.json`
- `owned_skills_index.json`

当前 runtime workspace 中，实验状态以这些文件为准。

workspace 还会提供可选参考文件 `biology_context.md`。它不是权威状态源，也不会在每一步重复展开；agent 可以在需要理解实验语义、成本时间口径或 branch 背景时主动读取。

workspace 中的 owned skill 可以作为可选决策支持能力使用。agent 可以按 `owned_skills/<skill_id>/source/SKILL.md` 的说明调用工具、脚本、检查流程或查询流程，分析返回结果后再决定下一步动作。可选输出建议保存在 `skill_analysis/`；这些输出不会改变 judge 状态或动作合法性。

每一步决策中，agent 可以使用的信息是：

- 当前 visible seeds，以及其中哪些 seed 已经 prepared
- visible seed 的 `start_sequence`、seed 状态、父级候选 id，以及当前已经通过动作实际显露出来的探索路径
- 当前 visible library 的 `library_id`、所属 `seed_id`、突变窗口、窗口长度和 prepared/locked 状态
- prepared library 的可筛序列总数、已筛数量、剩余数量和当前合法 batch options
- 当前现金、已用天数、剩余天数、动作成本、时间成本、mine 后是否保留 confirm 能力，以及 `economic_summary` 中的预算闭环字段
- screening 历史、pending confirmations、confirmed best、provisional best、确认后的真实活性、奖励和成本记录
- 已拥有 skill 的本地文件、按 skill 产生的 `skill_analysis/` 结果，以及 agent 自己对序列、候选和成本收益的分析

### `state.json`

核心字段包括：

- `current_cash`
- `elapsed_day`
- `remaining_days`
- `confirmed_best_activity`
- `confirmed_best_sequence`
- `provisional_best_activity`
- `provisional_best_sequence`
- `visible_seed_ids`
- `prepared_seed_ids`
- `prepared_library_ids`
- `screen_record_count`
- `confirmed_screen_record_count`
- `pending_confirmation_count`
- `pending_confirmations`
- `economic_summary`
- `skill_market_enabled`
- `skill_market_size`
- `skill_catalog_size`
- `initial_owned_skill_ids`
- `owned_skill_count`
- `owned_skill_ids`
- `total_skill_purchase_price_paid`
- `action_count`
- `rejected_action_count`
- `request_count`
- `total_reward_earned`
- `total_cost_paid`
- `stop_code`
- `stop_reason`
- `screening_noise_enabled`
- `screening_noise_sigma`
- `screening_noise_clip`
- `seeds`

其中每个 seed payload 都会提供：

- `seed_id`
- `parent_seed_candidate_ids`
- `parent_library_candidate_ids`
- `start_sequence`
- `seed_status`
- `libraries`

每个 library payload 都会提供：

- `library_id`
- `mutable_interval_aa`
- `interval_length_aa`
- `library_status`

当 `library_status = "prepared"` 时，还会额外提供：

- `screenable_sequence_count`
- `screened_sequence_count`
- `remaining_screenable_sequence_count`

### `available_actions.json`

结构固定为：

- `prepare_seed`: 数组
- `prepare_library`: 数组
- `mine_library`: 数组
- `confirm_hit`: 数组
- `purchase_skill`: 数组
- `stop`: 单个对象

需要特别注意：

- prepared library 会在 `state.json` 和 `available_actions.json` 中提供 `screenable_sequence_count`、`screened_sequence_count` 和 `remaining_screenable_sequence_count`
- `mine_library` 只能使用离散 `batch_options`
- `confirm_hit` 只能使用当前列出的 `screen_record_id`
- `purchase_skill` 只能使用当前列出的 `skill_id`
- 当前公开 preset 的 `mine_library` batch size 表示本次 screen 的变体吞吐量，菜单为 `780`、`880`、`1020`、`1280`

### `history.json`

当前会暴露：

- `recent_actions`
- `recent_screen_records`
- `recent_rejections`

screening 记录的稳定编号叫 `screen_record_id`，不会再使用其他命名。
`history.json` 是给 agent 长跑决策用的滚动摘要，不是完整实验归档。为了避免大批量 screening 后反复展开长序列，`recent_screen_records` 与 `recent_actions` 中的 sequence 会被压缩为 `sequence_length`、`sequence_prefix`、`sequence_suffix` 和 `sequence_sha256`。需要确认的候选仍会在 `state.pending_confirmations` 与 `available_actions.confirm_hit` 中保留完整 sequence；完整公开 screening 记录会写入最终 `results/screen_record_history.jsonl`。
在 confirm 前，公开 history 只会暴露 `observed_activity`；确认后才会追加 `confirmed_activity` 和 `noise_fraction`。

## 3. Library 筛选池语义

当一个 library 被 prepared 后，agent 会看到它的可筛序列总数、已筛数量和剩余数量。执行 `mine_library` 后，动作返回 JSON、刷新后的 `state.pending_confirmations`、`available_actions.confirm_hit` 和 `history.recent_screen_records` 会显示本次筛选产生的公开 screening 记录。

每个 library 背后都有一个按固定顺序排列的可筛序列池。构造规则是：

1. 该行序列在 `mutable_interval_aa` 之外必须与所属 seed 的 `start_sequence` 一致
2. 同一 library 内的条目会按 `config.seed + library key` 进行确定性打乱

因此：

- 同一份 config 与同一份 prepared 数据会得到完全一致的 library 内部顺序
- `mine_library` 是沿着这个固定顺序向前取样，不会回填
- sequence 的确认活性会影响 reward，但不会直接显露新的 seed
- screening 阶段看到的是带噪声的 `observed_activity`，不是最终确认值

## 4. 六类动作

### `prepare_seed`

前置条件：

- 该 seed 已 visible
- 该 seed 尚未 prepared

效果：

- 扣除 `prepare_seed` 的现金与天数成本
- 将该 seed 标记为 prepared
- 使该 seed 下面的 library 有资格进入 `prepare_library` 候选

### `prepare_library`

前置条件：

- 所属 seed 已 visible
- 所属 seed 已 prepared
- 该 library 当前处于 `locked`

效果：

- 扣除 `prepare_library` 的现金与天数成本
- 将该 library 标记为 `prepared`
- 如果该 library 打开了下游路径，动作返回 JSON 的 `newly_visible_seed_ids` 和刷新后的 `visible_seed_ids` 会显示实际新增 seed
- 从这一步开始，该 library 的 `screenable_sequence_count`、`screened_sequence_count`、`remaining_screenable_sequence_count` 才会出现在状态中

### `mine_library`

前置条件：

- 所属 seed 已 visible
- 所属 seed 已 prepared
- 该 library 已 prepared
- `batch_size` 必须严格来自当前 `batch_options`

效果：

- 扣除本次 `batch_option` 对应的现金与天数成本
- 从该 library 的固定顺序序列池中取出一个 batch
- 将每条结果写入 `screen_record_history`
- 为每条 sequence 生成稳定的 noisy `observed_activity`
- 更新 `provisional_best_activity` 与 `provisional_best_sequence`
- 如果 batch 中出现超过当前 `confirmed_best_activity` 的新候选，`confirm_hit` 中会出现对应 `screen_record_id`
- `mine_library` 本身不会直接返奖
- 如果某个 prepared library 的剩余可筛序列数小于最小 batch size，它不会出现在 `mine_library` 候选中；但 prepare 该 library 仍可能因为 branch unlock 而有价值

### `confirm_hit`

前置条件：

- `screen_record_id` 必须出现在当前 `confirm_hit` 候选里
- 剩余时间足以执行确认动作
- 该 `screen_record_id` 尚未被确认

效果：

- 扣除 `confirm_hit` 的现金与天数成本
- 将该 screening 记录标记为 confirmed，并揭示其 `confirmed_activity`
- 如果其确认活性超过当前 `confirmed_best_activity`，则更新：
  - `confirmed_best_activity`
  - `confirmed_best_sequence`
- 根据 reward tiers 发放奖励
- `confirm_hit` 是 per-candidate 口径，每次只确认一个当前列出的 `screen_record_id`；确认成本一旦启动就已经发生，候选是否超过当前 best 只影响 reward 和 confirmed best 更新

### `purchase_skill`

前置条件：

- `skill_id` 必须出现在当前 `purchase_skill` 候选里
- 剩余时间足以执行购买动作
- 当前尚未拥有该 skill

效果：

- 扣除该 skill 的固定价格与购买耗时
- 将完整 skill 内容物化到 `owned_skills/<skill_id>/source/`
- 后续所有步骤都可以继续读取这份本地内容
- 购买后 agent 可以选择按 skill 的说明调用工具或流程获得结果，并把分析结果用于后续决策；是否调用工具不是动作合法性的硬条件

### 开局 forced skill

某些正式 setting 会在开局直接提供一个已拥有 skill：

- `initial_owned_skill_ids` 会列出开局已拥有的 skill
- `owned_skills_index.json` 在第一步前就会显示该 skill
- 完整内容会直接物化到 `owned_skills/<skill_id>/source/`
- 这不是 `purchase_skill` 动作，不扣 skill price，也不消耗 `purchase_skill_days`
- 如果 `skill_market_enabled = false`，`skill_market.json.cards` 为空且 `purchase_skill` 不合法
- forced skill 的语义是“开局携带这项能力”。agent 可以调用它获取结果并分析后用于决策，但 Fig. 5a 不保证每个 run 都会实际产生 skill tool artifact；这正是需要审计的行为差异之一

### `stop`

效果：

- 立即终止 episode
- `stop_reason` 记录为 agent 给出的理由，或系统给出的终局原因

## 5. 收益与成本

所有动作都会产生直接成本；所有耗时还会通过 `daily_burn_cost` 计入现金支出。

公开 preset 使用 `$` 标度或等价预算单位。数值被校准到真实实验的试剂、服务和机会成本量级，但 benchmark 内部只按数值结算。当前口径中，`daily_burn_cost` 表示每个 elapsed day 的机会成本。

当前内置 preset 的 action-level 经济参数为：

| 动作 | 直接成本 | 天数 |
| --- | ---: | ---: |
| `prepare_seed` | `$365` | `3` |
| `prepare_library` | `$142` | `2` |
| `mine_library` | `$1200-$1400` | `9-10` |
| `confirm_hit` | `$467` | `12` |
| `purchase_skill` | market price | `1` |
| `stop` | `$0` | `0` |

只有在 `confirm_hit` 之后，且新的确认活性超过当前 `confirmed_best_activity` 时，才会发放 reward。`provisional_best_activity` 只表示你在 screening 中看到了好的候选，不代表已经回款。

reward 按 `reward_tiers` 做分段计算：

```text
for each crossed tier segment [lower, upper]:
  reward += base_asset_value
            * baseline_activity
            * tier.multiplier
            * ((1 / lower) - (1 / upper))
```

这意味着：

- 高 tier 的边际提升通常更值钱
- `mine_library` 看到强 hit 不等于已经赚钱
- 是否 confirm 需要同时考虑 reward 增量、确认成本和时间 burn

### 预算闭环

TadACampaign 的低预算设定不是要求 agent 尽可能多探索，而是要求 agent 在有限现金和时间里保留把发现兑现成 confirmed best 的能力。

`state.economic_summary` 会把当前经济状态集中暴露出来：

- `action_total_costs.confirm_hit`：确认一个 pending hit 的总现金成本，包含 `confirm_hit_days * daily_burn_cost`
- `configured_minimum_mine_then_confirm_total_cost`：当前配置下完成一次最便宜筛选加一次确认的最低总现金预留；它不包含为了到达可筛库而需要的 `prepare_seed` 或 `prepare_library`
- `configured_minimum_mine_then_confirm_days`：当前配置下完成一次最便宜筛选加一次确认的最低天数预留
- `has_available_mine_option`：当前是否已经有 prepared library 可以筛选
- `available_mine_then_confirm_total_cost` / `available_mine_then_confirm_days`：当当前已有可筛库时，从当前状态出发完成一次筛选加确认的最低预留
- `cash_after_confirm_reserve` / `remaining_days_after_confirm_reserve`：如果现在预留一次确认，剩余现金和天数是多少
- `budget_regime`：`can_mine_and_confirm`、`confirm_only`、`cash_below_confirm`、`time_below_confirm` 或 `cash_and_time_below_confirm`

`available_actions.mine_library[*].batch_options[*]` 也会给出筛选后的确认预留字段：

- `cash_after_action_and_confirm_reserve`
- `remaining_days_after_action_and_confirm_reserve`
- `leaves_confirm_cash`
- `leaves_confirm_time`
- `leaves_confirm_capacity`

这些字段不改变动作合法性；它们是 agent 的决策提示。一个 batch 即使当前合法，也可能把现金或时间降到无法确认新 hit 的状态。低预算 run 中，agent 应优先选择能保留 `leaves_confirm_capacity = true` 的筛选闭环，或者在 `reasoning` 中明确说明为什么要接受不可确认风险。

## 6. 终局条件

实验会在以下情形之一进入终局：

- 已达到 `max_experiment_days`：`stop_code = "max_experiment_days"`
- 剩余时间不足以执行任何合法动作：`stop_code = "time_insufficient"`
- 当前已无可继续操作的可见实验路径：`stop_code = "no_visible_path"`
- 当前现金不足以执行任何合法动作：`stop_code = "cash_insufficient"`
- agent 主动执行 `stop`：`stop_code = "agent_stop"`

如果 runner 因 agent/backend 故障强制终止 session，`stop_code = "backend_error"`，且 `stop_reason` 会以 `backend_error:` 开头。

## 7. Skill 市场

- `skill_market.json` 只提供购买前卡片信息
- 购买前，agent 与完整 skill 内容完全隔离
- 购买成功后，完整内容只会出现在 `owned_skills/<skill_id>/source/`
- skill 采用一次性买断定价，不存在日薪、解聘或退款
- forced-skill setting 会复用同一套 skill package 作为来源，但 market 购买界面关闭；agent 只看到开局已拥有的 skill 文件
- skill 的工具化使用是可选决策支持。agent 应在它有望改善 branch opening、mining、confirmation、purchase 或 stop 决策时使用；如果使用，推荐把结果保存到 `skill_analysis/` 并在动作 `reasoning` 中引用关键发现

## 8. 结果文件

分析一轮 run 时，最重要的文件通常是：

1. `results/summary.json`
2. `results/action_log.jsonl`
3. `results/screen_record_history.jsonl`
4. `results/rejection_log.jsonl`
5. `results/judge_audit.jsonl`
6. `results/runtime_timeline.jsonl`

如果想判断 agent 为什么停下，优先看：

- `summary.json` 的 `stop_code`
- `summary.json` 的 `stop_reason`
- `available_actions.json` 的末态
- `action_log.jsonl` 的最后几步
- `screen_record_history.jsonl` 与 `pending_confirmation_count`

如果想确认 noisy screening 是否生效，优先看：

- `state.json` / `summary.json` 里的 `screening_noise_enabled`、`screening_noise_sigma`、`screening_noise_clip`
- `screen_record_history.jsonl` 中 screening 阶段的 `observed_activity`
- `action_log.jsonl` 中 `confirm_hit` 记录里的 `confirmed_activity` 和 `noise_fraction`
