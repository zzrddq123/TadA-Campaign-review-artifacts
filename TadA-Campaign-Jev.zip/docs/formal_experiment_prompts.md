# TadACampaign V2 Formal 实验运行手册与 Codex Prompt

这份文档的目标很具体：你打开一个新的 Codex 窗口，复制其中一个 setting 的 Prompt 粘贴进去，它就能在当前 `TadA-Campaign` checkout 里为该 setting 串行完成 5 个 formal benchmark repeat。每个 repeat 使用一个独立 seed、一个独立 `setting.toml`、一个独立 output root 和一个独立 tmux session；同一时间只运行 1 个 seed，当前 seed 跑完并按要求保存结果后，再启动下一个 seed。

当前版本不使用“每个 setting 一个 worktree”的旧方法，也不通过反复编辑共享的 `config/experiments/TadACampaign_v2_formal.toml` 来跑论文 setting。所有正式 setting 都从同一个 baseline 模板生成独立的 `setting.toml`，再通过同一个公开入口运行；最终 run 目录会保存这份 setting 文件，所以后一个实验不会继承前一个实验的参数。

## 一句话流程

1. 在 `TadA-Campaign` 仓库根目录打开 Codex。
2. 从本文档复制一个 setting Prompt。
3. 粘贴给 Codex。
4. Codex 使用 canonical repeat seeds `601`、`602`、`603`、`604`、`605`。
5. Codex 对每个 seed 调用 `scripts/create_formal_setting.py --seed <SEED>`，从 `templates/TadACampaign_v2_formal_baseline.toml` 生成 `<output-root>/seed<SEED>/setting.toml`。
6. Codex 对当前 seed 设置 `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE=<output-root>/seed<SEED>/setting.toml`，用 tmux 启动 `bash scripts/run_TadACampaign_v2.sh formal <output-root>/seed<SEED>`。
7. Codex 监控当前 seed 的 tmux session 直到结束，找到本轮 run 目录，读取结果并写入 `EXPERIMENT_CARD.md`、`results/operator_summary.md`、`results/operator_event_log.csv`、`results/operator_run_summary.csv`。
8. 五个 seed 按 `601` 到 `605` 的顺序逐个串行运行；前一个 seed 完成并保存 operator outputs 后，才启动下一个 seed。
9. 每个 seed 的 run 目录保存本轮 `setting.toml`、运行时 `config.toml`、过程记录和结果文件。

## 公共入口

仓库只支持一个公开 formal 入口：

```bash
bash scripts/run_TadACampaign_v2.sh formal [output-root]
```

不要直接调用内部 runner，不要添加旁路启动脚本，不要让 Codex 创建新的 worktree。每个正式 setting 仍然使用 `formal` preset，只是启动前用 `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` 指向独立生成的 `setting.toml`。

## Baseline Setting 模板

正式论文实验的 baseline 模板固定为：

```text
templates/TadACampaign_v2_formal_baseline.toml
```

每个 setting repeat 生成自己的配置文件：

```text
<output-root>/seed<SEED>/setting.toml
```

生成命令模板：

```bash
SEED="<SEED>"
SEED_OUTPUT_ROOT="<OUTPUT_ROOT>/seed${SEED}"
mkdir -p "$SEED_OUTPUT_ROOT"
python3 scripts/create_formal_setting.py \
  --output "$SEED_OUTPUT_ROOT/setting.toml" \
  --run-output-root "$SEED_OUTPUT_ROOT" \
  --name "<RUN_NAME>_seed${SEED}" \
  --seed "$SEED" \
  --initial-cash "<INITIAL_CASH>" \
  --agent-backend "<BACKEND>" \
  [--agent-model "<MODEL>"] \
  [--agent-reasoning-effort "<REASONING_EFFORT>"]
```

规则：

- `templates/TadACampaign_v2_formal_baseline.toml` 是 baseline source of truth。
- 不要为了论文 setting 编辑 `config/experiments/TadACampaign_v2_formal.toml`；它只保留为内置 public preset。
- `scripts/create_formal_setting.py` 只用于生成 per-setting/per-seed TOML；它会把当前 checkout 的 `prepared_root` 和本 setting repeat 的 `output_root` 写成绝对路径，避免配置文件放在 `runs/` 下时相对路径解析错误。
- 论文 setting Prompt 默认必须传 `--seed` 并跑 canonical 5-seed repeats。不传 `--seed` 只适合调试、预检或用户明确要求的 single-run。
- 如果某个 setting 的 `model`、`reasoning_effort`、`profile`、`verbosity` 是 `OMIT`，生成命令里不要传对应参数；生成器会确保这些非默认字段不留在 `[agent]` 里。
- 启动前必须设置 `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` 指向本轮 `<output-root>/seed<SEED>/setting.toml`。这个变量只支持 `formal` preset。

最终每个 seed repeat 的 run 会保存四类配置证据：

```text
<output-root>/seed<SEED>/setting.toml              # 启动前生成的 per-setting/per-seed 配置
<run-dir>/setting.toml                             # 本轮 source setting 的副本
<run-dir>/results/host_runtime/source-config.toml  # host 编排侧保存的 source config
<run-dir>/config.toml                              # 注入 judge URL 后的运行时配置快照
```

因此，即使下一轮重新生成另一个 setting，上一轮结果目录仍然完整记录了当时用来 play benchmark 的配置。

## 这批实验最终跑什么

主文实验采用统一视觉语言：**decision-cash trajectory plot**。每个 setting 是一条完整游戏轨迹，x 轴为 simulated day，y 轴为 cash，线上 marker 表示 `prepare_seed`、`prepare_library`、`mine_library`、`confirm_hit`、`purchase_skill`、`stop`。

| Figure | 实验主题 | 自变量 | Setting | 主因变量 | 控制变量 | 这张图想证明什么 |
| --- | --- | --- | --- | --- | --- | --- |
| Fig. 2 | Construct validity of semi-blind policy baselines | 算法 policy | Stop Now / Random Legal / Budgeted Static Ranker / Scout Confirm Stop / Upside Greedy Explorer / Empirical EV Planner | capital-adjusted profit = `cash_final - initial_cash` | policy backend；initial cash = 100k；no skill；no market；same semi-blind observation interface；matched 5-seed serial repeats；same formal costs/noise/reward | benchmark 是否能在不使用 LLM 的情况下区分不同层次的 scientific operating policy |
| Fig. 3 | Budget effect on agent behavior | 起始资金 | 30k / 50k / 75k / 100k / 150k / 200k / 300k / 500k / 700k | cash trajectory | Codex；no skill；no market；matched 5-seed serial repeats；same formal costs/noise/reward | 不同 budget 是否改变 agent 行为路径：能否进入 screening、能否 afford confirmation、何时 stop |
| Fig. 4 | Agent effect on decision behavior | Agent 类型 | Codex-GPT-5.5 / Codex-GPT-5.4 / GPT-5.3-codex / OpenCode-DeepSeek-V3.2 / OpenCode-DeepSeek-V4-Flash / OpenCode-DeepSeek-V4-Pro / OpenCode-MiniMax-M2.5 / OpenCode-MiniMax-M2.7 / OpenCode-LongCat-Flash-Thinking / OpenCode-LongCat-Flash-Lite / OpenCode-GLM-5 / OpenCode-GLM-5.1 / OpenCode-GPT-5.4 / OpenCode-GPT-5.3-codex | cash trajectory | initial cash = 100k；no skill；no market；matched 5-seed serial repeats；same formal costs/noise/reward | 不同 agent 的差异是否体现在什么时候 prepare、mine、confirm、stop |
| Fig. 5a | Single-skill effect on agent behavior | 开局强制拥有的单个 BioSkill 文件 | No skill / 12 个 TadA-Campaign-screened CPU/local BioSkills | cash trajectory；tool-backed skill use artifact；action reasoning 是否引用 skill 结果 | Codex；initial cash = 100k；market purchase surface off；no prompt append；每次一个 forced owned BioSkill；matched 5-seed serial repeats | 哪些真正适配 TadA DNA benchmark 的 BioSkill 会改变 downstream experimental strategy |
| Fig. 5b | Skill-market effect on agent behavior | Skill market setting | No market / 12-BioSkills neutral market / 12-BioSkills marketing market | cash trajectory；purchase timing | Codex；initial cash = 100k；same 12-BioSkills pool；same price；matched 5-seed serial repeats | agent 是否购买 BioSkill、何时购买、购买后是否改变后续决策 |

## 结果总目录规范

所有正式论文 run 统一放到：

```text
runs/paper_main/
```

分层规则：

```text
runs/paper_main/
  fig2_construct_validity/
    stop_now/
    blind_random_legal/
    budgeted_static_ranker/
    scout_confirm_stop/
    upside_greedy_explorer/
    empirical_ev_planner/
  fig3_budget/
    cash30000/
    cash50000/
    cash75000/
    cash100000/
    cash150000/
    cash200000/
    cash300000/
    cash500000/
    cash700000/
  fig4_agent/
    codex/
    codex_gpt54/
    codex_gpt53/
    opencode_deepseekv32/
    opencode_deepseekv4_flash/
    opencode_deepseekv4_pro/
    opencode_minimaxm25/
    opencode_longcat_flash_thinking/
    opencode_longcat_flash_lite/
    opencode_minimaxm27/
    opencode_glm5/
    opencode_glm51/
    opencode_gpt54/
    opencode_gpt53codex/
  fig5a_single_skill/
    no_skill/
    motif_search/
    sequence_properties/
    pairwise_alignment/
    codon_usage/
    transcription_translation/
    reverse_complement/
    sequence_slicing/
    sequence_statistics/
    filter_sequences/
    msa_statistics/
    distance_calculations/
    restriction_sites/
  fig5b_skill_market/
    no_market/
    full_neutral_market/
    full_marketing_market/
```

每个 setting 的 `output_root` 是上面某个叶子目录。脚本完成后会在叶子目录下创建时间戳 run 目录，例如：

```text
runs/paper_main/fig3_budget/cash50000/
  20260426-170102-TadACampaign_v2_formal_fig3_budget_cash50000/
```

## 单个 run 的结果结构

每轮 run 至少应包含：

```text
<run-dir>/
  EXPERIMENT_CARD.md
  setting.toml
  config.toml
  process/
    agent_workspace/
    step_001/
    step_002/
    ...
  results/
    summary.json
    summary.md
    action_log.jsonl
    screen_record_history.jsonl
    rejection_log.jsonl
    judge_audit.jsonl
    runtime_timeline.jsonl
    cash_curve.csv
    cash_curve.png
    operator_summary.md
    operator_event_log.csv
    operator_run_summary.csv
    host_runtime/
```

其中：

- `setting.toml`：启动本轮 run 的 per-setting source config，来自 baseline 模板。
- `config.toml`：注入 judge URL 和运行时绝对路径后的最终配置快照。
- `EXPERIMENT_CARD.md`：人读的实验卡，说明这个结果文件夹用于哪张图、哪个 setting、改了什么变量、控制变量是什么。
- `process/step_*`：逐步过程记录，包含每步 state、available actions、chosen action、judge response。
- `results/summary.json`：权威最终指标。
- `results/action_log.jsonl`：成功动作序列。
- `results/operator_summary.md`：Codex 跑完后生成的人读摘要和完整动作表。
- `results/operator_event_log.csv`：方便画 trajectory marker 的逐动作表。
- `results/operator_run_summary.csv`：方便汇总所有 run 的单行摘要。

当前代码已经自动保存 `process/` 和 `results/` 的核心过程记录。本文档要求 Codex 额外写 `EXPERIMENT_CARD.md` 和 `operator_*` 文件，用于提升实验可追踪性。

## 运行前准备

如果 `prepared/manifest.json` 不存在，先在当前 checkout 中运行：

```bash
uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared
```

建议先做一次 smoke 预检：

```bash
unset TADACAMPAIGN_SKILL_MARKET_MANIFEST
unset TADACAMPAIGN_AGENT_PROMPT_APPEND
tmux new-session -d -s TadACampaign_smoke_preflight \
  "cd '$PWD' && mkdir -p runs/preflight_smoke && bash scripts/run_TadACampaign_v2.sh smoke runs/preflight_smoke 2>&1 | tee runs/preflight_smoke/tmux.log"
```

## 最短可复制 Prompt 索引

最推荐的日常用法是：从下面复制一条完整句子，粘贴到新开的 Codex 窗口。新 Codex 会读取本文档，用 `setting_id` 找到对应表格，并按该 setting 的专用 Prompt 串行运行 canonical 5-seed repeats。也就是说，下面这些示例默认都会按顺序运行 seeds `601`、`602`、`603`、`604`、`605`：每次只启动当前 seed 的 tmux session，当前 seed 完成并整理 operator outputs 后再启动下一个 seed。

### Fig. 2

Fig. 2 的六个 semi-blind policy baselines 不需要再给 Codex 一段提示词来执行。它们是纯 Python algorithmic policy backend，可直接用脚本启动。当前默认六个 policy 是 `stop_now`、`blind_random_legal`、`budgeted_static_ranker`、`scout_confirm_stop`、`upside_greedy_explorer`、`empirical_ev_planner`：

```bash
python3 scripts/run_construct_validity_baselines.py prepare
python3 scripts/run_construct_validity_baselines.py launch-serial
python3 scripts/run_construct_validity_baselines.py status
python3 scripts/run_construct_validity_baselines.py collect
```

`launch-serial` 会为当前 policy/seed 启动对应 tmux session，并按串行 5-seed 约定一次只运行 1 个 seed；每个 session 仍然只调用公开入口 `bash scripts/run_TadACampaign_v2.sh formal <seed_output_root>`。如果同名 tmux session 已存在，可加 `--force` 先杀掉再重启。

### Fig. 3

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash30000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash50000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash75000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash100000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash150000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash200000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash300000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash500000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig3_budget_cash700000 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

### Single-Run Debug Prompt

只有在你明确想做调试、预检或复现 baseline seed 的单次运行时，才使用下面这个 single-run 句式。它不会展开成 5 个 seed。

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=<SETTING_ID> 只运行 single-run formal debug；不要运行 canonical 5-seed repeats；使用该 setting 的 base output_root、base tmux session 和 baseline 默认 seed。
```

### Fig. 4

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_codex 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_codex_gpt54 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_codex_gpt53 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_deepseekv32 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_deepseekv4_flash 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_deepseekv4_pro 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_minimaxm25 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_longcat_flash_thinking 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_longcat_flash_lite 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_minimaxm27 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_glm5 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_glm51 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_gpt54 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig4_agent_opencode_gpt53codex 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

### Fig. 5a

Fig. 5a 直接评估 No skill control 和 12 个筛选后的 BioSkills forced-skill setting。原来的非 BioSkills setting 不再作为 Fig. 5a 正式 setting；它们和当前 TadA DNA benchmark 的输入、CPU-only 约束和可调用决策支持目标不匹配。

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_no_skill 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_motif_search 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_sequence_properties 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_pairwise_alignment 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_codon_usage 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_transcription_translation 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_reverse_complement 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_sequence_slicing 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_sequence_statistics 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_filter_sequences 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_msa_statistics 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_distance_calculations 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5a_single_skill_restriction_sites 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、BioSkills manifest 准备步骤和 operator 输出整理脚本。
```

### Fig. 5b

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5b_skill_market_no_market 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5b_skill_market_full_neutral 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、Skill Market 准备步骤和 operator 输出整理脚本。
```

```text
请阅读 docs/formal_experiment_prompts.md，并按 setting_id=fig5b_skill_market_full_marketing 运行对应的 serial 5seed formal repeats；必须使用 canonical repeat seeds 601、602、603、604、605，并使用该文档规定的 output_root、tmux session、setting 生成范围、Skill Market 准备步骤和 operator 输出整理脚本。
```

## 关键运行约束

- 不要新建或切换 worktree。
- 不要修改当前 checkout 之外的仓库目录。
- 不要为了论文 setting 编辑 `config/experiments/TadACampaign_v2_formal.toml`。
- 每次 setting 都从 `templates/TadACampaign_v2_formal_baseline.toml` 生成 5 个自己的 `<output_root>/seed<SEED>/setting.toml`。
- 默认 setting 的 TOML 只覆盖 Prompt 指定的 seed-specific `name`、`seed`、`initial_cash` 和 `[agent]` 字段；skill/market setting 还会按 Prompt 写入 `[judge].skill_market_manifest`、`[judge].skill_market_enabled` 和 `[judge].initial_owned_skill_ids`。
- `TADACAMPAIGN_*` 的 `unset` 或 `export` 要写进 tmux 命令内部；不要只依赖当前 shell 的环境状态。
- 正式 setting 优先把 skill manifest 写进每个 `<output_root>/seed<SEED>/setting.toml`；tmux 内默认 unset `TADACAMPAIGN_SKILL_MARKET_MANIFEST`，避免 env 覆盖 per-setting TOML。
- No-skill 和 Fig. 5a forced-skill run 必须 unset `TADACAMPAIGN_AGENT_PROMPT_APPEND`；Fig. 5a 不允许用 prompt append 代替真实 skill 文件。
- Skill Market run 只允许额外写 `/tmp/TadACampaign_skill_scout` 和 `/tmp/TadACampaign_skill_market/...` 用于构建本地 market。
- `backend = "opencode"` 的 run 不能启用 Skill Market；当前 Skill Market 只支持 Codex backend。

## 当前 formal 默认值提醒

本文档使用当前仓库的 formal baseline 模板，而不是旧对话材料中的旧成本表。

当前默认 formal 重点字段：

| 字段 | 当前值 |
| --- | --- |
| `seed` | `20260329` |
| `max_experiment_days` | `180.0` |
| `daily_burn_cost` | `800.0` |
| `prepare_seed_cost` / `prepare_seed_days` | `365.0` / `3.0` |
| `prepare_library_cost` / `prepare_library_days` | `142.0` / `2.0` |
| `confirm_hit_cost` / `confirm_hit_days` | `467.0` / `12.0` |
| `purchase_skill_days` | `1.0` |
| `mine_batch_menu` | `780` / `880` / `1020` / `1280` |
| screening noise | enabled, sigma `0.10`, clip `0.20` |

Prompt 中若出现旧设想的 `100 days` 或旧 batch size，应以 `templates/TadACampaign_v2_formal_baseline.toml` 为准，不要改 horizon、成本或 batch menu。

## Publication Repeat Seeds

正式论文重复实验使用固定共享 seed 集合，而不是日期 seed：

```text
601
602
603
604
605
```

这些数值是固定 repeat 编号，不是日期 seed，也不表示任何日历日期。

规则：

- 单个 formal setting 不传 `--seed` 时继续使用 baseline 默认 `20260329`，适合调试、预检和单实例复现实验。
- 论文主结果的 repeated evaluation 使用上面 5 个 seed；所有被比较的方法、budget、agent、skill 条件都必须使用同一组 seed。
- 不要在 `config/experiments/` 下创建 5 个永久 config 文件。每个 seed 都用 `scripts/create_formal_setting.py --seed <SEED>` 生成自己的 `<seed_output_root>/setting.toml`，并通过 `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` 传给 formal run。
- `operator_event_log.csv` 和 `operator_run_summary.csv` 会记录 `replay_seed`，后续合并表可以按 `setting_id` 和 `replay_seed` 做 matched comparison。

## tmux 启动和完成判定

推荐启动模式：

```bash
SEED="<SEED>"
SEED_OUTPUT_ROOT="<OUTPUT_ROOT>/seed${SEED}"
mkdir -p "$SEED_OUTPUT_ROOT"
python3 scripts/create_formal_setting.py \
  --output "$SEED_OUTPUT_ROOT/setting.toml" \
  --run-output-root "$SEED_OUTPUT_ROOT" \
  --name "<RUN_NAME>_seed${SEED}" \
  --seed "$SEED" \
  --initial-cash "<INITIAL_CASH>" \
  --agent-backend "<BACKEND>"

SETTING_CONFIG="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve())' "$SEED_OUTPUT_ROOT/setting.toml")"
tmux new-session -d -s "<TMUX_SESSION>_s<SEED>" \
  "cd '$PWD' && unset TADACAMPAIGN_SKILL_MARKET_MANIFEST && unset TADACAMPAIGN_AGENT_PROMPT_APPEND && export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE='$SETTING_CONFIG' && bash scripts/run_TadACampaign_v2.sh formal '$SEED_OUTPUT_ROOT' 2>&1 | tee '$SEED_OUTPUT_ROOT/tmux.log'"
```

如果 setting 需要指定 model 或 reasoning effort，在 `create_formal_setting.py` 命令中额外加入 `--agent-model "<MODEL>"` 或 `--agent-reasoning-effort "<REASONING_EFFORT>"`。如果对应字段是 `OMIT`，不要传这个参数。

如果 setting 属于 publication repeat，在 `create_formal_setting.py` 命令中额外加入 `--seed "<SEED>"`，并把 `name`、`tmux session`、`output_root` 都加上 seed 后缀，避免串行重复实验相互覆盖。

如果 setting 需要 forced skill 或 Skill Market，在每个 seed 的 `create_formal_setting.py` 命令中加入该 setting 指定的 `--skill-market-manifest`、`--skill-market-enabled/--no-skill-market-enabled`、`--initial-owned-skill-id` 参数。tmux 命令里仍默认 unset `TADACAMPAIGN_SKILL_MARKET_MANIFEST`，让 `<output_root>/seed<SEED>/setting.toml` 成为唯一配置证据。

监控：

```bash
tmux has-session -t "<TMUX_SESSION>_s<SEED>" 2>/dev/null && echo running || echo finished
tmux capture-pane -pt "<TMUX_SESSION>_s<SEED>" -S -120
```

找最终 run 目录：

```bash
RUN_DIR="$(find "$SEED_OUTPUT_ROOT" -maxdepth 1 -mindepth 1 -type d -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-)"
test -f "$RUN_DIR/results/summary.json"
test -f "$RUN_DIR/results/action_log.jsonl"
```

## Serial 5-Seed tmux 启动模式

这个模式用于同一个 setting 的 5 次独立重复实验。它不是新的 public benchmark 入口；每一轮按 seed 顺序一次只启动 1 个 tmux session，当前 seed 完成并保存结果后才启动下一个 seed。每个 tmux session 仍然只调用：

```bash
bash scripts/run_TadACampaign_v2.sh formal <seed_output_root>
```

串行重复实验的 seed 固定为：

```bash
REPEAT_SEEDS=(601 602 603 604 605)
```

输出目录规范：

```text
<base_output_root>/
  seed601/
    setting.toml
    tmux.log
    <timestamp-run-dir>/
  seed602/
  seed603/
  seed604/
  seed605/
```

命名规则：

- `seed_output_root = <base_output_root>/seed<SEED>`
- `seed_run_name = <base_run_name>_seed<SEED>`
- `seed_tmux_session = <base_tmux>_s<SEED>`
- `setting_id` 保持原 setting，例如 `fig3_budget_cash100000`；seed 作为 `replay_seed` 记录在 config 和 operator CSV 中。

通用启动骨架。注意：这个 loop 是串行的；每轮只启动当前 seed 的 1 个 tmux session，等待它结束、整理该 seed 的 operator outputs 后，才进入下一个 seed。

```bash
REPEAT_SEEDS=(601 602 603 604 605)
BASE_OUTPUT_ROOT="<OUTPUT_ROOT>"
BASE_RUN_NAME="<RUN_NAME>"
BASE_TMUX="<TMUX_SESSION>"

for SEED in "${REPEAT_SEEDS[@]}"; do
  SEED_OUTPUT_ROOT="${BASE_OUTPUT_ROOT}/seed${SEED}"
  SEED_RUN_NAME="${BASE_RUN_NAME}_seed${SEED}"
  SEED_TMUX="${BASE_TMUX}_s${SEED}"

  mkdir -p "${SEED_OUTPUT_ROOT}"
  python3 scripts/create_formal_setting.py \
    --output "${SEED_OUTPUT_ROOT}/setting.toml" \
    --run-output-root "${SEED_OUTPUT_ROOT}" \
    --name "${SEED_RUN_NAME}" \
    --seed "${SEED}" \
    --initial-cash "<INITIAL_CASH>" \
    --agent-backend "<BACKEND>"
  SETTING_CONFIG="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve())' "${SEED_OUTPUT_ROOT}/setting.toml")"
  tmux new-session -d -s "${SEED_TMUX}" \
    "cd '$PWD' && unset TADACAMPAIGN_SKILL_MARKET_MANIFEST && unset TADACAMPAIGN_AGENT_PROMPT_APPEND && export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE='${SETTING_CONFIG}' && bash scripts/run_TadACampaign_v2.sh formal '${SEED_OUTPUT_ROOT}' 2>&1 | tee '${SEED_OUTPUT_ROOT}/tmux.log'"

  while tmux has-session -t "${SEED_TMUX}" 2>/dev/null; do
    sleep 60
  done

  RUN_DIR="$(find "${SEED_OUTPUT_ROOT}" -maxdepth 1 -mindepth 1 -type d -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-)"
  test -f "${RUN_DIR}/results/summary.json"
  test -f "${RUN_DIR}/results/action_log.jsonl"

  python3 scripts/write_TadACampaign_operator_outputs.py \
    --run-dir "${RUN_DIR}" \
    --figure-id "<FIGURE_ID>" \
    --experiment-theme "<EXPERIMENT_THEME>" \
    --setting-id "<SETTING_ID>" \
    --setting-name "<SETTING_NAME>" \
    --agent-name "<AGENT_NAME>" \
    --initial-cash "<INITIAL_CASH>" \
    --independent-variable "<INDEPENDENT_VARIABLE>" \
    --control-variables "<CONTROL_VARIABLES>" \
    --purpose "<PURPOSE>" \
    --output-root "${SEED_OUTPUT_ROOT}" \
    --skill-condition "<SKILL_CONDITION>" \
    --market-condition "<MARKET_CONDITION>" \
    --prompt-append-mode "<PROMPT_APPEND_MODE>" \
    --manifest-path "<MANIFEST_PATH>"
done
```

如果 setting 需要 Skill Market 或 prompt append，沿用该 setting 的专用 Prompt 规则，把相同的 skill/market 参数加到每个 seed 的 `create_formal_setting.py` 命令里；tmux 内的 env unset/export 也要按该 setting 的规则逐个 session 设置。

正式论文 setting 默认使用这个串行模式，同一个 setting 的 5 个 seed 应当按固定 seed 顺序逐个启动 tmux session。这样可以避免同一 checkout 内的 host judge 端口、Skill Market env、operator 汇总或资源竞争互相干扰，同时仍保持相同目录和 seed 命名规范。

串行 5-seed Prompt 的完成要求：

1. 先列出 5 个计划运行的 `seed`、`seed_output_root`、`setting.toml` 和 `tmux session`。
2. 按 `601`、`602`、`603`、`604`、`605` 的顺序一次启动 1 个 seed tmux session；不要同时启动多个 seed session。
3. 持续监控当前 seed tmux session，直到该 seed 结束，再找到最终 `RUN_DIR`，读取 `results/summary.json` 和 `results/action_log.jsonl`。
4. 对当前已完成 seed 调用 `scripts/write_TadACampaign_operator_outputs.py`，其中 `--setting-id` 保持原 setting，`--output-root` 使用该 seed 的 `seed_output_root`。
5. 当前 seed 的 operator outputs 写完并确认结果文件存在后，才启动下一个 seed；5 个 seed 全部完成后，才认为这一轮 setting 完成。
6. 最后汇总 5 个 `RUN_DIR`、5 个 `replay_seed`、每个 seed 的 `confirmed_best_activity`、`cash_final`、`stop_reason` 和 operator summary 路径。

## operator 输出整理脚本

每个 setting Prompt 都要求 Codex 跑完后调用仓库内置的结果整理脚本：

- `EXPERIMENT_CARD.md`
- `results/operator_summary.md`
- `results/operator_event_log.csv`
- `results/operator_run_summary.csv`

这个脚本不是新的 benchmark 启动入口；它只读取已完成 run 的 `summary.json`、`action_log.jsonl` 和 `config.toml`，写出人读实验卡与画图用 CSV。调用形式如下：

```bash
python3 scripts/write_TadACampaign_operator_outputs.py \
  --run-dir "$RUN_DIR" \
  --figure-id "<FIGURE_ID>" \
  --experiment-theme "<EXPERIMENT_THEME>" \
  --setting-id "<SETTING_ID>" \
  --setting-name "<SETTING_NAME>" \
  --agent-name "<AGENT_NAME>" \
  --initial-cash "<INITIAL_CASH>" \
  --independent-variable "<INDEPENDENT_VARIABLE>" \
  --control-variables "<CONTROL_VARIABLES>" \
  --purpose "<PURPOSE>" \
  --output-root "<OUTPUT_ROOT>" \
  --skill-condition "<SKILL_CONDITION>" \
  --market-condition "<MARKET_CONDITION>" \
  --prompt-append-mode "<PROMPT_APPEND_MODE>" \
  --manifest-path "<MANIFEST_PATH>"
```

## 通用 Prompt 模板

不确定该复制哪个专用 Prompt 时，用这个模板。更推荐使用后面每个 setting 的专用 Prompt。

```text
请在当前 TadA-Campaign 仓库根目录为一个 TadACampaign V2 formal setting 运行 canonical 5-seed serial repeats。

SETTING：
- figure_id = "<FIGURE_ID>"
- experiment_theme = "<EXPERIMENT_THEME>"
- setting_id = "<SETTING_ID>"
- setting_name = "<SETTING_NAME>"
- purpose = "<这个 run 用来探究什么>"
- independent_variable = "<自变量>"
- control_variables = "<控制变量>"
- name = "<RUN_NAME>"
- initial_cash = <INITIAL_CASH>
- [agent].backend = "<BACKEND>"
- [agent].model = "<MODEL_OR_OMIT>"
- [agent].reasoning_effort = "<REASONING_OR_OMIT>"
- skill_condition = "<SKILL_CONDITION>"
- market_condition = "<MARKET_CONDITION>"
- forced_skill_id = "<unset 或 forced owned skill id>"
- skill_market_enabled = "<unset / true / false>"
- prompt_append = "<通常为 unset；只有明确的非 skill 运营提示才可设置>"
- manifest = "<unset 或 manifest path>"
- tmux session = "<TMUX_SESSION>"
- output_root = "<OUTPUT_ROOT>"

执行要求：
1. 不要新建或切换 worktree；直接在当前 checkout 中操作。
2. 如果 prepared/manifest.json 不存在，先运行 uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared。
3. 按 canonical repeat seeds `601`、`602`、`603`、`604`、`605` 生成 5 个 `<output_root>/seed<SEED>/setting.toml`；每个 setting 只设置 SETTING 中列出的 name、seed、initial_cash、[agent] 字段，以及明确列出的 skill/market `[judge]` 字段；其他 formal 默认参数不要改。
4. 如果 MODEL_OR_OMIT 或 REASONING_OR_OMIT 是 OMIT，就删除/不要保留对应字段。
5. 如果 SETTING 有 manifest，用 `scripts/create_formal_setting.py --skill-market-manifest "<manifest>"` 写入 setting；如果有 forced_skill_id，再加 `--no-skill-market-enabled --initial-owned-skill-id "<forced_skill_id>"`；如果是 market setting，保持 `--skill-market-enabled`。
6. 启动前在 tmux 内 unset TADACAMPAIGN_SKILL_MARKET_MANIFEST；按 SETTING 设置或 unset TADACAMPAIGN_AGENT_PROMPT_APPEND。
7. 按 `601` 到 `605` 顺序一次启动 1 个 seed tmux session；每个 session export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE 指向 `<output_root>/seed<SEED>/setting.toml`，然后运行 `bash scripts/run_TadACampaign_v2.sh formal <output_root>/seed<SEED>`；当前 seed session 结束并整理结果后，再启动下一个 seed。
8. 启动前告诉我当前 checkout 绝对路径，并列出 5 个 seed、seed-specific name、tmux session、seed output_root，以及这些结果文件夹用于探究什么。
9. 对当前 seed session 持续监控，直到它结束；找到该 seed 的最终 RUN_DIR 并整理 operator outputs，完成后再进入下一个 seed。
10. 对每个 RUN_DIR 读取 results/summary.json 和 results/action_log.jsonl。
11. 对每个 RUN_DIR 调用 `scripts/write_TadACampaign_operator_outputs.py`，把本 setting 字段作为参数传入，写 RUN_DIR/EXPERIMENT_CARD.md、RUN_DIR/results/operator_summary.md、RUN_DIR/results/operator_event_log.csv、RUN_DIR/results/operator_run_summary.csv；`--setting-id` 保持原 setting，`--output-root` 使用对应 seed output_root。
12. 最后在回复里汇总 5 个 RUN_DIR 绝对路径、5 个 replay_seed、每个 seed 的 confirmed_best_activity、cash_final、stop_reason 和 operator_summary.md 路径。
```

## Fig. 2：Construct Validity Policy Baselines

固定条件：

- Backend：`policy`
- Initial cash：`100000.0`
- Skill Market：off
- Prompt append：off
- Replay seed / costs / noise / reward：canonical 5-seed repeats；其余 formal 默认参数不变
- 信息边界：semi-blind；policy 只使用当前 judge observation、当前 legal actions、公开 history 和 policy 自己从已发生 action response 建立的探索树
- 禁止：读取 prepared manifest、hidden topology、hidden true activity；禁止把 seed/library id 数字后缀当作价值或深度信号
- 指标：`profit = cash_final - initial_cash`

| Setting ID | Policy | `[agent].policy` | `name` | `tmux prefix` | `output_root` |
| --- | --- | --- | --- | --- | --- |
| `fig2_construct_validity_stop_now` | Stop Now | `stop_now` | `TadACampaign_v2_formal_fig2_construct_validity_stop_now_cash100000` | `TadACampaign_fig2_stop_now` | `runs/paper_main/fig2_construct_validity/stop_now` |
| `fig2_construct_validity_random_legal` | Random Legal | `blind_random_legal` | `TadACampaign_v2_formal_fig2_construct_validity_blind_random_legal_cash100000` | `TadACampaign_fig2_blind_random_legal` | `runs/paper_main/fig2_construct_validity/blind_random_legal` |
| `fig2_construct_validity_budgeted_static_ranker` | Budgeted Static Ranker | `budgeted_static_ranker` | `TadACampaign_v2_formal_fig2_construct_validity_budgeted_static_ranker_cash100000` | `TadACampaign_fig2_budgeted_static_ranker` | `runs/paper_main/fig2_construct_validity/budgeted_static_ranker` |
| `fig2_construct_validity_scout_confirm_stop` | Scout Confirm Stop | `scout_confirm_stop` | `TadACampaign_v2_formal_fig2_construct_validity_scout_confirm_stop_cash100000` | `TadACampaign_fig2_scout_confirm_stop` | `runs/paper_main/fig2_construct_validity/scout_confirm_stop` |
| `fig2_construct_validity_upside_greedy_explorer` | Upside Greedy Explorer | `upside_greedy_explorer` | `TadACampaign_v2_formal_fig2_construct_validity_upside_greedy_explorer_cash100000` | `TadACampaign_fig2_upside_greedy_explorer` | `runs/paper_main/fig2_construct_validity/upside_greedy_explorer` |
| `fig2_construct_validity_empirical_ev_planner` | Empirical EV Planner | `empirical_ev_planner` | `TadACampaign_v2_formal_fig2_construct_validity_empirical_ev_planner_cash100000` | `TadACampaign_fig2_empirical_ev_planner` | `runs/paper_main/fig2_construct_validity/empirical_ev_planner` |

Policy 定义：

- `stop_now`：立即停止，给出不探索的 cash-preservation 下界。
- `blind_random_legal`：在当前 legal actions 中随机选择，仍只使用公开 observation；这是无运营判断的随机下界。
- `budgeted_static_ranker`：使用公开可见特征对 seed/library/mine action 排序；有正 EV pending hit 时先 confirm；非 confirm 行动必须同时满足 exploration spend cap、至少一次 future confirm 的现金和时间 reserve、以及每个 library 的 mine batch 上限。
- `scout_confirm_stop`：先对少量可见 library 做 bounded scout probing；每个 library 只做少量小 batch；若没有正 EV confirmation 或 reserve-preserving scout path，就主动 stop。
- `upside_greedy_explorer`：面向高活性确认可能带来大额收益的场景；有公开 observed upside hit 时优先确认 observed activity 最高的 hit；否则使用更高探索预算和最大 reserve-preserving batch 继续筛库，但仍保留至少一次 confirmation 的现金和时间 reserve。
- `empirical_ev_planner`：从已公开的 screening/confirmation action response 估计 library-level hit rate 和 batch EV；正 EV 时继续 prepare/mine/confirm，低于 EV 门槛且完成最小 probe floor 后 stop。

这些 policy 都是 semi-blind：它们不读取 `prepared/manifest.json`、hidden topology、hidden true activity，也不把 seed/library id 的数字后缀当作价值或深度信号。旧版 Fig. 2 setting 使用的 `visible_feature_ranker`、`myopic_confirm`、`frontier_probe_then_exploit` 已从当前公开 policy backend 中移除；如需复现旧结果，应使用包含旧 alias 的历史提交。

### Fig. 2 直接运行方式

这组 baseline 不需要 LLM agent，也不需要复制 prompt 给 Codex。直接运行脚本即可：

```bash
python3 scripts/run_construct_validity_baselines.py prepare
python3 scripts/run_construct_validity_baselines.py launch-serial
```

检查进度：

```bash
python3 scripts/run_construct_validity_baselines.py status
```

所有 session 结束后整理 operator outputs 和汇总 CSV：

```bash
python3 scripts/run_construct_validity_baselines.py collect
```

汇总文件会写到：

```text
runs/paper_main/fig2_construct_validity/construct_validity_policy_summary.csv
```

每个 seed 的 run 目录仍然包含 `results/summary.json`、`results/action_log.jsonl`、`results/cash_curve.csv`、`results/operator_summary.md`、`results/operator_event_log.csv` 和 `results/operator_run_summary.csv`。`summary.json` 中会记录 `agent_backend = "policy"` 和 `agent_policy = "<policy_name>"`。

## Fig. 3：Budget Effect

固定条件：

- Agent：Codex
- Skill Market：off
- Prompt append：off
- Replay seed / costs / noise / reward：默认使用 canonical 5-seed repeats；其余成本、噪声和 reward 不变。single-run debug 才使用 baseline 默认 seed
- 目的：看不同起始资金如何改变同一个 agent 的完整决策过程

| Setting ID | Initial Cash | `name` | `tmux` | `output_root` |
| --- | ---: | --- | --- | --- |
| `fig3_budget_cash30000` | `30000.0` | `TadACampaign_v2_formal_fig3_budget_cash30000` | `TadACampaign_fig3_budget_cash30000` | `runs/paper_main/fig3_budget/cash30000` |
| `fig3_budget_cash50000` | `50000.0` | `TadACampaign_v2_formal_fig3_budget_cash50000` | `TadACampaign_fig3_budget_cash50000` | `runs/paper_main/fig3_budget/cash50000` |
| `fig3_budget_cash75000` | `75000.0` | `TadACampaign_v2_formal_fig3_budget_cash75000` | `TadACampaign_fig3_budget_cash75000` | `runs/paper_main/fig3_budget/cash75000` |
| `fig3_budget_cash100000` | `100000.0` | `TadACampaign_v2_formal_fig3_budget_cash100000` | `TadACampaign_fig3_budget_cash100000` | `runs/paper_main/fig3_budget/cash100000` |
| `fig3_budget_cash150000` | `150000.0` | `TadACampaign_v2_formal_fig3_budget_cash150000` | `TadACampaign_fig3_budget_cash150000` | `runs/paper_main/fig3_budget/cash150000` |
| `fig3_budget_cash200000` | `200000.0` | `TadACampaign_v2_formal_fig3_budget_cash200000` | `TadACampaign_fig3_budget_cash200000` | `runs/paper_main/fig3_budget/cash200000` |
| `fig3_budget_cash300000` | `300000.0` | `TadACampaign_v2_formal_fig3_budget_cash300000` | `TadACampaign_fig3_budget_cash300000` | `runs/paper_main/fig3_budget/cash300000` |
| `fig3_budget_cash500000` | `500000.0` | `TadACampaign_v2_formal_fig3_budget_cash500000` | `TadACampaign_fig3_budget_cash500000` | `runs/paper_main/fig3_budget/cash500000` |
| `fig3_budget_cash700000` | `700000.0` | `TadACampaign_v2_formal_fig3_budget_cash700000` | `TadACampaign_fig3_budget_cash700000` | `runs/paper_main/fig3_budget/cash700000` |

### Fig. 3 可复制 Prompt

复制后只替换 `BUDGET_SETTING` 为表格中的一行。

```text
请在当前 TadA-Campaign 仓库根目录为 Fig. 3 budget-effect 的一个 formal setting 运行 canonical 5-seed serial repeats。

BUDGET_SETTING：
- figure_id = "Fig. 3"
- experiment_theme = "Budget effect on agent behavior"
- setting_id = "<fig3_budget_cash30000 / fig3_budget_cash50000 / fig3_budget_cash75000 / fig3_budget_cash100000 / fig3_budget_cash150000 / fig3_budget_cash200000 / fig3_budget_cash300000 / fig3_budget_cash500000 / fig3_budget_cash700000>"
- setting_name = "<30k / 50k / 75k / 100k / 150k / 200k / 300k / 500k / 700k>"
- purpose = "测试不同起始资金如何影响同一个 Codex agent 的完整决策轨迹，包括是否进入 screening、是否 afford confirmation、何时 stop。"
- independent_variable = "initial_cash"
- control_variables = "Codex backend; no skill; no skill market; matched canonical 5-seed serial repeats; same horizon/cost/noise/reward setting."
- name = "<对应表中的 name>"
- initial_cash = <对应表中的 Initial Cash>
- [agent].backend = "codex"
- [agent].model = "OMIT"
- [agent].reasoning_effort = "OMIT"
- skill_condition = "no_skill"
- market_condition = "no_market"
- prompt_append = "unset"
- manifest = "unset"
- tmux session = "<对应表中的 tmux>"
- output_root = "<对应表中的 output_root>"

执行要求：
1. 不要新建或切换 worktree；直接在当前 checkout 中操作。
2. 如果 prepared/manifest.json 不存在，先运行 uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared。
3. 按 canonical repeat seeds `601`、`602`、`603`、`604`、`605` 生成 5 个 `<output_root>/seed<SEED>/setting.toml`；每个 setting 写入 seed-specific name、seed、initial_cash，并确保 [agent].backend 保持 codex；不要保留 [agent].model、reasoning_effort、profile、verbosity 等非默认字段。
4. 其他 formal 默认参数全部保持不变。
5. 启动前执行 unset TADACAMPAIGN_SKILL_MARKET_MANIFEST 和 unset TADACAMPAIGN_AGENT_PROMPT_APPEND。
6. 按本文档 “Serial 5-Seed tmux 启动模式” 创建 5 个 seed output_root、生成 5 个 setting.toml，并按 `601` 到 `605` 顺序一次启动 1 个 seed tmux session；当前 seed session 结束并整理结果后，再启动下一个 seed。
7. 启动前告诉我当前 checkout 绝对路径，并列出 5 个 seed、seed-specific name、tmux session、seed output_root，以及这些结果文件夹用于 Fig. 3 budget-effect 的哪个 cash setting。
8. 对当前 seed session 持续监控，直到它结束；找到该 seed 的最终 RUN_DIR 并整理 operator outputs，完成后再进入下一个 seed。
9. 对每个 RUN_DIR 读取 results/summary.json 和 results/action_log.jsonl。
10. 对每个 RUN_DIR 调用 `scripts/write_TadACampaign_operator_outputs.py` 生成 EXPERIMENT_CARD.md、operator_summary.md、operator_event_log.csv、operator_run_summary.csv；参数使用本 setting 的 figure_id、experiment_theme、setting_id、setting_name、AGENT_NAME="Codex"、initial_cash、independent_variable、control_variables、purpose、对应 seed output_root、skill_condition、market_condition、PROMPT_APPEND_MODE="unset"、MANIFEST_PATH="unset"。
11. 最后汇总 5 个 RUN_DIR 绝对路径、5 个 replay_seed、每个 seed 的 confirmed_best_activity、cash_final、stop_reason 和 operator_summary.md 路径。
```

## Fig. 4：Agent Effect

固定条件：

- Initial cash：`100000.0`
- Skill Market：off
- Prompt append：off
- Replay seed / costs / noise / reward：默认使用 canonical 5-seed repeats；其余成本、噪声和 reward 不变。single-run debug 才使用 baseline 默认 seed
- 目的：看不同 agent 在同一预算和同一游戏条件下如何分配实验资源

当前仓库支持的 public backend 是 `codex`、`claude`、`opencode`。Fig. 4 主实验只使用 `codex` 和 `opencode` backend；Gemini CLI 尚未接入，所以本文档不提供 `backend = "gemini"` setting。

Codex rows 会通过 Codex CLI backend 启动，并把 `[agent].model` 传给 `codex exec -m <model>`；OpenCode rows 会通过 OpenCode backend 启动，并把模型写成 OpenCode provider 路径（例如 `openai/gpt-5.4`）。因此 `fig4_agent_codex_gpt54`、`fig4_agent_codex_gpt53` 是和 `fig4_agent_opencode_gpt54`、`fig4_agent_opencode_gpt53codex` 不同的 agent setting。`fig4_agent_codex` 对应 Codex-GPT-5.5。

| Setting ID | Agent | `[agent].backend` | `[agent].model` | `[agent].reasoning_effort` | `name` | `tmux` | `output_root` |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `fig4_agent_codex` | Codex-GPT-5.5 | `codex` | `gpt-5.5` | OMIT | `TadACampaign_v2_formal_fig4_agent_codex_gpt55_cash100000` | `TadACampaign_fig4_agent_codex` | `runs/paper_main/fig4_agent/codex` |
| `fig4_agent_codex_gpt54` | Codex-GPT-5.4 | `codex` | `gpt-5.4` | OMIT | `TadACampaign_v2_formal_fig4_agent_codex_gpt54_cash100000` | `TadACampaign_fig4_agent_codex_gpt54` | `runs/paper_main/fig4_agent/codex_gpt54` |
| `fig4_agent_codex_gpt53` | GPT-5.3-codex | `codex` | `gpt-5.3-codex` | OMIT | `TadACampaign_v2_formal_fig4_agent_codex_gpt53_cash100000` | `TadACampaign_fig4_agent_codex_gpt53` | `runs/paper_main/fig4_agent/codex_gpt53` |
| `fig4_agent_opencode_deepseekv32` | OpenCode-DeepSeek-V3.2 | `opencode` | `deepseek/deepseek-v3.2` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_deepseekv32_cash100000` | `TadACampaign_fig4_agent_deepseekv32` | `runs/paper_main/fig4_agent/opencode_deepseekv32` |
| `fig4_agent_opencode_deepseekv4_flash` | OpenCode-DeepSeek-V4-Flash | `opencode` | `deepseek/deepseek-v4-flash` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_deepseekv4_flash_cash100000` | `TadACampaign_fig4_agent_deepseekv4_flash` | `runs/paper_main/fig4_agent/opencode_deepseekv4_flash` |
| `fig4_agent_opencode_deepseekv4_pro` | OpenCode-DeepSeek-V4-Pro | `opencode` | `deepseek/deepseek-v4-pro` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_deepseekv4_pro_cash100000` | `TadACampaign_fig4_agent_deepseekv4_pro` | `runs/paper_main/fig4_agent/opencode_deepseekv4_pro` |
| `fig4_agent_opencode_minimaxm25` | OpenCode-MiniMax-M2.5 | `opencode` | `minimax/minimax-m2.5` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_minimaxm25_cash100000` | `TadACampaign_fig4_agent_minimaxm25` | `runs/paper_main/fig4_agent/opencode_minimaxm25` |
| `fig4_agent_opencode_longcat_flash_thinking` | OpenCode-LongCat-Flash-Thinking | `opencode` | `longcat/longcat-flash-thinking` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_longcat_flash_thinking_cash100000` | `TadACampaign_fig4_agent_longcat_flash_thinking` | `runs/paper_main/fig4_agent/opencode_longcat_flash_thinking` |
| `fig4_agent_opencode_longcat_flash_lite` | OpenCode-LongCat-Flash-Lite | `opencode` | `longcat/longcat-flash-lite` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_longcat_flash_lite_cash100000` | `TadACampaign_fig4_agent_longcat_flash_lite` | `runs/paper_main/fig4_agent/opencode_longcat_flash_lite` |
| `fig4_agent_opencode_minimaxm27` | OpenCode-MiniMax-M2.7 | `opencode` | `minimax/minimax-m2.7` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_minimaxm27_cash100000` | `TadACampaign_fig4_agent_minimaxm27` | `runs/paper_main/fig4_agent/opencode_minimaxm27` |
| `fig4_agent_opencode_glm5` | OpenCode-GLM-5 | `opencode` | `zai/glm-5` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_glm5_cash100000` | `TadACampaign_fig4_agent_glm5` | `runs/paper_main/fig4_agent/opencode_glm5` |
| `fig4_agent_opencode_glm51` | OpenCode-GLM-5.1 | `opencode` | `zai/glm-5.1` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_glm51_cash100000` | `TadACampaign_fig4_agent_glm51` | `runs/paper_main/fig4_agent/opencode_glm51` |
| `fig4_agent_opencode_gpt54` | OpenCode-GPT-5.4 | `opencode` | `openai/gpt-5.4` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_gpt54_cash100000` | `TadACampaign_fig4_agent_gpt54` | `runs/paper_main/fig4_agent/opencode_gpt54` |
| `fig4_agent_opencode_gpt53codex` | OpenCode-GPT-5.3-codex | `opencode` | `openai/gpt-5.3-codex` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_gpt53codex_cash100000` | `TadACampaign_fig4_agent_gpt53codex` | `runs/paper_main/fig4_agent/opencode_gpt53codex` |

### Fig. 4 可复制 Prompt

复制后只替换 `AGENT_SETTING` 为表格中的一行。

```text
请在当前 TadA-Campaign 仓库根目录为 Fig. 4 agent-effect 的一个 formal setting 运行 canonical 5-seed serial repeats。

AGENT_SETTING：
- figure_id = "Fig. 4"
- experiment_theme = "Agent effect on decision behavior"
- setting_id = "<从 Fig. 4 表格选择>"
- setting_name = "<Agent 名称>"
- purpose = "测试不同 agent 在 initial_cash=100000、no skill、no market、matched canonical 5-seed serial replay 条件下的完整 cash/action trajectory 差异。"
- independent_variable = "agent_backend_and_model"
- control_variables = "initial_cash=100000; no skill; no skill market; matched canonical 5-seed serial repeats; same horizon/cost/noise/reward setting."
- name = "<对应表中的 name>"
- initial_cash = 100000.0
- [agent].backend = "<对应 backend>"
- [agent].model = "<对应 model 或 OMIT>"
- [agent].reasoning_effort = "<对应 reasoning_effort 或 OMIT>"
- skill_condition = "no_skill"
- market_condition = "no_market"
- prompt_append = "unset"
- manifest = "unset"
- tmux session = "<对应 tmux>"
- output_root = "<对应 output_root>"

执行要求：
1. 不要新建或切换 worktree；直接在当前 checkout 中操作。
2. 如果 prepared/manifest.json 不存在，先运行 uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared。
3. 按 canonical repeat seeds `601`、`602`、`603`、`604`、`605` 生成 5 个 `<output_root>/seed<SEED>/setting.toml`；每个 setting 写入 seed-specific name、seed、initial_cash 和 AGENT_SETTING 中列出的 [agent] 字段；如果 model/reasoning_effort 是 OMIT，就删除/不要保留对应字段。
4. 其他 formal 默认参数全部保持不变。
5. 启动前执行 unset TADACAMPAIGN_SKILL_MARKET_MANIFEST 和 unset TADACAMPAIGN_AGENT_PROMPT_APPEND。
6. 按本文档 “Serial 5-Seed tmux 启动模式” 创建 5 个 seed output_root、生成 5 个 setting.toml，并按 `601` 到 `605` 顺序一次启动 1 个 seed tmux session；当前 seed session 结束并整理结果后，再启动下一个 seed。
7. 如果遇到可恢复问题，例如 tmux session 名冲突、CLI home/provider hostname 问题、opencode/claude 本地配置问题，请在当前 checkout 的 .runtime 或 output_root 内处理并继续；不要修改当前 TadA-Campaign 仓库之外的仓库内容。
8. 启动前告诉我当前 checkout 绝对路径，并列出 5 个 seed、seed-specific name、backend/model、tmux session、seed output_root，以及这些结果文件夹用于 Fig. 4 的哪个 agent setting。
9. 对当前 seed session 持续监控，直到它结束；找到该 seed 的最终 RUN_DIR 并整理 operator outputs，完成后再进入下一个 seed。
10. 对每个 RUN_DIR 读取 results/summary.json 和 results/action_log.jsonl。
11. 对每个 RUN_DIR 调用 `scripts/write_TadACampaign_operator_outputs.py` 生成 EXPERIMENT_CARD.md、operator_summary.md、operator_event_log.csv、operator_run_summary.csv；参数使用本 setting 的 figure_id、experiment_theme、setting_id、setting_name、agent_name、INITIAL_CASH="100000.0"、independent_variable、control_variables、purpose、对应 seed output_root、skill_condition、market_condition、PROMPT_APPEND_MODE="unset"、MANIFEST_PATH="unset"。
12. 最后汇总 5 个 RUN_DIR 绝对路径、5 个 replay_seed、每个 seed 的 confirmed_best_activity、cash_final、stop_reason 和 operator_summary.md 路径。
```

## Fig. 5a：Single-Skill Effect

固定条件：

- Agent：Codex
- Initial cash：`100000.0`
- Skill Market 购买界面：off
- Prompt append：off
- Replay seed / costs / noise / reward：默认使用 canonical 5-seed repeats；其余成本、噪声和 reward 不变。single-run debug 才使用 baseline 默认 seed
- 目的：隔离“开局强制携带一个真实 skill 文件”是否改变 agent 的实验选择；携带 skill 让 agent 可选择调用其说明、工具或流程获得结果，分析后用于决策，但不保证每轮一定实际调用

实现说明：Fig. 5a 不再使用 `TADACAMPAIGN_AGENT_PROMPT_APPEND` 模拟 skill。除 No skill control 外，每个 setting 都用 neutral manifest 作为 skill bundle 来源，并在 `setting.toml` 中写入：

```toml
[judge]
skill_market_manifest = "<MANIFEST_PATH>"
skill_market_enabled = false
initial_owned_skill_ids = ["<FORCED_SKILL_ID>"]
```

运行开始时，host judge 会把该 skill 视为已拥有；agent workspace 在第一步前就会出现 `owned_skills_index.json` 和 `owned_skills/<skill_id>/source/SKILL.md`。这意味着 agent 携带了该 skill，可以在过程中读取 `SKILL.md`，按 skill 描述安装/运行本地工具、脚本、检查清单或查询流程，获得分析结果后再决定 `prepare_seed`、`prepare_library`、`mine_library`、`confirm_hit`、`stop` 等下一步动作。这个使用是鼓励的、可审计的决策支持行为，不是动作合法性的硬前置条件；如果 agent 判断当前没有适合调用的 skill、没有可用输入或工具使用收益不足，也可能不产生 tool-backed artifact。`purchase_skill` 在 Fig. 5a 中不可用，不会产生购买动作，也不会扣 skill price 或 `purchase_skill_days` burn。

agent 若调用 skill 产生了结果或 artifact，推荐把输出保存在 `skill_analysis/`，并在后续动作 `--reasoning` 里引用 artifact 路径和关键发现。operator 在整理结果时需要记录是否观察到 `skill_analysis/` 产物；没有产物应报告为“未观察到 tool-backed skill use”，但不自动判为实验失败。

### Fig. 5a skill 评估口径

Fig. 5a 的正式 skill panel 只使用下方 12 个筛选后的 BioSkills，不再使用原来的非 BioSkills setting。筛选标准是：

- 不需要 GPU，不依赖结构生成、ESM/RFdiffusion/ProteinMPNN/ColabFold 等模型工作流。
- 输入能来自 benchmark agent 已经可见的 `state.json`、`history.json`、pending candidate sequence、confirmed/provisional activity、library counts 或 agent 自己整理的小 FASTA。
- Agent 能通过 `owned_skills/<skill_id>/source/SKILL.md` 理解如何调用 skill，能在本地运行脚本/示例或按说明得到可审计结果。
- 结果能影响下一步 `prepare_seed`、`prepare_library`、`mine_library`、`confirm_hit`、`stop` 的取舍，而不只是提供宽泛背景知识。

正式评估前要先构建 12-BioSkills manifest：

```text
/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json
```

这个 manifest 必须真的包含下表的 12 个 `skill_id` 和对应 `package_root`。不要使用原来的旧 skill manifest；否则会重新评估已经被替换掉的旧 skill pool。多数 BioSkills 依赖 Biopython，正式 run 的 experiment image 需要预装 `biopython`，或在各 skill package 里提供最小可执行适配脚本。否则实验会测到依赖缺失，而不是 skill 对 TadA-Campaign 决策的价值。

### Fig. 5a 正式 setting 表

除 No skill control 外，所有 Fig. 5a forced-skill setting 都使用同一份 12-BioSkills manifest，且设置 `skill_market_enabled = false`，让 agent 开局只拥有一个指定 BioSkill，不看到 market，也不能购买 skill。

| Setting ID | Skill condition | Forced skill id | `name` | `tmux` | `output_root` | Manifest |
| --- | --- | --- | --- | --- | --- | --- |
| `fig5a_single_skill_no_skill` | No skill | unset | `TadACampaign_v2_formal_fig5a_single_skill_no_skill_cash100000` | `TadACampaign_fig5a_no_skill` | `runs/paper_main/fig5a_single_skill/no_skill` | unset |
| `fig5a_single_skill_motif_search` | Motif Search | `bioskills-motif-search` | `TadACampaign_v2_formal_fig5a_single_skill_motif_search_cash100000` | `TadACampaign_fig5a_motif_search` | `runs/paper_main/fig5a_single_skill/motif_search` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_sequence_properties` | Sequence Properties | `bioskills-sequence-properties` | `TadACampaign_v2_formal_fig5a_single_skill_sequence_properties_cash100000` | `TadACampaign_fig5a_sequence_properties` | `runs/paper_main/fig5a_single_skill/sequence_properties` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_pairwise_alignment` | Pairwise Alignment | `bioskills-pairwise-alignment` | `TadACampaign_v2_formal_fig5a_single_skill_pairwise_alignment_cash100000` | `TadACampaign_fig5a_pairwise_alignment` | `runs/paper_main/fig5a_single_skill/pairwise_alignment` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_codon_usage` | Codon Usage | `bioskills-codon-usage` | `TadACampaign_v2_formal_fig5a_single_skill_codon_usage_cash100000` | `TadACampaign_fig5a_codon_usage` | `runs/paper_main/fig5a_single_skill/codon_usage` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_transcription_translation` | Transcription Translation | `bioskills-transcription-translation` | `TadACampaign_v2_formal_fig5a_single_skill_transcription_translation_cash100000` | `TadACampaign_fig5a_transcription_translation` | `runs/paper_main/fig5a_single_skill/transcription_translation` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_reverse_complement` | Reverse Complement | `bioskills-reverse-complement` | `TadACampaign_v2_formal_fig5a_single_skill_reverse_complement_cash100000` | `TadACampaign_fig5a_reverse_complement` | `runs/paper_main/fig5a_single_skill/reverse_complement` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_sequence_slicing` | Sequence Slicing | `bioskills-sequence-slicing` | `TadACampaign_v2_formal_fig5a_single_skill_sequence_slicing_cash100000` | `TadACampaign_fig5a_sequence_slicing` | `runs/paper_main/fig5a_single_skill/sequence_slicing` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_sequence_statistics` | Sequence Statistics | `bioskills-sequence-statistics` | `TadACampaign_v2_formal_fig5a_single_skill_sequence_statistics_cash100000` | `TadACampaign_fig5a_sequence_statistics` | `runs/paper_main/fig5a_single_skill/sequence_statistics` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_filter_sequences` | Filter Sequences | `bioskills-filter-sequences` | `TadACampaign_v2_formal_fig5a_single_skill_filter_sequences_cash100000` | `TadACampaign_fig5a_filter_sequences` | `runs/paper_main/fig5a_single_skill/filter_sequences` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_msa_statistics` | MSA Statistics | `bioskills-msa-statistics` | `TadACampaign_v2_formal_fig5a_single_skill_msa_statistics_cash100000` | `TadACampaign_fig5a_msa_statistics` | `runs/paper_main/fig5a_single_skill/msa_statistics` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_distance_calculations` | Distance Calculations | `bioskills-distance-calculations` | `TadACampaign_v2_formal_fig5a_single_skill_distance_calculations_cash100000` | `TadACampaign_fig5a_distance_calculations` | `runs/paper_main/fig5a_single_skill/distance_calculations` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_restriction_sites` | Restriction Sites | `bioskills-restriction-sites` | `TadACampaign_v2_formal_fig5a_single_skill_restriction_sites_cash100000` | `TadACampaign_fig5a_restriction_sites` | `runs/paper_main/fig5a_single_skill/restriction_sites` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |

### 12 个 BioSkills 的用途和决策作用

前 8 个最适合直接用在单步序列 triage；后 4 个仍然 CPU/local，但通常需要 agent 把候选、seed、已 confirm hit 整理成小 FASTA、alignment 或 digest 输入，适合作为辅助分析。

| Setting ID | Skill condition | Forced skill id | bioSkills source path | 主要作用 | Agent 如何用结果决策 |
| --- | --- | --- | --- | --- | --- |
| `fig5a_single_skill_motif_search` | Motif Search | `bioskills-motif-search` | `sequence-manipulation/motif-search` | 扫描 DNA 序列中的 motif、重复片段、start/stop/ORF 相关模式或命中的局部模式。 | 对 pending candidate 和已知高活性序列做 motif 对比；若候选含有在高活性 hit 中反复出现的模式，可优先 confirm 或围绕该模式开新 branch；若出现明显风险模式，可推迟确认。 |
| `fig5a_single_skill_sequence_properties` | Sequence Properties | `bioskills-sequence-properties` | `sequence-manipulation/sequence-properties` | 计算长度、GC、分子量、蛋白翻译后基础理化性质等序列级指标。 | 用 GC、长度、翻译后性质和简单 liabilities 比较候选与 seed/confirmed best；帮助决定是否继续 mine 当前 branch、是否 confirm 一个看起来更稳的候选。 |
| `fig5a_single_skill_pairwise_alignment` | Pairwise Alignment | `bioskills-pairwise-alignment` | `alignment/pairwise-alignment` | 对两个 DNA/RNA/protein 序列做 local/global alignment，量化相似度和突变差异。 | 将 pending candidate 对齐 seed、branch parent 或 confirmed best；用突变距离和保守区域变化判断候选是小步优化还是过度偏离，从而选择 confirm、继续挖掘或换 branch。 |
| `fig5a_single_skill_codon_usage` | Codon Usage | `bioskills-codon-usage` | `sequence-manipulation/codon-usage` | 统计 codon composition、稀有 codon、stop codon 和表达相关偏差。 | 对 DNA candidate 做表达可行性 triage；若高分候选有异常 stop/稀有 codon 负担，agent 可以降低 confirmation 优先级或用该 branch 的其他候选替代。 |
| `fig5a_single_skill_transcription_translation` | Transcription Translation | `bioskills-transcription-translation` | `sequence-manipulation/transcription-translation` | 将 DNA 转录/翻译成 RNA/protein，检查 ORF、终止密码子和蛋白序列变化。 | 把 agent 可见的 DNA 候选转换成蛋白层面的变化；判断突变是否导致提前终止、明显长度变化或氨基酸替换集中，从而影响 confirm/stop。 |
| `fig5a_single_skill_reverse_complement` | Reverse Complement | `bioskills-reverse-complement` | `sequence-manipulation/reverse-complement` | 生成反向互补链，检查方向性和互补链 motif。 | 当候选序列方向、motif 命中方向或子序列解释不清时，用 reverse complement 排除错误解释；避免 agent 基于错误链方向做确认或分支选择。 |
| `fig5a_single_skill_sequence_slicing` | Sequence Slicing | `bioskills-sequence-slicing` | `sequence-manipulation/sequence-slicing` | 按坐标提取、拼接、比较局部序列片段。 | 将突变窗口、motif 周边、ORF 区段从 candidate/seed 中切出单独分析；帮助定位高活性变化来自哪个局部区域，再决定下一轮 library 应围绕哪里展开。 |
| `fig5a_single_skill_sequence_statistics` | Sequence Statistics | `bioskills-sequence-statistics` | `sequence-io/sequence-statistics` | 对一组 FASTA 序列汇总长度、碱基组成、N content、GC 分布等批量统计。 | Agent 可把已观察候选、confirmed hit、pending candidate 写成小 FASTA，比较高低活性组的 composition 差异；用于决定继续当前 branch 还是换 branch。 |
| `fig5a_single_skill_filter_sequences` | Filter Sequences | `bioskills-filter-sequences` | `sequence-io/filter-sequences` | 按长度、composition、ambiguous bases、motif 或质量规则筛掉不合格序列。 | 对多个候选或 branch 备选序列做规则化预筛选；减少把预算花在明显低质量或不符合约束的 confirmation 上。 |
| `fig5a_single_skill_msa_statistics` | MSA Statistics | `bioskills-msa-statistics` | `alignment/msa-statistics` | 从小型 MSA 计算 conservation、entropy、gap、consensus 等统计。 | 当 agent 已积累多个同 branch 候选或 confirmed/provisional hit 时，可构造小 alignment，识别保守/可变位置；用于判断下一步更适合开 library、mine 还是 confirm。 |
| `fig5a_single_skill_distance_calculations` | Distance Calculations | `bioskills-distance-calculations` | `phylogenetics/distance-calculations` | 计算序列间距离矩阵或简单进化距离。 | 把 seed、不同 branch hit、pending candidate 的距离量化；帮助 agent 在 exploitation 和 exploration 之间取舍，避免只确认高度冗余候选。 |
| `fig5a_single_skill_restriction_sites` | Restriction Sites | `bioskills-restriction-sites` | `restriction-analysis/restriction-sites` | 扫描限制性内切酶识别位点和克隆相关序列特征。 | 如果候选需要可构建性/克隆可行性约束，agent 可避开含不利 restriction sites 的候选；在 activity 相近时优先 confirm 更容易构建的序列。 |

### Fig. 5a 可复制 Prompt

复制后只替换 `SINGLE_SKILL_SETTING` 为上方 Fig. 5a 正式 setting 表中的一行。BioSkills setting 必须使用 `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` 或等价 manifest；如果该 manifest 尚未构建，请先按下方 BioSkills manifest 准备步骤创建，不要改跑旧 skill manifest。

```text
请在当前 TadA-Campaign 仓库根目录为 Fig. 5a single-skill-effect 的一个 formal setting 运行 canonical 5-seed serial repeats。

SINGLE_SKILL_SETTING：
- figure_id = "Fig. 5a"
- experiment_theme = "Single-skill effect on agent behavior"
- setting_id = "<从 Fig. 5a 表格选择>"
- setting_name = "<No skill / BioSkill name>"
- purpose = "测试开局强制拥有一个真实 skill 文件是否会改变 Codex agent 的 downstream experimental choices，包括 branch opening、mining、confirmation 和 stopping；同时审计 agent 是否选择调用该 skill 获取结果、分析结果并用于决策。"
- independent_variable = "forced_initial_owned_skill"
- control_variables = "Codex backend; initial_cash=100000; skill market purchase surface disabled; one forced owned skill at a time; no prompt append; matched canonical 5-seed serial repeats; same horizon/cost/noise/reward setting."
- name = "<对应表中的 name>"
- initial_cash = 100000.0
- [agent].backend = "codex"
- [agent].model = "OMIT"
- [agent].reasoning_effort = "OMIT"
- skill_condition = "<对应 Skill condition>"
- forced_skill_id = "<对应 Forced skill id；No skill 为 unset>"
- market_condition = "no_market"
- skill_market_enabled = "<No skill 为 unset；forced skill setting 为 false>"
- prompt_append = "unset"
- manifest = "<对应 Manifest；No skill 为 unset>"
- tmux session = "<对应 tmux>"
- output_root = "<对应 output_root>"

执行要求：
1. 不要新建或切换 worktree；直接在当前 checkout 中操作。
2. 如果 prepared/manifest.json 不存在，先运行 uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared。
3. Forced BioSkill setting 如果 manifest 不存在，先按本文档 Fig. 5b 的 BioSkills manifest 准备步骤构建 `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` 或等价 manifest；只允许写入 /tmp/TadACampaign_skill_scout 和 /tmp/TadACampaign_skill_market。
4. 按本文档 “Serial 5-Seed tmux 启动模式” 创建 5 个 seed output_root，并用 `scripts/create_formal_setting.py --seed <SEED>` 从 baseline 生成 5 个 `<output_root>/seed<SEED>/setting.toml`。
5. No skill setting 生成 setting 时只设置 name、initial_cash、[agent].backend，不传 skill market 参数。
6. Forced skill setting 生成 setting 时必须额外传入 `--skill-market-manifest "<manifest>" --no-skill-market-enabled --initial-owned-skill-id "<forced_skill_id>"`。
7. 检查每个 `<output_root>/seed<SEED>/setting.toml`：forced skill setting 必须包含 `[judge].skill_market_manifest`、`[judge].skill_market_enabled = false`、`[judge].initial_owned_skill_ids = ["<forced_skill_id>"]`；No skill setting 不应包含这些字段。
8. 启动前必须在 tmux 命令内部执行 unset TADACAMPAIGN_SKILL_MARKET_MANIFEST 和 unset TADACAMPAIGN_AGENT_PROMPT_APPEND；Fig. 5a 不使用 prompt append，也不依赖 env manifest override。
9. 按 `601` 到 `605` 顺序一次启动 1 个 seed tmux session；每个 session export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE 指向 `<output_root>/seed<SEED>/setting.toml`，然后运行 `bash scripts/run_TadACampaign_v2.sh formal <output_root>/seed<SEED>`；当前 seed session 结束并整理结果后，再启动下一个 seed。
10. 启动前告诉我当前 checkout 绝对路径，并列出 5 个 seed、seed-specific name、tmux session、seed output_root、forced_skill_id、manifest path，以及这些结果文件夹用于 Fig. 5a 的哪个 single-skill setting。
11. 对当前 seed session 持续监控，直到它结束；找到该 seed 的最终 RUN_DIR 并整理 operator outputs，完成后再进入下一个 seed。
12. 对每个 RUN_DIR 读取 results/summary.json、results/action_log.jsonl、process/agent_workspace/owned_skills_index.json；forced skill setting 还要确认 `owned_skill_count > 0`、`skill_market_enabled = false`、`skill_market_size = 0`、`total_skill_purchase_price_paid = 0`，并确认 `owned_skills/<forced_skill_id>/source/SKILL.md` 存在。
13. 对每个 RUN_DIR 检查 process/agent_workspace/skill_analysis/ 是否存在；如存在，记录其中 JSON/Markdown/CSV/TXT/LOG 等 artifact 路径、关键结果，以及 action reasoning 是否引用了这些结果。如不存在，记录“未观察到 tool-backed skill use artifact”；这不自动表示 run 失败。
14. 对每个 RUN_DIR 调用 `scripts/write_TadACampaign_operator_outputs.py` 生成 EXPERIMENT_CARD.md、operator_summary.md、operator_event_log.csv、operator_run_summary.csv；参数使用本 setting 的 figure_id、experiment_theme、setting_id、setting_name、AGENT_NAME="Codex"、INITIAL_CASH="100000.0"、independent_variable、control_variables、purpose、对应 seed output_root、skill_condition、market_condition、PROMPT_APPEND_MODE="unset"、MANIFEST_PATH。
15. 最后汇总 5 个 RUN_DIR 绝对路径、5 个 replay_seed、每个 seed 的 confirmed_best_activity、cash_final、stop_reason 和 operator_summary.md 路径。
```

## Fig. 5b：Skill Market Effect

固定条件：

- Agent：Codex
- Initial cash：`100000.0`
- Replay seed / costs / noise / reward：默认使用 canonical 5-seed repeats；其余成本、噪声和 reward 不变。single-run debug 才使用 baseline 默认 seed
- 目的：测试 agent 在 market 环境下是否购买 skill、买什么、何时买，以及购买后是否改变后续实验策略；购买后 agent 携带该 skill，可选择调用其说明、工具或流程获得结果，分析后用于决策

| Setting ID | Market condition | `name` | `tmux` | `output_root` | Manifest |
| --- | --- | --- | --- | --- | --- |
| `fig5b_skill_market_no_market` | No market | `TadACampaign_v2_formal_fig5b_skill_market_no_market_cash100000` | `TadACampaign_fig5b_no_market` | `runs/paper_main/fig5b_skill_market/no_market` | unset |
| `fig5b_skill_market_full_neutral` | 12-BioSkills neutral market | `TadACampaign_v2_formal_fig5b_skill_market_full_neutral_cash100000` | `TadACampaign_fig5b_full_neutral_market` | `runs/paper_main/fig5b_skill_market/full_neutral_market` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5b_skill_market_full_marketing` | 12-BioSkills marketing market | `TadACampaign_v2_formal_fig5b_skill_market_full_marketing_cash100000` | `TadACampaign_fig5b_full_marketing_market` | `runs/paper_main/fig5b_skill_market/full_marketing_market` | `/tmp/TadACampaign_skill_market/bioskills_screened12_marketing/skill_market.json` |

### Skill Market 准备

Fig. 5a forced-skill setting 和 Fig. 5b market setting 都使用同一组 12 个 TadA-Campaign-screened BioSkills。不要使用默认 curated market；默认 curated market 仍包含已经被替换掉的旧 skill pool。这里直接构建只包含 12 个 BioSkills 的 manifest，market id 记为 `TadACampaign-bioskills-screened12`，价格保持 `1000.0`，让 market setting 更容易观察到 agent 是否购买、如何使用 skill，同时避免 neutral/marketing 条件之间引入不同价格。

12-BioSkills market 只需要这个本地 source checkout：

| Source | 目标目录 |
| --- | --- |
| `GPTomics/bioSkills` | `/tmp/TadACampaign_skill_scout/bioSkills` |

如果该 checkout 不存在，先运行：

```bash
mkdir -p /tmp/TadACampaign_skill_scout
if [ ! -d /tmp/TadACampaign_skill_scout/bioSkills ]; then
  gh repo clone GPTomics/bioSkills /tmp/TadACampaign_skill_scout/bioSkills
fi
```

构建 12-BioSkills neutral manifest：

```bash
mkdir -p /tmp/TadACampaign_skill_market/bioskills_screened12_neutral/sources

python3 - <<'PY'
from pathlib import Path
import json
import shutil

source_root = Path("/tmp/TadACampaign_skill_scout/bioSkills")
output_dir = Path("/tmp/TadACampaign_skill_market/bioskills_screened12_neutral")
sources_dir = output_dir / "sources"
price = 1000.0

skills = [
    {
        "skill_id": "bioskills-motif-search",
        "display_name": "Motif Search",
        "summary": "Scan candidate DNA sequences for motifs, repeats, ORF-related patterns, and recurring hit-local patterns.",
        "source_path": "sequence-manipulation/motif-search",
        "tags": ["sequence", "motif", "screening"],
    },
    {
        "skill_id": "bioskills-sequence-properties",
        "display_name": "Sequence Properties",
        "summary": "Compute GC, length, molecular weight, translated-protein properties, and basic sequence liabilities.",
        "source_path": "sequence-manipulation/sequence-properties",
        "tags": ["sequence", "properties", "triage"],
    },
    {
        "skill_id": "bioskills-pairwise-alignment",
        "display_name": "Pairwise Alignment",
        "summary": "Align candidate sequences against seed, parent branch, or confirmed best sequences to quantify similarity and mutation burden.",
        "source_path": "alignment/pairwise-alignment",
        "tags": ["sequence", "alignment", "comparison"],
    },
    {
        "skill_id": "bioskills-codon-usage",
        "display_name": "Codon Usage",
        "summary": "Count codons, detect stop codons, and summarize expression-oriented codon composition.",
        "source_path": "sequence-manipulation/codon-usage",
        "tags": ["sequence", "codon", "expression"],
    },
    {
        "skill_id": "bioskills-transcription-translation",
        "display_name": "Transcription Translation",
        "summary": "Transcribe and translate DNA candidates to inspect ORFs, stops, protein-length changes, and amino-acid substitutions.",
        "source_path": "sequence-manipulation/transcription-translation",
        "tags": ["sequence", "translation", "orf"],
    },
    {
        "skill_id": "bioskills-reverse-complement",
        "display_name": "Reverse Complement",
        "summary": "Generate reverse complements and check strand direction before interpreting motifs or subsequences.",
        "source_path": "sequence-manipulation/reverse-complement",
        "tags": ["sequence", "strand", "sanity-check"],
    },
    {
        "skill_id": "bioskills-sequence-slicing",
        "display_name": "Sequence Slicing",
        "summary": "Extract and compare local sequence windows around mutations, motifs, ORFs, or candidate-specific regions.",
        "source_path": "sequence-manipulation/sequence-slicing",
        "tags": ["sequence", "subsequence", "local-analysis"],
    },
    {
        "skill_id": "bioskills-sequence-statistics",
        "display_name": "Sequence Statistics",
        "summary": "Summarize length and composition statistics across a small FASTA of candidates, hits, and seeds.",
        "source_path": "sequence-io/sequence-statistics",
        "tags": ["sequence", "fasta", "statistics"],
    },
    {
        "skill_id": "bioskills-filter-sequences",
        "display_name": "Filter Sequences",
        "summary": "Filter sequence sets by length, composition, ambiguity, or simple sequence-quality constraints.",
        "source_path": "sequence-io/filter-sequences",
        "tags": ["sequence", "filtering", "quality"],
    },
    {
        "skill_id": "bioskills-msa-statistics",
        "display_name": "MSA Statistics",
        "summary": "Compute conservation, entropy, gap, and consensus statistics from small alignments.",
        "source_path": "alignment/msa-statistics",
        "tags": ["sequence", "msa", "conservation"],
    },
    {
        "skill_id": "bioskills-distance-calculations",
        "display_name": "Distance Calculations",
        "summary": "Compute sequence-distance summaries to compare exploration diversity against local exploitation.",
        "source_path": "phylogenetics/distance-calculations",
        "tags": ["sequence", "distance", "diversity"],
    },
    {
        "skill_id": "bioskills-restriction-sites",
        "display_name": "Restriction Sites",
        "summary": "Scan DNA candidates for restriction sites and cloning-relevant sequence features.",
        "source_path": "restriction-analysis/restriction-sites",
        "tags": ["sequence", "restriction", "constructability"],
    },
]

if not source_root.is_dir():
    raise SystemExit(f"Missing bioSkills checkout: {source_root}")

if output_dir.exists():
    shutil.rmtree(output_dir)
sources_dir.mkdir(parents=True, exist_ok=True)

manifest = {"version": 1, "market_id": "TadACampaign-bioskills-screened12", "skills": []}
audit = {"market_id": manifest["market_id"], "source_root": str(source_root), "skill_count": len(skills), "skills": []}

for item in skills:
    source_dir = source_root / item["source_path"]
    skill_md = source_dir / "SKILL.md"
    if not skill_md.is_file():
        raise SystemExit(f"Missing SKILL.md for {item['skill_id']}: {skill_md}")
    package_root = sources_dir / item["skill_id"]
    shutil.copytree(source_dir, package_root)
    manifest["skills"].append({
        "skill_id": item["skill_id"],
        "display_name": item["display_name"],
        "price": price,
        "summary": item["summary"],
        "description": "Screened BioSkills panel for TadA-Campaign DNA benchmark. Full local instructions unlock after purchase or forced ownership.",
        "tags": item["tags"],
        "source_repo": "GPTomics/bioSkills",
        "source_path": item["source_path"],
        "package_root": f"sources/{item['skill_id']}",
    })
    audit["skills"].append({
        "skill_id": item["skill_id"],
        "source_path": item["source_path"],
        "copied_from": str(source_dir),
        "copied_to": str(package_root),
    })

(output_dir / "skill_market.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
(output_dir / "market_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(output_dir / "skill_market.json")
PY
```

构建 marketing manifest。Marketing 条件只改 market card 文案，payload、price、skill_id、package_root 和 neutral 条件保持一致：

```bash
rm -rf /tmp/TadACampaign_skill_market/bioskills_screened12_marketing
cp -a /tmp/TadACampaign_skill_market/bioskills_screened12_neutral \
  /tmp/TadACampaign_skill_market/bioskills_screened12_marketing

python3 - <<'PY'
from pathlib import Path
import json

manifest_path = Path("/tmp/TadACampaign_skill_market/bioskills_screened12_marketing/skill_market.json")
payload = json.loads(manifest_path.read_text(encoding="utf-8"))
payload["market_id"] = "TadACampaign-bioskills-screened12-marketing"
for skill in payload["skills"]:
    skill["summary"] = "High-impact TadA-Campaign decision-support BioSkill: " + skill["summary"]
    skill["description"] = (
        "Marketing preview only; payload, price, skill_id, and package_root are unchanged. "
        "This card emphasizes likely value for TadA DNA candidate triage, confirmation choices, and branch selection. "
        + skill["description"]
    )
manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY
```

构建后用下面命令检查 manifest 能被当前 runner 加载：

```bash
PYTHONPATH=src python3 - <<'PY'
from pathlib import Path
from TadACampaign.skill_market import load_skill_market_catalog

for manifest in [
    Path("/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json"),
    Path("/tmp/TadACampaign_skill_market/bioskills_screened12_marketing/skill_market.json"),
]:
    catalog = load_skill_market_catalog(manifest)
    market = catalog.market_snapshot(owned_skill_ids=set(), purchase_days=1.0, daily_burn_cost=800.0)
    prices = sorted({entry.price for entry in catalog.ordered_entries()})
    total_costs = sorted({card["total_cost"] for card in market["cards"]})
    print(manifest)
    print(len(catalog.ordered_entries()))
    print("prices", prices)
    print("total_costs", total_costs)
    print([entry.skill_id for entry in catalog.ordered_entries()])
PY
```

每个 manifest 都必须输出 12 个 skill、`prices [1000.0]` 和 `total_costs [1800.0]`。否则先修正 manifest 或 source checkout，再运行 Fig. 5a / Fig. 5b skill setting。

### Market Evaluation Block

```text
Skill Market evaluation instruction:
1. At every decision point, read agent_playbook.md, available_actions.json, skill_market.json, owned_skills_index.json, state.json, and history.json in that order.
2. Treat purchase_skill as an optional investment action, not a mandatory action.
3. Buy a skill only if its expected improvement to downstream branch opening, mining, confirmation, or stopping decisions plausibly exceeds purchase price plus one day of burn, while still preserving enough budget/time for at least one useful experimental action afterward.
4. If purchase_skill succeeds, immediately inspect owned_skills/<skill_id>/source/SKILL.md. Treat the purchased skill as an optional decision-support capability: when useful, follow its local instructions, tools, scripts, requirements, examples, checklists, or query workflow to obtain results and improve later prepare_seed, prepare_library, mine_library, confirm_hit, purchase_skill, or stop decisions.
5. If you call a skill-provided tool or workflow and it produces results or artifacts, save outputs under skill_analysis/ and cite the concrete artifact path and findings in later --reasoning when they affect a benchmark action.
6. It is acceptable not to call a skill tool when there is no relevant input, when the skill does not fit the current decision, or when setup cost/risk is not worth it.
7. Continue using only ./TadACampaign-agent-step for state changes. Do not manually edit state files.
8. Within a suitable budget/time range, further exploration can reveal higher-activity proteins and materially higher confirmation reward; continue only when the next action preserves a credible path to higher final cash, otherwise stop.
```

### Fig. 5b 可复制 Prompt

复制后只替换 `MARKET_SETTING` 为表格中的一行。

```text
请在当前 TadA-Campaign 仓库根目录为 Fig. 5b skill-market-effect 的一个 formal setting 运行 canonical 5-seed serial repeats。

MARKET_SETTING：
- figure_id = "Fig. 5b"
- experiment_theme = "Skill-market effect on agent behavior"
- setting_id = "<从 Fig. 5b 表格选择>"
- setting_name = "<No market / 12-BioSkills neutral market / 12-BioSkills marketing market>"
- purpose = "测试 Codex agent 在 skill market 环境下是否购买 skill、何时购买、买完以后是否改变 branch opening、mining、confirmation 和 stopping 策略，并审计购买后的 skill 是否被调用以获得结果、分析结果并支持决策。"
- independent_variable = "skill_market_condition"
- control_variables = "Codex backend; initial_cash=100000; same 12-BioSkills pool and price for market settings; matched canonical 5-seed serial repeats; same horizon/cost/noise/reward setting; marketing market only changes preview wording."
- name = "<对应表中的 name>"
- initial_cash = 100000.0
- [agent].backend = "codex"
- [agent].model = "OMIT"
- [agent].reasoning_effort = "OMIT"
- skill_condition = "market_access"
- market_condition = "<No market / 12-BioSkills neutral market / 12-BioSkills marketing market>"
- prompt_append = "<No market 为 unset；market setting 为 Market Evaluation Block 完整文本；这是 market 评估提示，不是 skill 本体>"
- manifest = "<unset 或对应 manifest path>"
- tmux session = "<对应 tmux>"
- output_root = "<对应 output_root>"

执行要求：
1. 不要新建或切换 worktree；直接在当前 checkout 中操作。
2. 如果 prepared/manifest.json 不存在，先运行 uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared。
3. 按 canonical repeat seeds `601`、`602`、`603`、`604`、`605` 生成 5 个 `<output_root>/seed<SEED>/setting.toml`；每个 setting 写入 seed-specific name、seed、initial_cash、[agent].backend，以及 market setting 的 `[judge].skill_market_manifest` / `[judge].skill_market_enabled`；不要保留 [agent].model、reasoning_effort、profile、verbosity 等非默认字段。
4. 其他 formal 默认参数全部保持不变。
5. No market setting 执行 unset TADACAMPAIGN_SKILL_MARKET_MANIFEST 和 unset TADACAMPAIGN_AGENT_PROMPT_APPEND。
6. Market setting 如果 manifest 不存在，先按本文档 Skill Market 准备步骤构建；只允许写入 /tmp/TadACampaign_skill_scout 和 /tmp/TadACampaign_skill_market。启动前必须检查 manifest 输出为 12 个 skill、`prices [1000.0]` 和 `total_costs [1800.0]`。
7. Market setting 对每个 seed 用 `scripts/create_formal_setting.py --seed <SEED> --skill-market-manifest "<manifest>" --skill-market-enabled` 把 manifest 写进 `<output_root>/seed<SEED>/setting.toml`；不要依赖 `TADACAMPAIGN_SKILL_MARKET_MANIFEST` env override。
8. Market setting 启动前在 tmux 命令内部 unset TADACAMPAIGN_SKILL_MARKET_MANIFEST，并 export TADACAMPAIGN_AGENT_PROMPT_APPEND='<Market Evaluation Block 完整文本>'。这个 prompt append 只要求 agent 认真评估 market，不提供任何 skill 文件内容。
9. 按本文档 “Serial 5-Seed tmux 启动模式” 创建 5 个 seed output_root、生成 5 个 setting.toml，并按 `601` 到 `605` 顺序一次启动 1 个 seed tmux session；每个 session export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE 指向对应 seed 的 setting.toml，然后运行 `bash scripts/run_TadACampaign_v2.sh formal <output_root>/seed<SEED>`；当前 seed session 结束并整理结果后，再启动下一个 seed。
10. 启动前告诉我当前 checkout 绝对路径，并列出 5 个 seed、seed-specific name、tmux session、seed output_root、实际使用的 manifest path，以及这些结果文件夹用于 Fig. 5b 的哪个 market setting。
11. 对当前 seed session 持续监控，直到它结束；找到该 seed 的最终 RUN_DIR 并整理 operator outputs，完成后再进入下一个 seed。
12. 对每个 RUN_DIR 读取 results/summary.json 和 results/action_log.jsonl；market setting 还要记录是否出现 `purchase_skill`、购买了哪些 skill、购买后 action reasoning 是否引用 owned skill。
13. 检查 RUN_DIR/process/agent_workspace/skill_analysis/ 是否存在；如存在，记录其中 JSON/Markdown/CSV/TXT/LOG 等 artifact 路径和关键结果，并判断是否发生在 purchase 后或 forced owned skill 可见后。如不存在，记录“未观察到 tool-backed skill use artifact”；这不自动表示 run 失败。
14. 对每个 RUN_DIR 调用 `scripts/write_TadACampaign_operator_outputs.py` 生成 EXPERIMENT_CARD.md、operator_summary.md、operator_event_log.csv、operator_run_summary.csv；参数使用本 setting 的 figure_id、experiment_theme、setting_id、setting_name、AGENT_NAME="Codex"、INITIAL_CASH="100000.0"、independent_variable、control_variables、purpose、对应 seed output_root、skill_condition、market_condition、PROMPT_APPEND_MODE="<unset 或 skill_market_prompt_append>"、MANIFEST_PATH。
15. 最后汇总 5 个 RUN_DIR 绝对路径、5 个 replay_seed、每个 seed 的 confirmed_best_activity、cash_final、stop_reason 和 operator_summary.md 路径。
```

## 后续合并作图数据

所有 setting 跑完后，可以合并每个 run 的 operator CSV：

```bash
mkdir -p runs/paper_main/tables
python3 - <<'PY'
from pathlib import Path
import csv

root = Path("runs/paper_main")
event_paths = sorted(root.glob("**/results/operator_event_log.csv"))
summary_paths = sorted(root.glob("**/results/operator_run_summary.csv"))

def merge(paths, out_path):
    if not paths:
        return
    fieldnames = None
    rows = []
    for path in paths:
        with path.open(encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if fieldnames is None:
                fieldnames = reader.fieldnames
            rows.extend(reader)
    with out_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

merge(event_paths, root / "tables" / "event_log.csv")
merge(summary_paths, root / "tables" / "run_summary.csv")
print(root / "tables" / "event_log.csv")
print(root / "tables" / "run_summary.csv")
PY
```

这两个合并表用于后续绘制：

- `runs/paper_main/tables/event_log.csv`
- `runs/paper_main/tables/run_summary.csv`

过滤方式：

- Fig. 3：`figure_id == "Fig. 3"`
- Fig. 4：`figure_id == "Fig. 4"`
- Fig. 5a：`figure_id == "Fig. 5a"`
- Fig. 5b：`figure_id == "Fig. 5b"`

## 常见红旗

- `summary.json` 的 `stop_reason` 以 `backend_error:` 开头：这不是成功完成的策略结果。
- `results/rejection_log.jsonl` 很长：agent 可能反复提交非法动作。
- `confirmed_best_activity` 明显低于 `provisional_best_activity` 且没有 confirm：agent 可能错过兑现 reward。
- 低预算 setting 很快 stop：不一定是错误，需要结合 cash runway、legal actions 和 confirm 成本判断。
- market setting 没有 `purchase_skill`：不一定是错误；Fig. 5b 本来就要观察 agent 是否购买、何时购买、买后是否改变策略。
- 同一 checkout 同时跑多个 setting：虽然每个 setting 都有自己的 `setting.toml`，但 tmux session、output_root、host judge 端口、Skill Market env 和 operator 汇总仍然可能混淆。正式记录建议一次启动并确认一个 setting 的 5 个 serial seeds 都完成、结果都保存后，再启动下一个 setting。
