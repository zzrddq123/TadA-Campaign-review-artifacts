import json
import random
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

from tests.test_backends import _config
from tests.test_policies import _observation
from TadACampaign import jev_policy
from TadACampaign.policies import make_policy_memory, select_action


class FakeChoiceClient:
    def system_one(self, **kwargs):
        criteria = kwargs["questions"]["action"].criteria
        choice = next(iter(criteria))
        probabilities = {key: 0.0 for key in criteria}
        probabilities[choice] = 1.0
        return SimpleNamespace(
            answers={
                "action": SimpleNamespace(
                    choice=choice,
                    probabilities=probabilities,
                    confidence=0.9,
                )
            },
            usage=SimpleNamespace(input_tokens=10, output_tokens=0),
        )


def test_jev_family_model_defaults_and_aliases() -> None:
    assert jev_policy._default_model_for_policy("jev_k1") == "typesafe-ai/jev"
    assert jev_policy._default_model_for_policy("d1_k1") == "liquid/d1"
    assert jev_policy._default_model_for_policy("laya_k1") == "convaiinnovations/laya-free"
    assert jev_policy._gateway_model("convaiinnovations/laya") == "convaiinnovations/laya"


def test_tokendance_jev_models_share_the_compact_choice_head() -> None:
    assert {"ateve-jev-v1", "bocha-jev-v1"}.issubset(jev_policy.COMPACT_CHOICE_MODELS)


def test_laya_choice_aliases_keep_the_choice_head_compact() -> None:
    criteria = {
        "prepare_library:seed1:seed1_library1": "Prepare library seed1_library1 from seed seed1, window=aa2-32; cost=1742.0; never-mined.",
        "mine_library:seed1:seed1_library1:batch=780": "Mine library seed1_library1 from seed seed1, batch_size=780; never-mined, window=aa2-32, cost=1200.0, remaining=100, leaves_confirm_capacity=True .",
        "stop": "Stop the campaign and preserve the current ledger.",
    }
    compact = jev_policy._laya_choice_criteria(criteria)
    aliases = jev_policy._laya_choice_aliases(criteria)

    assert list(compact) == ["a1", "a2", "stop"]
    assert compact["a1"] == "open aa2-32"
    assert compact["a2"] == "mine b780 c1200 confirmable"
    assert aliases["a1"] == "prepare_library:seed1:seed1_library1"
    restored = jev_policy._restore_laya_choice(
        "a2",
        {"a1": 0.1, "a2": 0.8, "stop": 0.1},
        ["a2"],
        aliases,
    )
    assert restored == (
        "mine_library:seed1:seed1_library1:batch=780",
        {
            "prepare_library:seed1:seed1_library1": 0.1,
            "mine_library:seed1:seed1_library1:batch=780": 0.8,
            "stop": 0.1,
        },
        ["mine_library:seed1:seed1_library1:batch=780"],
    )


def test_d1_policy_uses_the_existing_jev_choice_loop(tmp_path: Path, monkeypatch) -> None:
    runtime = jev_policy.JEVPolicyRuntime(FakeChoiceClient(), "liquid/d1", 1, "compact")
    monkeypatch.setattr(jev_policy, "_get_runtime", lambda memory, config, policy_name: runtime)
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy="d1_k1")

    decision = select_action(
        "d1_k1",
        config=config,
        observation=_observation(),
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action in {"stop", "prepare_seed", "prepare_library", "mine_library", "confirm_hit"}
    assert runtime.traces[0]["model"] == "liquid/d1"


def test_laya_payload_is_a_small_public_ledger_projection() -> None:
    projected = jev_policy._laya_state_payload(
        {
            "task": {"objective": "maximize cash"},
            "current": {
                "current_cash": 1000.0,
                "remaining_days": 10.0,
                "seeds": [{"seed_id": "seed1", "protein_sequence": "A" * 1000}],
            },
            "campaign_trace": [],
        }
    )

    assert projected["current"]["current_cash"] == 1000.0
    assert "seeds" not in projected["current"]
    assert "Biology hint:" not in projected["task"]["brief"]
    assert len(json.dumps(projected)) < 1500

    biology_projected = jev_policy._laya_state_payload(
        {
            "task": {"objective": "maximize cash"},
            "current": {"current_cash": 1000.0, "remaining_days": 10.0},
            "campaign_trace": [],
        },
        include_biology_context=True,
    )
    assert "Biology hint:" in biology_projected["task"]["brief"]
    assert len(json.dumps(biology_projected)) < 1500
