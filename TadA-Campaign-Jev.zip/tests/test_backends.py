import json
import subprocess
import time
from dataclasses import replace
from pathlib import Path

import pytest

import TadACampaign.backends as backends
from TadACampaign.backends import BackendError, run_backend_episode
from TadACampaign.models import ExperimentConfig, MineBatchOption, RewardTier


def _config(
    tmp_path: Path,
    *,
    timeout_seconds: int = 30,
    handoff_max_count: int = -1,
    backend: str = "codex",
    model: str | None = None,
    reasoning_effort: str | None = None,
    skill_market_manifest: Path | None = None,
) -> ExperimentConfig:
    return ExperimentConfig(
        name="backend_test",
        prepared_root=tmp_path,
        variant="protein",
        output_root=tmp_path,
        seed=1,
        initial_cash=1000.0,
        base_asset_value=1000.0,
        baseline_activity=1.0,
        prepare_seed_cost=25.0,
        prepare_seed_days=1.0,
        prepare_library_cost=10.0,
        daily_burn_cost=2.0,
        prepare_library_days=1.0,
        confirm_hit_cost=5.0,
        confirm_hit_days=1.0,
        purchase_skill_days=1.0,
        mine_batch_menu=(MineBatchOption(batch_size=1, cost=21.0, time_days=1.0),),
        initial_visible_seeds=("seed1",),
        initial_prepared_seeds=(),
        max_experiment_days=10.0,
        agent_timeout_seconds=timeout_seconds,
        reward_tiers=(RewardTier(min_activity=1.0, max_activity=float("inf"), multiplier=1.0),),
        linear_issue=None,
        agent_backend=backend,
        agent_model=model,
        agent_profile=None,
        agent_reasoning_effort=reasoning_effort,
        agent_verbosity=None,
        agent_codex_context_window_handoff_max_count=handoff_max_count,
        skill_market_manifest=skill_market_manifest,
        skill_market_enabled=True,
        initial_owned_skill_ids=(),
        judge_server_url=None,
        judge_request_timeout_seconds=10,
    )


def _jsonl(*payloads: dict) -> str:
    return "".join(json.dumps(payload, ensure_ascii=False) + "\n" for payload in payloads)


def _prepare_run_dirs(tmp_path: Path) -> tuple[Path, Path]:
    run_dir = tmp_path / "run"
    (run_dir / "results").mkdir(parents=True, exist_ok=True)
    agent_workspace = run_dir / "process" / "agent_workspace"
    agent_workspace.mkdir(parents=True, exist_ok=True)
    return run_dir, agent_workspace


def test_run_backend_episode_writes_json_events_and_final_result(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, model="gpt-5.4")
    commands: list[list[str]] = []
    captured_env: dict[str, str] = {}

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            captured_env.update(kwargs["env"])
            commands.append(list(command))
            self.returncode = 0
            self.pid = 4321

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del timeout
            assert "./TadACampaign-agent-step" in prompt
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-1"},
                    {"type": "turn.started"},
                    {
                        "type": "item.completed",
                        "item": {
                            "id": "msg-1",
                            "type": "agent_message",
                            "text": json.dumps(
                                {
                                    "status": "completed",
                                    "stop_reason": "agent_stop",
                                    "action_count": 3,
                                    "summary": "finished",
                                }
                            ),
                        },
                    },
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["thread_id"] == "thread-1"
    assert (run_dir / "results" / "codex_events.jsonl").is_file()
    assert (run_dir / "results" / "codex_final_result.json").is_file()
    assert commands
    command = commands[0]
    assert "--json" in command
    assert "-m" in command and "gpt-5.4" in command
    assert "--ephemeral" not in command
    assert "--output-schema" in command
    schema_path = Path(command[command.index("--output-schema") + 1])
    assert schema_path == run_dir / "results" / "codex_final_result_schema.json"
    assert json.loads(schema_path.read_text(encoding="utf-8"))["required"] == [
        "status",
        "stop_reason",
        "action_count",
        "summary",
    ]
    assert "-o" not in command
    assert command[command.index("--add-dir") + 1] == str(run_dir)
    assert "--full-auto" not in command
    assert "--search" not in command
    assert "--dangerously-bypass-approvals-and-sandbox" not in command
    assert "-s" not in command
    assert "TADACAMPAIGN_JUDGE_ADMIN_TOKEN" not in captured_env


def test_extract_codex_episode_result_accepts_final_json_embedded_in_text(tmp_path: Path) -> None:
    results_dir = tmp_path / "results"
    results_dir.mkdir(parents=True)
    events_path = results_dir / "codex_events.jsonl"
    result_path = results_dir / "codex_final_result.json"
    events_path.write_text(
        _jsonl(
            {"type": "thread.started", "thread_id": "thread-1"},
            {"type": "turn.started"},
            {
                "type": "item.completed",
                "item": {
                    "id": "msg-1",
                    "type": "agent_message",
                    "text": (
                        "实验已终止，返回最终JSON：\n"
                        '{"status":"completed","stop_reason":"done","action_count":2,"summary":"ok"}'
                    ),
                },
            },
            {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
        ),
        encoding="utf-8",
    )

    result = backends._extract_codex_episode_result(events_path, result_path)

    assert result["status"] == "completed"
    assert result["action_count"] == 2
    assert json.loads(result_path.read_text(encoding="utf-8"))["summary"] == "ok"


def test_run_backend_episode_resumes_after_premature_codex_final_json(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []
    (agent_workspace / "state.json").write_text(
        json.dumps({"action_count": 0, "current_cash": 1000.0}) + "\n",
        encoding="utf-8",
    )

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 0
            self.pid = 4400 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            if self.attempt == 1:
                return (
                    _jsonl(
                        {"type": "thread.started", "thread_id": "thread-1"},
                        {"type": "turn.started"},
                        {
                            "type": "item.completed",
                            "item": {
                                "id": "msg-1",
                                "type": "agent_message",
                                "text": json.dumps(
                                    {
                                        "status": "completed",
                                        "stop_reason": "premature",
                                        "action_count": 0,
                                        "summary": "not actually terminal",
                                    }
                                ),
                            },
                        },
                        {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                    ),
                    "",
                )
            (agent_workspace / "state.json").write_text(
                json.dumps({"action_count": 1, "stop_code": "agent_stop", "stop_reason": "done"}) + "\n",
                encoding="utf-8",
            )
            return (
                _jsonl(
                    {"type": "turn.started"},
                    {
                        "type": "item.completed",
                        "item": {
                            "id": "msg-2",
                            "type": "agent_message",
                            "text": json.dumps(
                                {
                                    "status": "completed",
                                    "stop_reason": "done",
                                    "action_count": 1,
                                    "summary": "resumed after premature final",
                                }
                            ),
                        },
                    },
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["thread_id"] == "thread-1"
    assert len(commands) == 2
    assert commands[1][-3:] == ["resume", "thread-1", "-"]
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["success"] is True
    assert meta["resume_count"] == 1
    assert meta["attempts"][0]["classification"] == "retryable_premature_completion"


def test_episode_prompt_appends_operator_override(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    config = _config(tmp_path)
    monkeypatch.setenv(backends.AGENT_PROMPT_APPEND_ENV, "Buy pds-campaign-manager before any other non-stop action.")

    prompt = backends._episode_prompt(config)

    assert "附加运营指令：" in prompt
    assert "Buy pds-campaign-manager before any other non-stop action." in prompt


def test_run_backend_episode_accepts_completed_turn_despite_transient_stream_error(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del command, kwargs
            self.returncode = 0
            self.pid = 4322

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-1"},
                    {"type": "turn.started"},
                    {"type": "error", "message": "stream disconnected before completion"},
                    {
                        "type": "item.completed",
                        "item": {
                            "id": "msg-1",
                            "type": "agent_message",
                            "text": json.dumps(
                                {
                                    "status": "completed",
                                    "stop_reason": "done",
                                    "action_count": 2,
                                    "summary": "completed despite transient stream error",
                                }
                            ),
                        },
                    },
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["thread_id"] == "thread-1"
    assert json.loads((run_dir / "results" / "codex_final_result.json").read_text(encoding="utf-8"))["status"] == "completed"
    assert not (run_dir / "results" / "codex_resume_meta.json").exists()


def test_run_backend_episode_rejects_missing_thread_started(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del command, kwargs
            self.returncode = 0
            self.pid = 4321

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            return (
                _jsonl(
                    {"type": "turn.started"},
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    with pytest.raises(BackendError, match="thread.started"):
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)


def test_episode_prompt_aligns_with_graph_driven_seed_semantics(tmp_path: Path) -> None:
    prompt = backends._episode_prompt(_config(tmp_path))

    assert "`agent_playbook.md`" in prompt
    assert "`AGENTS.md`" not in prompt
    assert "你是一名 AI 蛋白工程师" in prompt
    assert "`state.economic_summary`" in prompt
    assert "`configured_minimum_mine_then_confirm_total_cost`" in prompt
    assert "`available_mine_then_confirm_total_cost`" in prompt
    assert "`has_available_mine_option`" in prompt
    assert "`leaves_confirm_capacity=true`" in prompt
    assert "低预算时不要把钱全部花在探索和大 batch screening 上" in prompt
    assert "你作为当局者可以使用的信息" in prompt
    assert "当前 visible seeds、prepared seeds、prepared libraries" in prompt
    assert "你已经通过动作实际显露出来的探索路径" in prompt
    assert "visible seed 的 `start_sequence`" in prompt
    assert "prepared library 的可筛序列总数、已筛数量、剩余数量和当前合法 batch options" in prompt
    assert "`prepare_library` 只会准备当前 library" in prompt
    assert "`newly_visible_seed_ids` 和刷新后的 `visible_seed_ids` 会显示新的 visible seed" in prompt
    assert "`historical_round_id`" not in prompt
    assert "`unlock_child_seed_ids`" not in prompt
    assert "`prepare_seed` 只会把一个已 visible 的 seed 变成 prepared" in prompt
    assert "`mine_library` 是 screening 动作，不会直接发放 reward，也不会显露新的 seed" in prompt
    assert "screening 结果只会先暴露带噪声的 `observed_activity`" in prompt
    assert "`confirm_hit` 是把 provisional screen 结果转成 confirmed 结果、揭示 `confirmed_activity` 并可能触发 reward 的唯一动作" in prompt
    assert "更多探索可能发现活性更高的蛋白" in prompt
    assert "当剩余动作已没有可信的风险调整后现金提升路径时，应主动 `stop`" in prompt
    assert "持续行动，直到工具脚本返回" not in prompt
    assert "purchase_skill" not in prompt
    assert "skill_market.json" not in prompt
    assert "owned_skills_index.json" not in prompt
    assert "owned_skills/<skill_id>/source/SKILL.md" not in prompt
    assert "携带 skill 不代表每一步都必须使用" not in prompt
    assert "可选的决策支持能力" not in prompt
    assert "获得结果后进行分析" not in prompt
    assert "skill_analysis/" not in prompt
    assert "如果当前没有适合调用的 skill" not in prompt
    assert "必须读取并使用" not in prompt
    assert "并在后续动作选择中显式使用它" not in prompt
    assert "如果你没有特别强的理由" not in prompt
    assert "只根据 `available_actions.json` 和刷新后的 `state.json` 判断当前哪些动作与参数合法" in prompt
    assert "`seed_manifest.json`" not in prompt
    assert "固定时间上限是 10 个 `elapsed_day`" in prompt


def test_episode_prompt_includes_skill_surface_only_when_manifest_configured(tmp_path: Path) -> None:
    prompt = backends._episode_prompt(_config(tmp_path, skill_market_manifest=tmp_path / "skill_market.json"))

    assert "`skill_market.json`" in prompt
    assert "`owned_skills_index.json`" in prompt
    assert "`purchase_skill` 只用于 market 条件下解锁尚未 owned 的离线 skill 文件" in prompt
    assert "如果当前 `skill_market.json.cards` 为空但 `owned_skills_index.json` 非空" in prompt
    assert "`owned_skills/<skill_id>/source/SKILL.md`" in prompt
    assert "携带 skill 不代表每一步都必须使用" in prompt
    assert "可选的决策支持能力" in prompt
    assert "获得结果后进行分析" in prompt
    assert "`skill_analysis/`" in prompt
    assert "如果当前没有适合调用的 skill" in prompt


def test_run_backend_episode_rejects_missing_final_json_message(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del command, kwargs
            self.returncode = 0
            self.pid = 4321

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-1"},
                    {"type": "turn.started"},
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    with pytest.raises(BackendError, match="final text result"):
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)


def test_run_backend_episode_terminates_process_tree_on_timeout(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, timeout_seconds=1)
    terminated: list[object] = []

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del command, kwargs
            self.returncode = None
            self.pid = 4321
            self.communicate_calls = 0

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            self.communicate_calls += 1
            if self.communicate_calls == 1:
                raise subprocess.TimeoutExpired(cmd=["codex", "exec"], timeout=timeout or 0, output="", stderr="")
            self.returncode = -9
            return "", ""

    fake_process = FakeProcess([])
    monkeypatch.setattr(backends.subprocess, "Popen", lambda *args, **kwargs: fake_process)
    monkeypatch.setattr(backends, "_terminate_process_tree", lambda process: terminated.append(process))

    with pytest.raises(BackendError, match="timed out"):
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert terminated == [fake_process]
    assert (run_dir / "results" / "codex_command.txt").is_file()
    assert (run_dir / "results" / "codex_stderr.log").is_file()


def test_run_backend_episode_rejects_unsupported_backend(tmp_path: Path) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = replace(_config(tmp_path), agent_backend="claude-code")

    with pytest.raises(BackendError, match="Unsupported agent backend"):
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)


def test_run_backend_episode_resumes_retryable_interruption_with_same_thread(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.command = list(command)
            self.returncode = 23 if self.attempt == 1 else 0
            self.pid = 4321 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            if self.attempt == 1:
                (run_dir / "results" / "codex_final_result.json").write_text(
                    '{"status":"partial"}\n',
                    encoding="utf-8",
                )
                return (
                    _jsonl(
                        {"type": "thread.started", "thread_id": "thread-1"},
                        {"type": "turn.started"},
                        {"type": "error", "message": "stream disconnected before completion"},
                    ),
                    "stream disconnected before completion",
                )
            return (
                _jsonl(
                    {"type": "turn.started"},
                    {
                        "type": "item.completed",
                        "item": {
                            "id": "msg-2",
                            "type": "agent_message",
                            "text": json.dumps(
                                {
                                    "status": "completed",
                                    "stop_reason": "done",
                                    "action_count": 2,
                                    "summary": "resumed",
                                }
                            ),
                        },
                    },
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["thread_id"] == "thread-1"
    assert result["resume_meta_path"]
    assert commands[1][-3:] == ["resume", "thread-1", "-"]
    assert (run_dir / "results" / "codex_events_attempt1.jsonl").is_file()
    assert (run_dir / "results" / "codex_final_result_attempt1.json").is_file()
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["version"] == 2
    assert meta["success"] is True
    assert meta["resume_count"] == 1
    assert meta["handoff_count"] == 0
    assert meta["final_thread_id"] == "thread-1"
    assert meta["attempts_total"] == 2
    assert meta["attempts"][0]["classification"] == "retryable_interruption"
    assert meta["attempts"][1]["mode"] == "resume"
    assert json.loads((run_dir / "results" / "codex_final_result.json").read_text(encoding="utf-8"))["status"] == "completed"


def test_run_backend_episode_resumes_when_stream_missing_turn_completed(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.command = list(command)
            self.returncode = 0
            self.pid = 5300 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            if self.attempt == 1:
                return (
                    _jsonl(
                        {"type": "thread.started", "thread_id": "thread-1"},
                        {"type": "turn.started"},
                        {
                            "type": "item.completed",
                            "item": {
                                "id": "msg-1",
                                "type": "agent_message",
                                "text": "working",
                            },
                        },
                    ),
                    "",
                )
            return (
                _jsonl(
                    {"type": "turn.started"},
                    {
                        "type": "item.completed",
                        "item": {
                            "id": "msg-2",
                            "type": "agent_message",
                            "text": json.dumps(
                                {
                                    "status": "completed",
                                    "stop_reason": "done",
                                    "action_count": 2,
                                    "summary": "resumed after missing turn completion",
                                }
                            ),
                        },
                    },
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["thread_id"] == "thread-1"
    assert result["resume_meta_path"]
    assert commands[1][-3:] == ["resume", "thread-1", "-"]
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["success"] is True
    assert meta["attempts"][0]["classification"] == "retryable_missing_turn_completed"
    assert meta["handoff_count"] == 0


def test_run_backend_episode_uses_fresh_handoff_for_context_window_exhaustion(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    state_payload = {
        "elapsed_day": 100.0,
        "remaining_days": 265.0,
        "current_cash": 1234.0,
        "confirmed_best_activity": 1.8,
        "action_count": 7,
        "request_count": 8,
    }
    history_payload = {
        "recent_actions": [
            {"action": "prepare_seed", "seed_id": "seed2", "elapsed_day_after": 98.0, "cash_after": 1500.0},
            {"action": "mine_library", "seed_id": "seed2", "library_id": "seed2_library1", "elapsed_day_after": 100.0, "cash_after": 1234.0},
        ],
        "recent_rejections": [
            {"action": "mine_library", "seed_id": "seed2", "library_id": "seed2_library1", "rejection_reason": "illegal batch"}
        ],
    }
    (agent_workspace / "state.json").write_text(json.dumps(state_payload) + "\n", encoding="utf-8")
    (agent_workspace / "history.json").write_text(json.dumps(history_payload) + "\n", encoding="utf-8")

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 23 if self.attempt == 1 else 0
            self.pid = 6100 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del timeout
            if self.attempt == 1:
                return (
                    _jsonl(
                        {"type": "thread.started", "thread_id": "thread-ctx-1"},
                        {"type": "turn.started"},
                        {"type": "error", "message": "context_window_exceeded"},
                    ),
                    "context_window_exceeded",
                )
            assert "续跑交接说明：" in prompt
            assert "当前 `elapsed_day`：100.0" in prompt
            assert "AGENTS.md" not in prompt
            (agent_workspace / "state.json").write_text(
                json.dumps(
                    {
                        **state_payload,
                        "action_count": 9,
                        "stop_code": "agent_stop",
                        "stop_reason": "done",
                    }
                )
                + "\n",
                encoding="utf-8",
            )
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-ctx-2"},
                    {"type": "turn.started"},
                    {
                        "type": "item.completed",
                        "item": {
                            "id": "msg-2",
                            "type": "agent_message",
                            "text": json.dumps(
                                {
                                    "status": "completed",
                                    "stop_reason": "done",
                                    "action_count": 9,
                                    "summary": "continued after handoff",
                                }
                            ),
                        },
                    },
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["thread_id"] == "thread-ctx-2"
    assert len(commands) == 2
    assert commands[0][-1] == "-"
    assert commands[1][-1] == "-"
    assert "resume" not in commands[1]
    prompt_path = run_dir / "results" / "codex_handoff_prompt_attempt2.txt"
    assert prompt_path.is_file()
    timeline = (run_dir / "results" / "runtime_timeline.jsonl").read_text(encoding="utf-8")
    assert '"event": "codex.handoff.scheduled"' in timeline
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["version"] == 2
    assert meta["success"] is True
    assert meta["resume_count"] == 0
    assert meta["handoff_count"] == 1
    assert meta["attempts"][0]["classification"] == "fresh_handoff_required"
    assert meta["attempts"][1]["mode"] == "handoff"
    assert meta["attempts"][1]["source_thread_id"] == "thread-ctx-1"
    assert meta["attempts"][1]["prompt_path"].endswith("codex_handoff_prompt_attempt2.txt")


def test_run_backend_episode_triggers_internal_handoff_drill_in_live_attempt(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 0
            self.pid = 8100 + self.attempt
            self.terminated = False
            commands.append(list(command))

        def poll(self):
            return None if not self.terminated else self.returncode

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            if self.attempt == 1:
                for step_index in (1, 2):
                    step_dir = run_dir / "process" / f"step_{step_index:03d}"
                    step_dir.mkdir(parents=True, exist_ok=True)
                    (step_dir / "step_meta.json").write_text(
                        json.dumps({"step_index": step_index, "accepted": True}) + "\n",
                        encoding="utf-8",
                    )
                deadline = time.time() + 2.0
                while time.time() < deadline:
                    if self.terminated:
                        self.returncode = 23
                        return (
                            _jsonl(
                                {"type": "thread.started", "thread_id": "thread-drill-1"},
                                {"type": "turn.started"},
                            ),
                            "",
                        )
                    time.sleep(0.02)
                raise AssertionError("handoff drill did not terminate the first process")
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-drill-2"},
                    {"type": "turn.started"},
                    {
                        "type": "item.completed",
                        "item": {
                            "id": "msg-2",
                            "type": "agent_message",
                            "text": json.dumps(
                                {
                                    "status": "completed",
                                    "stop_reason": "done",
                                    "action_count": 3,
                                    "summary": "continued after live drill handoff",
                                }
                            ),
                        },
                    },
                    {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
                ),
                "",
            )

    def fake_request_process_termination(process) -> None:
        process.terminated = True

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends, "_request_process_termination", fake_request_process_termination)
    monkeypatch.setenv(backends.HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS_ENV, "2")
    monkeypatch.setenv(backends.HANDOFF_DRILL_MAX_TRIGGERS_ENV, "1")

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["thread_id"] == "thread-drill-2"
    assert len(commands) == 2
    assert "resume" not in commands[1]
    timeline = (run_dir / "results" / "runtime_timeline.jsonl").read_text(encoding="utf-8")
    assert '"event": "codex.handoff_drill.armed"' in timeline
    assert '"event": "codex.handoff_drill.triggered"' in timeline
    assert '"event": "codex.handoff.scheduled"' in timeline
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["handoff_count"] == 1
    assert meta["attempts"][0]["classification"] == "fresh_handoff_required"
    assert meta["attempts"][1]["mode"] == "handoff"
    drill_meta = json.loads((run_dir / "results" / "handoff_drill_meta.json").read_text(encoding="utf-8"))
    assert drill_meta["triggered"] is True
    assert drill_meta["trigger_count"] == 1
    assert drill_meta["pre_handoff_thread_id"] == "thread-drill-1"
    assert drill_meta["post_handoff_thread_id"] == "thread-drill-2"


def test_run_backend_episode_claude_triggers_internal_handoff_drill_in_live_attempt(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="claude", model="haiku")
    commands: list[list[str]] = []

    session_ids = iter(["claude-session-1", "claude-session-2"])
    monkeypatch.setattr(backends, "_new_claude_session_id", lambda: next(session_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 0
            self.pid = 8200 + self.attempt
            self.terminated = False
            commands.append(list(command))

        def poll(self):
            return None if not self.terminated else self.returncode

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                step_dir = run_dir / "process" / "step_001"
                step_dir.mkdir(parents=True, exist_ok=True)
                (step_dir / "step_meta.json").write_text(
                    json.dumps({"step_index": 1, "accepted": True}) + "\n",
                    encoding="utf-8",
                )
                deadline = time.time() + 2.0
                while time.time() < deadline:
                    if self.terminated:
                        self.returncode = 23
                        return ("", "")
                    time.sleep(0.02)
                raise AssertionError("handoff drill did not terminate the first Claude process")
            return (
                json.dumps(
                    {
                        "result": {
                            "status": "completed",
                            "stop_reason": "done",
                            "action_count": 2,
                            "summary": "continued after Claude live drill handoff",
                        }
                    }
                ),
                "",
            )

    def fake_request_process_termination(process) -> None:
        process.terminated = True

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends, "_request_process_termination", fake_request_process_termination)
    monkeypatch.setenv(backends.HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS_ENV, "1")
    monkeypatch.setenv(backends.HANDOFF_DRILL_MAX_TRIGGERS_ENV, "1")

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["session_id"] == "claude-session-2"
    assert len(commands) == 2
    assert "--resume" in commands[1]
    assert commands[1][commands[1].index("--resume") + 1] == "claude-session-1"
    assert "--fork-session" in commands[1]
    timeline = (run_dir / "results" / "runtime_timeline.jsonl").read_text(encoding="utf-8")
    assert '"event": "agent.handoff_drill.armed"' in timeline
    assert '"event": "agent.handoff_drill.triggered"' in timeline
    assert '"event": "agent.handoff.scheduled"' in timeline
    meta = json.loads((run_dir / "results" / "agent_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["handoff_count"] == 1
    assert meta["attempts"][0]["classification"] == "fresh_handoff_required"
    assert meta["attempts"][1]["mode"] == "handoff"
    drill_meta = json.loads((run_dir / "results" / "handoff_drill_meta.json").read_text(encoding="utf-8"))
    assert drill_meta["backend"] == "claude"
    assert drill_meta["triggered"] is True
    assert drill_meta["trigger_count"] == 1
    assert drill_meta["pre_handoff_session_id"] == "claude-session-1"
    assert drill_meta["post_handoff_session_id"] == "claude-session-2"


def test_run_backend_episode_opencode_triggers_internal_handoff_drill_in_live_attempt(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="opencode", model="minimax/minimax-m2.5")
    commands: list[list[str]] = []

    lookup_ids = iter(["ses-opencode-1", "ses-opencode-2"])
    monkeypatch.setattr(backends, "_lookup_opencode_session_id", lambda *_args, **_kwargs: next(lookup_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 0
            self.pid = 8300 + self.attempt
            self.terminated = False
            commands.append(list(command))

        def poll(self):
            return None if not self.terminated else self.returncode

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                step_dir = run_dir / "process" / "step_001"
                step_dir.mkdir(parents=True, exist_ok=True)
                (step_dir / "step_meta.json").write_text(
                    json.dumps({"step_index": 1, "accepted": True}) + "\n",
                    encoding="utf-8",
                )
                deadline = time.time() + 2.0
                while time.time() < deadline:
                    if self.terminated:
                        self.returncode = 23
                        return ("", "")
                    time.sleep(0.02)
                raise AssertionError("handoff drill did not terminate the first OpenCode process")
            return (
                json.dumps(
                    {
                        "payload": {
                            "status": "completed",
                            "stop_reason": "done",
                            "action_count": 2,
                            "summary": "continued after OpenCode live drill handoff",
                        }
                    }
                ),
                "",
            )

    def fake_request_process_termination(process) -> None:
        process.terminated = True

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends, "_request_process_termination", fake_request_process_termination)
    monkeypatch.setenv(backends.HANDOFF_DRILL_AFTER_ACCEPTED_ACTIONS_ENV, "1")
    monkeypatch.setenv(backends.HANDOFF_DRILL_MAX_TRIGGERS_ENV, "1")

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["session_id"] == "ses-opencode-2"
    assert len(commands) == 2
    assert "--session" in commands[1]
    assert commands[1][commands[1].index("--session") + 1] == "ses-opencode-1"
    assert "--fork" in commands[1]
    timeline = (run_dir / "results" / "runtime_timeline.jsonl").read_text(encoding="utf-8")
    assert '"event": "agent.handoff_drill.armed"' in timeline
    assert '"event": "agent.handoff_drill.triggered"' in timeline
    assert '"event": "agent.handoff.scheduled"' in timeline
    meta = json.loads((run_dir / "results" / "agent_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["handoff_count"] == 1
    assert meta["attempts"][0]["classification"] == "fresh_handoff_required"
    assert meta["attempts"][1]["mode"] == "handoff"
    drill_meta = json.loads((run_dir / "results" / "handoff_drill_meta.json").read_text(encoding="utf-8"))
    assert drill_meta["backend"] == "opencode"
    assert drill_meta["triggered"] is True
    assert drill_meta["trigger_count"] == 1
    assert drill_meta["pre_handoff_session_id"] == "ses-opencode-1"
    assert drill_meta["post_handoff_session_id"] == "ses-opencode-2"


def test_run_backend_episode_stops_when_handoff_limit_is_reached(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)

    (agent_workspace / "state.json").write_text(
        json.dumps({"elapsed_day": 50.0, "remaining_days": 10.0, "current_cash": 500.0, "confirmed_best_activity": 1.0}) + "\n",
        encoding="utf-8",
    )
    (agent_workspace / "history.json").write_text(json.dumps({"recent_actions": [], "recent_rejections": []}) + "\n", encoding="utf-8")

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del command, kwargs
            self.returncode = 23
            self.pid = 7201

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-limit"},
                    {"type": "turn.started"},
                    {"type": "error", "message": "context window exhausted"},
                ),
                "context window exhausted",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends, "DEFAULT_CODEX_CONTEXT_WINDOW_HANDOFF_MAX_COUNT", 0)

    with pytest.raises(BackendError, match="context_window_handoff_limit_reached") as excinfo:
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert excinfo.value.thread_id == "thread-limit"
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["handoff_count"] == 0
    assert meta["success"] is False


def test_run_backend_episode_does_not_resume_terminal_failure(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            self.returncode = 23
            self.pid = 4321
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-1"},
                    {"type": "turn.started"},
                    {"type": "error", "message": "unauthorized"},
                ),
                "unauthorized",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    with pytest.raises(BackendError, match="non-zero exit code 23"):
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert len(commands) == 1
    assert not (run_dir / "results" / "codex_resume_meta.json").exists()


def test_run_backend_episode_keeps_terminal_attempt_result_as_canonical_artifact(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del command, kwargs
            self.returncode = 23
            self.pid = 6001

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            (run_dir / "results" / "codex_final_result.json").write_text(
                '{"status":"partial","reason":"unauthorized"}\n',
                encoding="utf-8",
            )
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-1"},
                    {"type": "turn.started"},
                    {"type": "error", "message": "unauthorized"},
                ),
                "unauthorized",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    with pytest.raises(BackendError, match="non-zero exit code 23"):
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert (run_dir / "results" / "codex_final_result.json").is_file()
    assert not (run_dir / "results" / "codex_final_result_attempt1.json").exists()
    assert not (run_dir / "results" / "codex_resume_meta.json").exists()


def test_run_backend_episode_honors_disabled_auto_resume(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            self.returncode = 23
            self.pid = 7777
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-1"},
                    {"type": "turn.started"},
                    {"type": "error", "message": "stream disconnected before completion"},
                ),
                "stream disconnected before completion",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends, "DEFAULT_CODEX_AUTO_RESUME_ENABLED", False)

    with pytest.raises(BackendError, match="non-zero exit code 23"):
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert len(commands) == 1
    assert not (run_dir / "results" / "codex_events_attempt1.jsonl").exists()
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["version"] == 2
    assert meta["success"] is False
    assert meta["resume_count"] == 0
    assert meta["handoff_count"] == 0


def test_run_backend_episode_records_failed_retry_chain_when_attempt_limit_reached(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 23
            self.pid = 5000 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            if self.attempt == 1:
                (run_dir / "results" / "codex_final_result.json").write_text(
                    '{"status":"partial"}\n',
                    encoding="utf-8",
                )
                return (
                    _jsonl(
                        {"type": "thread.started", "thread_id": "thread-1"},
                        {"type": "turn.started"},
                        {"type": "error", "message": "stream disconnected before completion"},
                    ),
                    "stream disconnected before completion",
                )
            return (
                _jsonl(
                    {"type": "turn.started"},
                    {"type": "error", "message": "stream disconnected before completion"},
                ),
                "stream disconnected before completion",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)
    monkeypatch.setattr(backends, "DEFAULT_CODEX_AUTO_RESUME_MAX_ATTEMPTS", 1)

    with pytest.raises(BackendError, match="non-zero exit code 23") as excinfo:
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert excinfo.value.thread_id == "thread-1"
    assert len(commands) == 2
    assert commands[1][-3:] == ["resume", "thread-1", "-"]
    assert (run_dir / "results" / "codex_events_attempt1.jsonl").is_file()
    assert (run_dir / "results" / "codex_final_result_attempt1.json").is_file()
    assert not (run_dir / "results" / "codex_final_result.json").exists()
    assert (run_dir / "results" / "codex_events.jsonl").is_file()
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["version"] == 2
    assert meta["success"] is False
    assert meta["attempts_total"] == 2
    assert meta["resume_count"] == 1
    assert meta["handoff_count"] == 0
    assert meta["retryable_failure_count"] == 1
    assert meta["attempts"][1]["retryable"] is True


def test_run_backend_episode_rejects_resume_attempt_that_switches_thread_id(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path)
    commands: list[list[str]] = []

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 23
            self.pid = 7000 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str, timeout: int | None = None) -> tuple[str, str]:
            del prompt, timeout
            if self.attempt == 1:
                return (
                    _jsonl(
                        {"type": "thread.started", "thread_id": "thread-1"},
                        {"type": "turn.started"},
                        {"type": "error", "message": "stream disconnected before completion"},
                    ),
                    "stream disconnected before completion",
                )
            return (
                _jsonl(
                    {"type": "thread.started", "thread_id": "thread-2"},
                    {"type": "turn.started"},
                    {"type": "error", "message": "stream disconnected before completion"},
                ),
                "stream disconnected before completion",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    with pytest.raises(BackendError, match="unexpected thread id") as excinfo:
        run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert excinfo.value.thread_id == "thread-1"
    assert len(commands) == 2
    meta = json.loads((run_dir / "results" / "codex_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["version"] == 2
    assert meta["success"] is False
    assert meta["attempts_total"] == 2
    assert meta["handoff_count"] == 0
    assert meta["attempts"][1]["classification"] == "terminal_non_retryable_error"
    assert meta["attempts"][1]["observed_thread_id"] == "thread-2"
    assert meta["attempts"][1]["effective_thread_id"] == "thread-1"


def test_run_backend_episode_supports_claude_cli_backend(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="claude", model="haiku", reasoning_effort="high")
    commands: list[list[str]] = []

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            self.returncode = 0
            self.pid = 9101
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            return (
                json.dumps(
                    {
                        "result": {
                            "status": "completed",
                            "stop_reason": "done",
                            "action_count": 3,
                            "summary": "claude completed",
                        }
                    }
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    command = commands[0]
    assert command[:2] == ["reclaude", "-p"]
    assert "--dangerously-skip-permissions" in command
    assert "--output-format" in command and "json" in command
    assert "--json-schema" in command
    assert "--model" in command and "haiku" in command
    assert "--effort" in command and "high" in command
    assert "--session-id" in command
    assert result["backend"] == "claude"
    assert result["session_id"]
    assert (run_dir / "results" / "agent_stdout.log").is_file()
    assert (run_dir / "results" / "agent_final_result.json").is_file()
    assert not (run_dir / "results" / "codex_events.jsonl").exists()


def test_build_claude_command_defaults_to_reclaude_and_honors_override(tmp_path: Path, monkeypatch) -> None:
    config = _config(tmp_path, backend="claude", model="claude-fable-5", reasoning_effort="max")
    invocation = backends._AttemptInvocation(
        backend="claude",
        mode="initial",
        prompt="hello",
        prompt_path=None,
        resume_session_id=None,
        target_session_id="11111111-1111-1111-1111-111111111111",
        source_session_id=None,
        trigger="run_start",
    )

    monkeypatch.delenv(backends.CLAUDE_CLI_BIN_ENV, raising=False)
    default_command = backends._build_claude_command(config, run_dir=tmp_path / "run", invocation=invocation)
    assert default_command[0] == "reclaude"
    assert default_command[1] == "-p"
    assert "--model" in default_command and "claude-fable-5" in default_command
    assert "--effort" in default_command and "max" in default_command
    assert default_command[-1] == "hello"

    monkeypatch.setenv(backends.CLAUDE_CLI_BIN_ENV, "claude")
    override_command = backends._build_claude_command(config, run_dir=tmp_path / "run", invocation=invocation)
    assert override_command[0] == "claude"


def test_run_backend_episode_claude_resumes_same_session_after_retryable_failure(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="claude", model="haiku")
    commands: list[list[str]] = []

    session_ids = iter(["claude-session-1"])
    monkeypatch.setattr(backends, "_new_claude_session_id", lambda: next(session_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 23 if self.attempt == 1 else 0
            self.pid = 9200 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                return ("", "stream disconnected before completion")
            return (
                json.dumps(
                    {
                        "status": "completed",
                        "stop_reason": "done",
                        "action_count": 2,
                        "summary": "claude resumed",
                    }
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["session_id"] == "claude-session-1"
    assert "--resume" in commands[1]
    assert commands[1][commands[1].index("--resume") + 1] == "claude-session-1"
    meta = json.loads((run_dir / "results" / "agent_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["backend"] == "claude"
    assert meta["resume_count"] == 1
    assert meta["handoff_count"] == 0


def test_run_backend_episode_claude_forks_new_session_for_context_window_handoff(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="claude", model="haiku")
    commands: list[list[str]] = []

    session_ids = iter(["claude-session-1", "claude-session-2"])
    monkeypatch.setattr(backends, "_new_claude_session_id", lambda: next(session_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 23 if self.attempt == 1 else 0
            self.pid = 9300 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, prompt: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del timeout
            if self.attempt == 1:
                return ("", "context window exhausted")
            assert prompt is None
            return (
                json.dumps(
                    {
                        "status": "completed",
                        "stop_reason": "done",
                        "action_count": 2,
                        "summary": "claude handoff",
                    }
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["session_id"] == "claude-session-2"
    assert "--resume" in commands[1]
    assert commands[1][commands[1].index("--resume") + 1] == "claude-session-1"
    assert "--fork-session" in commands[1]
    assert "--session-id" in commands[1]
    assert commands[1][commands[1].index("--session-id") + 1] == "claude-session-2"


def test_run_backend_episode_supports_opencode_cli_backend_and_recovers_session_id(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="opencode", model="qwen/qwen3coder", reasoning_effort="max")
    commands: list[list[str]] = []
    monkeypatch.setattr(backends, "_lookup_opencode_session_id", lambda *_args, **_kwargs: "ses-opencode-1")

    class FakeProcess:
        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            self.returncode = 0
            self.pid = 9401
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            return (
                "\n".join(
                    [
                        json.dumps({"type": "session.created"}),
                        json.dumps(
                            {
                                "type": "message.completed",
                                "message": {
                                    "role": "assistant",
                                    "content": json.dumps(
                                        {
                                            "status": "completed",
                                            "stop_reason": "done",
                                            "action_count": 4,
                                            "summary": "opencode completed",
                                        }
                                    ),
                                },
                            }
                        ),
                    ]
                )
                + "\n",
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    command = commands[0]
    assert command[:3] == ["opencode", "run", "--pure"]
    assert "--thinking" in command
    assert "--format" in command and "json" in command
    assert "--dir" in command and str(agent_workspace) in command
    assert "--model" in command and "qwen/qwen3coder" in command
    assert "--variant" in command and "max" in command
    assert "--title" in command
    assert result["session_id"] == "ses-opencode-1"
    assert (run_dir / "results" / "agent_final_result.json").is_file()


def test_extract_generic_episode_result_accepts_trailing_json_embedded_in_text_event(tmp_path: Path) -> None:
    results_dir = tmp_path / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    stdout = (
        json.dumps(
            {
                "type": "text",
                "part": {
                    "text": (
                        "The experiment is complete.\n\n"
                        '{"status":"completed","stop_reason":"已达到 max_experiment_days，实验结束","action_count":1,'
                        '"summary":"Completed after one accepted step."}'
                    )
                },
            }
        )
        + "\n"
    )

    payload = backends._extract_generic_episode_result(backend="opencode", stdout=stdout, results_dir=results_dir)

    assert payload["status"] == "completed"
    assert payload["stop_reason"] == "已达到 max_experiment_days，实验结束"
    assert payload["action_count"] == 1
    assert json.loads((results_dir / "agent_final_result.json").read_text(encoding="utf-8"))["summary"] == (
        "Completed after one accepted step."
    )


def test_extract_generic_episode_result_accepts_reclaude_structured_output_envelope(tmp_path: Path) -> None:
    # reclaude/Claude Code 在 `--output-format json --json-schema` 下，把 schema 校验后的结果放在
    # 顶层 `structured_output` 字段，而 `result` 只是人类可读文本。这里锁定该真实输出契约能被正确解析。
    results_dir = tmp_path / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    stdout = (
        json.dumps(
            {
                "type": "result",
                "subtype": "success",
                "is_error": False,
                "result": "Done. Confirmed the seed6 hit and stopped after the incumbent stopped improving.",
                "session_id": "db2baa10-bcbb-432d-ba21-8b0280d2958f",
                "structured_output": {
                    "status": "completed",
                    "stop_reason": "Locked in 9.0x confirmed activity; remaining screens no longer improve cash_final",
                    "action_count": 7,
                    "summary": "Validated a 9.0x seed6 hit and stopped.",
                },
                "terminal_reason": "completed",
                "uuid": "422916f5-5199-448f-819e-00182d383aa4",
            }
        )
        + "\n"
    )

    payload = backends._extract_generic_episode_result(backend="claude", stdout=stdout, results_dir=results_dir)

    assert payload["status"] == "completed"
    assert payload["action_count"] == 7
    assert payload["stop_reason"].startswith("Locked in 9.0x")
    assert json.loads((results_dir / "agent_final_result.json").read_text(encoding="utf-8"))["summary"] == (
        "Validated a 9.0x seed6 hit and stopped."
    )


def test_extract_generic_episode_result_accepts_trailing_json_inside_markdown_code_fence(tmp_path: Path) -> None:
    results_dir = tmp_path / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    stdout = (
        json.dumps(
            {
                "type": "text",
                "part": {
                    "text": (
                        "实验已终止，返回最终JSON：\n\n```json\n"
                        '{"status":"completed","stop_reason":"已达到 max_experiment_days，实验结束","action_count":2,'
                        '"summary":"Experiment completed with 963.0 remaining after 2 actions"}\n```'
                    )
                },
            }
        )
        + "\n"
    )

    payload = backends._extract_generic_episode_result(backend="opencode", stdout=stdout, results_dir=results_dir)

    assert payload["status"] == "completed"
    assert payload["action_count"] == 2
    assert payload["summary"] == "Experiment completed with 963.0 remaining after 2 actions"


def test_run_backend_episode_opencode_resumes_recovered_session_after_retryable_failure(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="opencode", model="deepseek/deepseek-v3.2")
    commands: list[list[str]] = []

    lookup_ids = iter(["ses-opencode-1", "ses-opencode-1"])
    monkeypatch.setattr(backends, "_lookup_opencode_session_id", lambda *_args, **_kwargs: next(lookup_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 23 if self.attempt == 1 else 0
            self.pid = 9500 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                return ("", "stream disconnected before completion")
            return (
                json.dumps(
                    {
                        "payload": {
                            "status": "completed",
                            "stop_reason": "done",
                            "action_count": 2,
                            "summary": "opencode resumed",
                        }
                    }
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["session_id"] == "ses-opencode-1"
    assert "--session" in commands[1]
    assert commands[1][commands[1].index("--session") + 1] == "ses-opencode-1"
    meta = json.loads((run_dir / "results" / "agent_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["backend"] == "opencode"
    assert meta["resume_count"] == 1


def test_run_backend_episode_opencode_resumes_after_missing_final_json(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="opencode", model="zai/glm-5.1")
    commands: list[list[str]] = []

    lookup_ids = iter(["ses-opencode-glm51", "ses-opencode-glm51"])
    monkeypatch.setattr(backends, "_lookup_opencode_session_id", lambda *_args, **_kwargs: next(lookup_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 0
            self.pid = 9600 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                return (
                    json.dumps({"type": "step_finish", "part": {"reason": "tool-calls"}}) + "\n",
                    "",
                )
            return (
                json.dumps(
                    {
                        "type": "text",
                        "part": {
                            "text": (
                                '{"status":"completed","stop_reason":"done",'
                                '"action_count":1,"summary":"opencode resumed after tool call"}'
                            )
                        },
                    }
                )
                + "\n",
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert "--thinking" not in commands[0]
    assert result["session_id"] == "ses-opencode-glm51"
    assert "--session" in commands[1]
    assert commands[1][commands[1].index("--session") + 1] == "ses-opencode-glm51"
    assert json.loads((run_dir / "results" / "agent_final_result.json").read_text(encoding="utf-8"))["summary"] == (
        "opencode resumed after tool call"
    )
    meta = json.loads((run_dir / "results" / "agent_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["attempts"][0]["classification"] == "retryable_missing_final_result"
    assert meta.get("hand_off_count", meta.get("handoff_count")) == 1


def test_run_backend_episode_opencode_handoffs_after_missing_final_json(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="opencode", model="zai/glm-5.1")
    commands: list[list[str]] = []

    lookup_ids = iter(["ses-opencode-handoff-1", "ses-opencode-handoff-2"])
    monkeypatch.setattr(backends, "_lookup_opencode_session_id", lambda *_args, **_kwargs: next(lookup_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 0
            self.pid = 9700 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                return (json.dumps({"type": "step_finish", "part": {"reason": "tool-calls"}}) + "\n", "")
            return (
                json.dumps(
                    {
                        "type": "text",
                        "part": {
                            "text": (
                                '{"status":"completed","stop_reason":"done",'
                                '"action_count":1,"summary":"opencode handoff resumed"}'
                            )
                        },
                    }
                )
                + "\n",
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert "--session" not in commands[0]
    assert "--session" in commands[1]
    assert result["session_id"] == "ses-opencode-handoff-2"
    assert "--fork" in commands[1]
    meta = json.loads((run_dir / "results" / "agent_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["attempts"][0]["continuation_mode"] == "handoff"
    assert meta["handoff_count"] == 1


def test_run_backend_episode_opencode_retries_api_connection_error(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="opencode", model="qwen/qwen3coder")
    commands: list[list[str]] = []

    lookup_ids = iter(["ses-opencode-qwen-1", "ses-opencode-qwen-1"])
    monkeypatch.setattr(backends, "_lookup_opencode_session_id", lambda *_args, **_kwargs: next(lookup_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 0
            self.pid = 9700 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                return (
                    json.dumps(
                        {
                            "type": "error",
                            "error": {
                                "name": "UnknownError",
                                "data": {
                                    "message": (
                                        "litellm.APIConnectionError: APIConnectionError: "
                                        "OpenAIException - list index out of range"
                                    )
                                },
                            },
                        }
                    )
                    + "\n",
                    "",
                )
            return (
                json.dumps(
                    {
                        "payload": {
                            "status": "completed",
                            "stop_reason": "done",
                            "action_count": 1,
                            "summary": "qwen resumed after transient provider failure",
                        }
                    }
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)
    monkeypatch.setattr(backends.time, "sleep", lambda seconds: None)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["session_id"] == "ses-opencode-qwen-1"
    assert "--session" in commands[1]
    assert commands[1][commands[1].index("--session") + 1] == "ses-opencode-qwen-1"
    meta = json.loads((run_dir / "results" / "agent_resume_meta.json").read_text(encoding="utf-8"))
    assert meta["resume_count"] == 1
    assert meta["attempts"][0]["classification"] == "retryable_interruption"


def test_run_backend_episode_opencode_forks_session_for_context_window_handoff(tmp_path: Path, monkeypatch) -> None:
    run_dir, agent_workspace = _prepare_run_dirs(tmp_path)
    config = _config(tmp_path, backend="opencode", model="minimax/minimax-m2.5")
    commands: list[list[str]] = []

    lookup_ids = iter(["ses-opencode-1", "ses-opencode-2"])
    monkeypatch.setattr(backends, "_lookup_opencode_session_id", lambda *_args, **_kwargs: next(lookup_ids))

    class FakeProcess:
        attempt = 0

        def __init__(self, command: list[str], **kwargs) -> None:
            del kwargs
            type(self).attempt += 1
            self.attempt = type(self).attempt
            self.returncode = 23 if self.attempt == 1 else 0
            self.pid = 9600 + self.attempt
            commands.append(list(command))

        def poll(self):
            return None

        def communicate(self, _input: str | None = None, timeout: int | None = None) -> tuple[str, str]:
            del _input, timeout
            if self.attempt == 1:
                return ("", "context length exceeded")
            return (
                json.dumps(
                    {
                        "payload": {
                            "status": "completed",
                            "stop_reason": "done",
                            "action_count": 2,
                            "summary": "opencode handoff",
                        }
                    }
                ),
                "",
            )

    monkeypatch.setattr(backends.subprocess, "Popen", FakeProcess)

    result = run_backend_episode(config, run_dir=run_dir, agent_workspace=agent_workspace)

    assert result["session_id"] == "ses-opencode-2"
    assert "--session" in commands[1]
    assert commands[1][commands[1].index("--session") + 1] == "ses-opencode-1"
    assert "--fork" in commands[1]
