from pathlib import Path

from TadACampaign.judge.client import JudgeHttpClient
from TadACampaign.network_policy import (
    NetworkEndpoint,
    merge_no_proxy,
    resolve_backend_egress_allowlist,
    resolve_backend_proxy_bypass_hosts,
)


def test_resolve_backend_egress_allowlist_prefers_proxy_and_rewrites_localhost(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        '[model_providers.openai]\nbase_url = "provider-config"\n',
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist(
        "codex",
        codex_home=codex_home,
        env={"HTTPS_PROXY": "http://localhost:7890"},
    )

    assert endpoints == (
        NetworkEndpoint(host="host.docker.internal", port=7890),
        NetworkEndpoint(host="provider-config", port=443),
    )


def test_resolve_backend_egress_allowlist_keeps_judge_endpoint_when_proxy_is_present(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        '[model_providers.openai]\nbase_url = "provider-config"\n',
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist(
        "codex",
        codex_home=codex_home,
        env={"HTTPS_PROXY": "http://localhost:7890"},
        extra_urls=("http://host.docker.internal:36465",),
    )

    assert endpoints == (
        NetworkEndpoint(host="host.docker.internal", port=7890),
        NetworkEndpoint(host="provider-config", port=443),
        NetworkEndpoint(host="host.docker.internal", port=36465),
    )


def test_resolve_backend_egress_allowlist_uses_codex_provider_when_no_proxy(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        (
            'model_provider = "sub"\n'
            '\n'
            '[model_providers.sub]\n'
            'base_url = "http://localhost:5205/v1"\n'
        ),
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist("codex", codex_home=codex_home, env={})

    assert endpoints == (NetworkEndpoint(host="host.docker.internal", port=5205),)


def test_resolve_backend_proxy_bypass_hosts_skips_public_provider(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        '[model_providers.openai]\nbase_url = "provider-config"\n',
        encoding="utf-8",
    )

    hosts = resolve_backend_proxy_bypass_hosts("codex", codex_home=codex_home)

    assert hosts == ()


def test_resolve_backend_egress_allowlist_adds_judge_endpoint_without_proxy(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        (
            'model_provider = "sub"\n'
            '\n'
            '[model_providers.sub]\n'
            'base_url = "http://localhost:5205/v1"\n'
        ),
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist(
        "codex",
        codex_home=codex_home,
        env={},
        extra_urls=("http://host.docker.internal:36465",),
    )

    assert endpoints == (
        NetworkEndpoint(host="host.docker.internal", port=5205),
        NetworkEndpoint(host="host.docker.internal", port=36465),
    )


def test_merge_no_proxy_adds_host_docker_internal_without_duplicates() -> None:
    rendered = merge_no_proxy("127.0.0.1,localhost", "localhost", "host.docker.internal")
    assert rendered == "127.0.0.1,localhost,host.docker.internal"


def test_judge_client_bypasses_proxy_for_host_docker_internal(monkeypatch) -> None:
    client = JudgeHttpClient("http://host.docker.internal:8080", timeout_seconds=5, session_token="token")
    observed: dict[str, object] = {"build_opener_called": False, "urlopen_called": False}

    class FakeOpener:
        def open(self, request, timeout=None):
            observed["build_opener_called"] = True
            observed["request_url"] = request.full_url
            observed["timeout"] = timeout
            raise RuntimeError("stop")

    monkeypatch.setattr("urllib.request.build_opener", lambda *args: FakeOpener())
    monkeypatch.setattr(
        "urllib.request.urlopen",
        lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("unexpected direct urlopen")),
    )

    try:
        client.healthcheck()
    except RuntimeError as exc:
        assert str(exc) == "stop"

    assert observed["build_opener_called"] is True
    assert observed["request_url"] == "http://host.docker.internal:8080/healthz"
