import inspect
import json
import random
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.test_backends import _config
from TadACampaign.policies import POLICY_NAMES, make_policy_memory, select_action


def _observation() -> dict:
    return {
        "state": {
            "current_cash": 1000.0,
            "remaining_days": 100.0,
            "confirmed_best_activity": 1.0,
            "total_cost_paid": 0.0,
            "total_reward_earned": 0.0,
            "seeds": [
                {
                    "seed_id": "alpha",
                    "seed_status": "prepared",
                    "libraries": [
                        {"library_id": "lib_a", "library_status": "prepared"},
                        {"library_id": "lib_b", "library_status": "locked"},
                    ],
                },
                {"seed_id": "beta", "seed_status": "visible", "libraries": [{"library_id": "lib_c", "library_status": "locked"}]},
            ],
        },
        "history": {"recent_actions": [], "recent_screen_records": [], "recent_rejections": []},
        "available_actions": {
            "prepare_seed": [
                {"action": "prepare_seed", "seed_id": "alpha", "total_cost": 10.0},
                {"action": "prepare_seed", "seed_id": "beta", "total_cost": 10.0},
            ],
            "prepare_library": [
                {
                    "action": "prepare_library",
                    "seed_id": "alpha",
                    "library_id": "lib_a",
                    "interval_length_aa": 30,
                    "total_cost": 10.0,
                }
            ],
            "mine_library": [
                {
                    "action": "mine_library",
                    "seed_id": "alpha",
                    "library_id": "lib_a",
                    "screenable_sequence_count": 100,
                    "screened_sequence_count": 0,
                    "remaining_screenable_sequence_count": 100,
                    "batch_options": [
                        {
                            "batch_size": 1,
                            "total_cost": 10.0,
                            "leaves_confirm_capacity": True,
                        }
                    ],
                }
            ],
            "confirm_hit": [
                {
                    "action": "confirm_hit",
                    "screen_record_id": 3,
                    "observed_activity": 2.0,
                    "total_cost": 7.0,
                }
            ],
            "purchase_skill": [],
            "stop": {"action": "stop"},
        },
    }


@pytest.mark.parametrize(
    "policy_name",
    [
        "stop_now",
        "blind_random_legal",
        "budgeted_static_ranker",
        "scout_confirm_stop",
        "upside_greedy_explorer",
        "empirical_ev_planner",
    ],
)
def test_policy_selects_structured_decision(tmp_path: Path, policy_name: str) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    decision = select_action(
        policy_name,
        config=config,
        observation=_observation(),
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action in {"stop", "prepare_seed", "prepare_library", "mine_library", "confirm_hit"}
    assert decision.reasoning


@pytest.mark.parametrize(
    "policy_name",
    sorted(POLICY_NAMES - {"jev_choice", "jev_k1", "d1_k1", "laya_k1"}),
)
def test_policy_names_are_selectable(tmp_path: Path, policy_name: str) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    decision = select_action(
        policy_name,
        config=config,
        observation=_observation(),
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action in {"stop", "prepare_seed", "prepare_library", "mine_library", "confirm_hit"}


@pytest.mark.parametrize(
    "policy_name",
    ["budgeted_static_ranker", "scout_confirm_stop", "upside_greedy_explorer", "empirical_ev_planner"],
)
def test_upgraded_policies_stop_when_nonconfirm_action_would_break_confirm_runway(
    tmp_path: Path, policy_name: str
) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    observation = _observation()
    observation["available_actions"]["confirm_hit"] = []
    observation["state"]["current_cash"] = 16.0
    observation["state"]["remaining_days"] = 2.0

    decision = select_action(
        policy_name,
        config=config,
        observation=observation,
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action == "stop"
    assert "reserve" in decision.reasoning or "probe floor" in decision.reasoning or "stop" in decision.reasoning


@pytest.mark.parametrize(
    "policy_name",
    ["budgeted_static_ranker", "scout_confirm_stop", "upside_greedy_explorer", "empirical_ev_planner"],
)
def test_upgraded_policies_prioritize_positive_ev_confirm(tmp_path: Path, policy_name: str) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    observation = _observation()

    decision = select_action(
        policy_name,
        config=config,
        observation=observation,
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action == "confirm_hit"
    assert decision.screen_record_id == 3


def test_upside_greedy_explorer_prefers_largest_reserve_preserving_batch(tmp_path: Path) -> None:
    config = replace(
        _config(tmp_path),
        agent_backend="policy",
        agent_policy="upside_greedy_explorer",
        initial_cash=1000.0,
        confirm_hit_cost=5.0,
        confirm_hit_days=1.0,
        daily_burn_cost=2.0,
    )
    observation = _observation()
    observation["available_actions"]["confirm_hit"] = []
    observation["available_actions"]["mine_library"][0]["batch_options"] = [
        {"batch_size": 1, "total_cost": 10.0, "leaves_confirm_capacity": True},
        {"batch_size": 8, "total_cost": 100.0, "leaves_confirm_capacity": True},
        {"batch_size": 16, "total_cost": 1000.0, "leaves_confirm_capacity": False},
    ]

    decision = select_action(
        "upside_greedy_explorer",
        config=config,
        observation=observation,
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action == "mine_library"
    assert decision.batch_size == 8


def test_jev_singleton_choice_is_selected_without_gateway_call() -> None:
    from TadACampaign import jev_policy

    class NeverCalledClient:
        def system_one(self, **kwargs):
            raise AssertionError("singleton choices must not call the gateway")

    runtime = jev_policy.JEVPolicyRuntime(NeverCalledClient(), "liquid/d1", 1, "compact")
    choice, probabilities, selected_per_call, usages, confidence = jev_policy._ask_choice(
        runtime,
        {},
        "Choose the only legal action.",
        {"stop": "stop"},
    )

    assert choice == "stop"
    assert probabilities == {"stop": 1.0}
    assert selected_per_call == []
    assert usages == []
    assert confidence == 1.0
    assert runtime.calls == 0


@pytest.mark.parametrize(
    ("probabilities", "expected_options"),
    [
        ({"stop": 0.6, "mine:1": 0.3, "prepare:1": 0.1}, {"stop", "mine:1", "prepare:1"}),
        ({"stop": 0.4, "mine:1": 0.4, "prepare:1": 0.2}, {"stop", "mine:1", "prepare:1"}),
        ({"stop": 0.2, "mine:1": 0.5, "prepare:1": 0.3}, {"mine:1", "prepare:1"}),
    ],
)
def test_jev_sampling_stop_pool_uses_all_options_when_stop_is_highest(
    probabilities: dict[str, float],
    expected_options: set[str],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from TadACampaign import jev_policy

    class FakeClient:
        def system_one(self, **kwargs):
            return SimpleNamespace(
                answers={"action": SimpleNamespace(choice="stop", probabilities=probabilities)},
                usage=SimpleNamespace(input_tokens=1, output_tokens=1),
            )

    sampled_options: list[tuple[str, ...]] = []

    def fake_choices(options, *, weights, k):
        sampled_options.append(tuple(options))
        return [options[0]]

    monkeypatch.setattr(jev_policy.random, "choices", fake_choices)
    runtime = jev_policy.JEVPolicyRuntime(FakeClient(), "jev-latest", 1, "compact", sampling=True)
    choice, _, _, _, _ = jev_policy._ask_choice(
        runtime,
        {},
        "Choose one action.",
        {option_id: option_id for option_id in probabilities},
    )

    assert set(sampled_options) == {tuple(option_id for option_id in probabilities if option_id in expected_options)}
    assert choice in expected_options


def test_jev_state_payload_includes_public_task_context_but_not_hidden_data(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    config = replace(_config(tmp_path), agent_backend="policy", agent_policy="jev_k1")
    payload = jev_policy._state_payload(_observation(), "compact", config)

    assert payload["task"]["objective"]
    assert payload["task"]["brief"]
    assert "cash_final" in payload["task"]["brief"]
    assert payload["task"]["reward_tiers"]
    assert payload["task"]["action_semantics"]["confirm_hit"]
    assert payload["task"]["costs"]["daily_burn_cost"]
    assert payload["current"]["current_cash"] == 1000.0
    assert payload["current"]["economic_summary"] == {}

    serialized = json.dumps(payload, ensure_ascii=True)
    for hidden in ("true_activity", "noise_seed", "settlement", "replay_table"):
        assert hidden not in serialized


def test_jev_biology_context_switch_defaults_on_and_can_be_disabled(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    default_config = replace(_config(tmp_path), agent_backend="policy", agent_policy="jev_k1")
    default_payload = jev_policy._state_payload(_observation(), "compact", default_config)
    assert jev_policy._include_biology_context(default_config) is True
    assert "biology" in default_payload["task"]
    assert "risk_and_branch_guidance" in default_payload["task"]["biology"]

    neutral_config = replace(
        default_config,
        agent_policy_params={"include_biology_context": False},
    )
    neutral_payload = jev_policy._state_payload(_observation(), "compact", neutral_config)
    assert jev_policy._include_biology_context(neutral_config) is False
    assert "biology" not in neutral_payload["task"]
    assert neutral_payload["task"]["objective"]
    assert neutral_payload["task"]["action_semantics"]["mine_library"]
    serialized = json.dumps(neutral_payload, ensure_ascii=True).lower()
    for biological_term in ("tada", "directed evolution", "lineage", "descendant", "risk_and_branch_guidance"):
        assert biological_term not in serialized


def test_jev_agent_shared_biology_context_replaces_legacy_jev_biology(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    config = replace(
        _config(tmp_path),
        agent_backend="policy",
        agent_policy="jev_k1",
        agent_policy_params={"biology_context_mode": "agent_shared"},
    )
    payload = jev_policy._state_payload(_observation(), "compact", config)
    assert payload["task"]["biology_context_mode"] == "agent_shared"
    assert "biology" not in payload["task"]
    shared_text = jev_policy._load_agent_shared_biology_context()
    assert shared_text.startswith("# TadACampaign Biology Context")
    assert "TadA directed-evolution" in shared_text

    runtime = jev_policy.JEVPolicyRuntime(
        None,
        "jev-latest",
        1,
        "compact",
        biology_context_mode="agent_shared",
        shared_biology_context=shared_text,
    )
    instructions = jev_policy._choice_instructions(runtime, "Return exactly one option id.")
    assert instructions.startswith(shared_text + "\n\nReturn exactly one option id.")


def test_jev_full_history_uses_real_public_history_fields(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    config = replace(_config(tmp_path), agent_backend="policy", agent_policy="jev_k1")
    observation = _observation()
    observation["history"] = {
        "recent_actions": [
            {
                "action": "prepare_library",
                "seed_id": "seed1",
                "library_id": "lib_a",
                "newly_visible_seed_ids": ["seed2"],
                "cash_after": 900.0,
                "elapsed_day_after": 2.0,
            }
        ],
        "recent_screen_records": [
            {
                "screen_record_id": 7,
                "seed_id": "seed1",
                "library_id": "lib_a",
                "observed_activity": 2.5,
                "is_confirmed": False,
                "noise_pending": True,
                "sequence_length": 100,
            }
        ],
        "recent_rejections": [],
    }

    payload = jev_policy._state_payload(observation, "full-history", config)

    actions = payload["action_history"]
    assert actions[0]["newly_visible_seed_ids"] == ["seed2"]
    assert actions[0]["cash_after"] == 900.0
    candidates = payload["candidate_score_summary"]
    assert candidates[0]["observed_activity"] == 2.5
    assert candidates[0]["is_confirmed"] is False


def test_jev_campaign_action_accumulates_full_history(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    runtime = jev_policy.JEVPolicyRuntime(None, "jev-latest", 1, "full-history")
    memory = make_policy_memory()
    memory.jev_runtime = runtime

    jev_policy.record_campaign_action(
        memory,
        {
            "action": "mine_library",
            "seed_id": "seed1",
            "library_id": "lib_a",
            "requested_batch_size": 780,
            "newly_visible_seed_ids": [],
            "best_update": {"observed_activity": 2.1},
            "reward_earned": 0.0,
            "cash_after": 800.0,
            "elapsed_day_after": 10.0,
            "reasoning": "should be filtered out",
        },
    )

    assert len(runtime.campaign_actions) == 1
    entry = runtime.campaign_actions[0]
    assert entry["best_update"] == {"observed_activity": 2.1}
    assert entry["cash_after"] == 800.0
    assert "reasoning" not in entry


def test_jev_exposes_mutational_window_to_jev(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    config = replace(_config(tmp_path), agent_backend="policy", agent_policy="jev_k1")
    obs = _observation()
    obs["state"]["seeds"][0]["libraries"][0]["mutable_interval_aa"] = {
        "start_index_0based_inclusive": 55,
        "end_index_0based_exclusive": 85,
    }
    obs["state"]["seeds"][0]["libraries"][0]["interval_length_aa"] = 30

    payload = jev_policy._state_payload(obs, "compact", config)
    lib = payload["current"]["seeds"][0]["libraries"][0]
    assert lib["mutable_interval_aa"]["start_index_0based_inclusive"] == 55

    obs["available_actions"]["prepare_library"][0]["mutable_interval_aa"] = {
        "start_index_0based_inclusive": 55,
        "end_index_0based_exclusive": 85,
    }
    criteria, _ = jev_policy._options(obs)
    assert "window=aa55-85" in criteria["prepare_library:alpha:lib_a"]
    assert "window=aa55-85" in criteria["mine_library:alpha:lib_a:batch=1"]


def test_jev_state_includes_visible_protein_sequence_and_window(tmp_path: Path) -> None:
    from TadACampaign import jev_policy
    from TadACampaign.specs import ROOT_DNA

    config = replace(_config(tmp_path), agent_backend="policy", agent_policy="jev_k1")
    obs = _observation()
    obs["state"]["seeds"][0]["start_sequence"] = ROOT_DNA
    obs["state"]["seeds"][0]["libraries"][0]["mutable_interval_aa"] = {
        "start_index_0based_inclusive": 55,
        "end_index_0based_exclusive": 85,
    }

    payload = jev_policy._state_payload(obs, "compact", config)
    seed = payload["current"]["seeds"][0]
    assert len(seed["protein_sequence"]) == 167
    lib = seed["libraries"][0]
    assert lib["window_subsequence"].startswith("AHAE")
    assert "directed_evolution_loop" in payload["task"]["biology"]
    assert "risk_and_branch_guidance" in payload["task"]["biology"]
    assert "higher prior for upside" in payload["task"]["biology"]["risk_and_branch_guidance"]
    assert "paid noisy experiment" in payload["task"]["biology"]["risk_and_branch_guidance"]
    assert "motif_prior" not in payload["task"]["biology"]
    assert "catalytic_motifs" not in seed


def test_jev_campaign_trace_records_reveal_events(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    config = replace(_config(tmp_path), agent_backend="policy", agent_policy="jev_k1")
    actions = [
        {
            "action": "prepare_library",
            "seed_id": "seed1",
            "library_id": "seed1_library3",
            "newly_visible_seed_ids": ["seed2", "seed3"],
            "cash_after": 900.0,
            "elapsed_day_after": 5.0,
        }
    ]
    payload = jev_policy._state_payload(_observation(), "compact", config, actions)
    trace = payload["campaign_trace"]
    assert trace[0]["revealed_seeds"] == ["seed2", "seed3"]
    assert trace[0]["library_id"] == "seed1_library3"
    assert "reveal_semantics" in payload["task"]["biology"]


def test_jev_hierarchical_choice_two_level(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from TadACampaign import jev_policy

    calls: list[list[str]] = []

    class FakeClient:
        def system_one(self, **kwargs):
            keys = list(kwargs["questions"]["action"].criteria.keys())
            calls.append(keys)
            if set(keys) >= {"stop", "mine_library", "prepare_library"}:
                return SimpleNamespace(
                    answers={"action": SimpleNamespace(choice="mine_library", probabilities={"stop": 0.1, "prepare_seed": 0.1, "prepare_library": 0.2, "mine_library": 0.6})},
                    usage=SimpleNamespace(input_tokens=1, output_tokens=1),
                )
            probs = {k: (0.9 if "batch=1" in k else 0.05) for k in keys}
            return SimpleNamespace(
                answers={"action": SimpleNamespace(choice=next(k for k in keys if "batch=1" in k), probabilities=probs)},
                usage=SimpleNamespace(input_tokens=1, output_tokens=1),
            )

        def close(self) -> None:
            pass

    runtime = jev_policy.JEVPolicyRuntime(FakeClient(), "jev-latest", 1, "compact", hierarchical=True)
    monkeypatch.setattr(jev_policy, "_get_runtime", lambda m, c, p: runtime)
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy="jev_k1")
    observation = _observation()
    observation["available_actions"]["mine_library"][0]["batch_options"].append(
        {"batch_size": 2, "total_cost": 20.0, "leaves_confirm_capacity": True}
    )
    decision = select_action(
        "jev_k1", config=config, observation=observation, memory=make_policy_memory(), rng=random.Random(1)
    )

    assert decision.action == "mine_library"
    assert decision.batch_size == 1
    assert len(calls) == 2  # category level + specific-option level


def test_jev_mine_options_show_observed_activity_stats(tmp_path: Path) -> None:
    from TadACampaign import jev_policy

    runtime = jev_policy.JEVPolicyRuntime(None, "jev-latest", 1, "compact")
    obs = _observation()
    obs["history"]["recent_screen_records"] = [
        {"screen_record_id": 1, "library_id": "lib_a", "observed_activity": 0.01},
        {"screen_record_id": 2, "library_id": "lib_a", "observed_activity": 0.03},
    ]
    jev_policy._accumulate_screens(runtime, obs)
    criteria, _ = jev_policy._options(obs, runtime.screen_stats)
    mine = criteria["mine_library:alpha:lib_a:batch=1"]
    assert "avg_obs=0.020" in mine
    assert "max_obs=0.030" in mine


def test_removed_fig2_aliases_are_rejected(tmp_path: Path) -> None:
    config = replace(_config(tmp_path), agent_backend="policy")

    for policy_name in ("visible_feature_ranker", "myopic_confirm", "frontier_probe_then_exploit"):
        with pytest.raises(ValueError, match="Unknown policy"):
            select_action(
                policy_name,
                config=config,
                observation=_observation(),
                memory=make_policy_memory(),
                rng=random.Random(1),
            )


def test_policy_module_does_not_import_hidden_benchmark_surfaces() -> None:
    import TadACampaign.policies as policies

    source = inspect.getsource(policies)
    assert "TadACampaign.specs" not in source
    assert "TadACampaign.data" not in source
    assert "TadACampaign.environment" not in source
    assert "prepared/manifest" not in source
