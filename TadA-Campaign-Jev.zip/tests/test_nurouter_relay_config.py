from pathlib import Path
import os
import subprocess
import sys


def test_configure_codex_sidecar_uses_only_staged_home(tmp_path: Path) -> None:
    source = Path.home() / ".codex" / "config.toml"
    staged = tmp_path / ".codex"
    staged.mkdir()
    staged_config = staged / "config.toml"
    staged_config.write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    env_file = tmp_path / "sidecar.env"

    script = Path(__file__).parents[1] / "scripts" / "configure_codex_sidecar.py"
    env = {**os.environ, "NUROUTER_PROCESS_SIDECAR_TOKEN": "test-sidecar-token"}
    subprocess.run(
        [
            sys.executable, str(script), str(Path(__file__).parents[1]), str(staged),
            "http", "host.docker.internal", "45678", "--env-file", str(env_file),
        ],
        check=True,
        env=env,
    )
    rendered = staged_config.read_text(encoding="utf-8")
    assert 'model_provider = "nurouter"' in rendered
    assert 'chatgpt_base_url = "http://host.docker.internal:45678/proxy/backend-api"' in rendered
    assert 'base_url = "http://host.docker.internal:45678/proxy/backend-api/codex"' in rendered
    assert 'env_key = "NUROUTER_PROCESS_SIDECAR_TOKEN"' in rendered
    assert 'requires_openai_auth = false' in rendered
    assert env_file.read_text(encoding="utf-8") == "NUROUTER_PROCESS_SIDECAR_TOKEN=test-sidecar-token\n"
