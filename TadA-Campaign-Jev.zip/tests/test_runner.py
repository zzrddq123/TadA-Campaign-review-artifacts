import json
import os
from contextlib import contextmanager
from pathlib import Path
from threading import Thread

import pytest

from tests.helpers import inject_judge_server_url, write_experiment_config, write_minimal_prepared_bundle, write_skill_market_bundle
from TadACampaign.backends import BackendError
from TadACampaign.judge import JudgeHttpClient
from TadACampaign.judge.http import JudgeService, _JudgeHTTPServer
from TadACampaign.models import AgentDecision
from TadACampaign.runner import (
    _load_agent_playbook_text,
    _load_judge_session,
    assert_run_succeeded,
    load_experiment_config,
    run_agent_step,
    run_experiment,
)

TEST_ADMIN_TOKEN = "test-admin-token"


def _write_config(
    tmp_path: Path,
    prepared_root: Path,
    *,
    judge_server_url: str | None = None,
    backend: str = "codex",
) -> Path:
    return write_experiment_config(
        tmp_path / "experiment.toml",
        name="runner_test",
        prepared_root=prepared_root,
        output_root=tmp_path / "runs",
        max_experiment_days=10.0,
        judge_server_url=judge_server_url,
        backend=backend,
    )


def _write_relative_config(tmp_path: Path, prepared_root: Path) -> Path:
    config_dir = tmp_path / "configs"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "experiment.toml"
    config_path.write_text(
        (
            'name = "runner_test"\n'
            'prepared_root = "../prepared"\n'
            'variant = "protein"\n'
            'output_root = "../runs"\n'
            "seed = 5\n"
            "initial_cash = 1000.0\n"
            "base_asset_value = 1000.0\n"
            "baseline_activity = 1.0\n"
            "screening_noise_enabled = true\n"
            "screening_noise_sigma = 0.10\n"
            "screening_noise_clip = 0.20\n"
            "prepare_seed_cost = 25.0\n"
            "prepare_library_cost = 10.0\n"
            "daily_burn_cost = 1.0\n"
            "prepare_seed_days = 1.0\n"
            "prepare_library_days = 1.0\n"
            "confirm_hit_cost = 5.0\n"
            "confirm_hit_days = 1.0\n"
            'initial_visible_seeds = ["seed1"]\n'
            'initial_prepared_seeds = []\n'
            "max_experiment_days = 10.0\n"
            "agent_timeout_seconds = 30\n"
            "\n"
            "[[reward_tiers]]\n"
            "min_activity = 1.0\n"
            'max_activity = "inf"\n'
            "multiplier = 1.0\n"
            "\n"
            "[[mine_batch_menu]]\n"
            "batch_size = 1\n"
            "cost = 10.0\n"
            "time_days = 1.0\n"
            "\n"
            "[agent]\n"
            'backend = "codex"\n'
            "\n"
            "[judge]\n"
            "request_timeout_seconds = 5\n"
        ),
        encoding="utf-8",
    )
    assert prepared_root == tmp_path / "prepared"
    return config_path


@contextmanager
def _running_judge(config_path: Path, audit_root: Path):
    config = load_experiment_config(config_path)
    previous_admin_token = os.environ.get("TADACAMPAIGN_JUDGE_ADMIN_TOKEN")
    os.environ["TADACAMPAIGN_JUDGE_ADMIN_TOKEN"] = TEST_ADMIN_TOKEN
    service = JudgeService(config, audit_root=audit_root, admin_token=TEST_ADMIN_TOKEN)
    server = _JudgeHTTPServer(("127.0.0.1", 0), service)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        base_url = f"http://127.0.0.1:{server.server_port}"
        inject_judge_server_url(config_path, base_url)
        yield base_url
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()
        if previous_admin_token is None:
            os.environ.pop("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", None)
        else:
            os.environ["TADACAMPAIGN_JUDGE_ADMIN_TOKEN"] = previous_admin_token


@pytest.mark.parametrize(
    ("removed_key", "removed_value"),
    [
        ("full_auto", "false"),
        ("dangerously_bypass_approvals", "true"),
        ("sandbox_mode", '"danger-full-access"'),
        ("search", "true"),
        ("codex_auto_resume", "false"),
        ("codex_context_window_handoff_max_count", "4"),
    ],
)
def test_load_experiment_config_rejects_removed_agent_keys(
    tmp_path: Path, removed_key: str, removed_value: str
) -> None:
    prepared_root = tmp_path / "prepared"
    config_path = _write_config(tmp_path, prepared_root)
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            '[agent]\nbackend = "codex"\n',
            f'[agent]\nbackend = "codex"\n{removed_key} = {removed_value}\n',
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="unsupported removed keys"):
        load_experiment_config(config_path)


@pytest.mark.parametrize(("removed_key", "removed_value"), [("mode", '"server"'), ("url", '"http://127.0.0.1:8787"')])
def test_load_experiment_config_rejects_removed_judge_keys(
    tmp_path: Path, removed_key: str, removed_value: str
) -> None:
    prepared_root = tmp_path / "prepared"
    config_path = _write_config(tmp_path, prepared_root)
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            "[judge]\nrequest_timeout_seconds = 5\n",
            f"[judge]\n{removed_key} = {removed_value}\nrequest_timeout_seconds = 5\n",
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="unsupported removed keys"):
        load_experiment_config(config_path)


def test_load_experiment_config_resolves_relative_paths_and_server_url(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    config_path = _write_relative_config(tmp_path, prepared_root)
    inject_judge_server_url(config_path, "http://127.0.0.1:8787")

    config = load_experiment_config(config_path)

    assert config.prepared_root == prepared_root.resolve()
    assert config.output_root == (tmp_path / "runs").resolve()
    assert config.judge_server_url == "http://127.0.0.1:8787"
    assert config.judge_request_timeout_seconds == 5
    assert config.screening_noise_enabled is True
    assert config.screening_noise_sigma == pytest.approx(0.10)
    assert config.screening_noise_clip == pytest.approx(0.20)


def test_load_agent_playbook_text_renders_current_reward_config(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    output_root = tmp_path / "runs"
    config_path = tmp_path / "experiment.toml"
    config_path.write_text(
        (
            'name = "runner_playbook_test"\n'
            f'prepared_root = "{prepared_root}"\n'
            'variant = "protein"\n'
            f'output_root = "{output_root}"\n'
            "seed = 7\n"
            "initial_cash = 2000.0\n"
            "base_asset_value = 4321.0\n"
            "baseline_activity = 1.25\n"
            "screening_noise_enabled = true\n"
            "screening_noise_sigma = 0.12\n"
            "screening_noise_clip = 0.18\n"
            "prepare_seed_cost = 25.0\n"
            "prepare_library_cost = 10.0\n"
            "daily_burn_cost = 1.0\n"
            "prepare_seed_days = 1.0\n"
            "prepare_library_days = 1.0\n"
            "confirm_hit_cost = 5.0\n"
            "confirm_hit_days = 1.0\n"
            'initial_visible_seeds = ["seed1"]\n'
            'initial_prepared_seeds = []\n'
            "max_experiment_days = 10.0\n"
            "agent_timeout_seconds = 30\n"
            "\n"
            "[[reward_tiers]]\n"
            "min_activity = 1.25\n"
            "max_activity = 2.0\n"
            "multiplier = 0.5\n"
            "\n"
            "[[reward_tiers]]\n"
            "min_activity = 2.0\n"
            'max_activity = "inf"\n'
            "multiplier = 1.5\n"
            "\n"
            "[[mine_batch_menu]]\n"
            "batch_size = 1\n"
            "cost = 10.0\n"
            "time_days = 1.0\n"
            "\n"
            "[agent]\n"
            'backend = "codex"\n'
            "\n"
            "[judge]\n"
            "request_timeout_seconds = 5\n"
        ),
        encoding="utf-8",
    )

    config = load_experiment_config(config_path)
    text = _load_agent_playbook_text(config)

    assert "base_asset_value = 4321.0" in text
    assert "baseline_activity = 1.25" in text
    assert "tier 1: `[1.25, 2.0)`， `multiplier = 0.5`" in text
    assert "tier 2: `[2.0, +inf)`， `multiplier = 1.5`" in text
    assert "例如，在当前 config 下：" in text


def test_load_experiment_config_rejects_skill_market_for_non_codex_backend(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = _write_config(tmp_path, prepared_root, backend="claude")
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            "agent_timeout_seconds = 30\n",
            f'agent_timeout_seconds = 30\nskill_market_manifest = "{market_manifest}"\n',
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="currently supported only for the codex backend"):
        load_experiment_config(config_path)


def test_load_experiment_config_accepts_judge_scoped_skill_market_manifest(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = _write_config(tmp_path, prepared_root)
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            "[judge]\nrequest_timeout_seconds = 5\n",
            f'[judge]\nrequest_timeout_seconds = 5\nskill_market_manifest = "{market_manifest}"\n',
        ),
        encoding="utf-8",
    )

    config = load_experiment_config(config_path)

    assert config.skill_market_manifest == market_manifest.resolve()


def test_load_experiment_config_accepts_forced_initial_owned_skills(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = _write_config(tmp_path, prepared_root)
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            "[judge]\nrequest_timeout_seconds = 5\n",
            (
                "[judge]\n"
                "request_timeout_seconds = 5\n"
                f'skill_market_manifest = "{market_manifest}"\n'
                "skill_market_enabled = false\n"
                'initial_owned_skill_ids = ["protein-scout"]\n'
            ),
        ),
        encoding="utf-8",
    )

    config = load_experiment_config(config_path)

    assert config.skill_market_manifest == market_manifest.resolve()
    assert config.skill_market_enabled is False
    assert config.initial_owned_skill_ids == ("protein-scout",)


def test_load_experiment_config_rejects_initial_owned_skills_without_manifest(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    config_path = _write_config(tmp_path, prepared_root)
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            "[judge]\nrequest_timeout_seconds = 5\n",
            '[judge]\nrequest_timeout_seconds = 5\ninitial_owned_skill_ids = ["protein-scout"]\n',
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="initial_owned_skill_ids requires skill_market_manifest"):
        load_experiment_config(config_path)


def test_load_experiment_config_accepts_policy_backend(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    config_path = _write_config(tmp_path, prepared_root, backend="policy")
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            '[agent]\nbackend = "policy"\n',
            '[agent]\nbackend = "policy"\npolicy = "stop_now"\n',
        ),
        encoding="utf-8",
    )

    config = load_experiment_config(config_path)

    assert config.agent_backend == "policy"
    assert config.agent_policy == "stop_now"


def test_load_experiment_config_rejects_policy_backend_without_policy(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    config_path = _write_config(tmp_path, prepared_root, backend="policy")

    with pytest.raises(ValueError, match=r"\[agent\]\.policy"):
        load_experiment_config(config_path)


def test_load_judge_session_rejects_non_server_transport(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    session_path = run_dir / "process" / "agent_workspace" / "judge_session.json"
    session_path.parent.mkdir(parents=True, exist_ok=True)
    session_path.write_text(json.dumps({"transport": "local"}) + "\n", encoding="utf-8")

    with pytest.raises(RuntimeError, match="only 'server' is supported"):
        _load_judge_session(run_dir)


def test_run_experiment_supports_policy_backend(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root, backend="policy")
    config_path.write_text(
        config_path.read_text(encoding="utf-8").replace(
            '[agent]\nbackend = "policy"\n',
            '[agent]\nbackend = "policy"\npolicy = "stop_now"\n',
        ),
        encoding="utf-8",
    )

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert summary["agent_backend"] == "policy"
    assert summary["agent_policy"] == "stop_now"
    assert summary["stop_code"] == "agent_stop"
    assert summary["cash_final"] == pytest.approx(1000.0)
    assert (run_dir / "results" / "agent_stdout.log").is_file()
    assert (run_dir / "results" / "agent_final_result.json").is_file()


def test_run_experiment_writes_expected_artifacts(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, agent_workspace
        (run_dir / "results" / "codex_events.jsonl").write_text(
            '{"type":"thread.started","thread_id":"thread-1"}\n'
            '{"type":"turn.started"}\n'
            '{"type":"turn.completed","usage":{"input_tokens":1,"cached_input_tokens":0,"output_tokens":1}}\n',
            encoding="utf-8",
        )
        (run_dir / "results" / "codex_final_result.json").write_text(
            json.dumps({"status": "completed", "stop_reason": "done", "action_count": 4}) + "\n",
            encoding="utf-8",
        )
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        run_agent_step(
            run_dir,
            AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open"),
        )
        run_agent_step(
            run_dir,
            AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="mine"),
        )
        run_agent_step(run_dir, AgentDecision(action="stop", reasoning="done"))
        return {"thread_id": "thread-1"}

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert (run_dir / "results" / "summary.md").is_file()
    assert (run_dir / "results" / "cash_curve.png").is_file()
    assert (run_dir / "results" / "codex_events.jsonl").is_file()
    assert (run_dir / "results" / "runtime_timeline.jsonl").is_file()
    assert (run_dir / "process" / "step_001" / "step_meta.json").is_file()
    assert not (run_dir / "process" / "agent_workspace" / "AGENTS.md").exists()
    assert summary["action_count"] >= 2
    assert summary["execution_model"] == "docker_agent_host_judge"
    assert summary["artifacts"]["codex_events_jsonl"].endswith("codex_events.jsonl")
    assert summary["artifacts"]["runtime_timeline_jsonl"].endswith("runtime_timeline.jsonl")
    assert summary["codex_thread_id"] == "thread-1"
    assert summary["codex_attempt_count"] == 1
    assert summary["codex_resume_count"] == 0
    assert summary["codex_handoff_count"] == 0
    assert summary["run_started_at"]
    assert summary["run_completed_at"]
    assert summary["screening_noise_enabled"] is True
    assert summary["screening_noise_sigma"] == pytest.approx(0.10)
    assert summary["screening_noise_clip"] == pytest.approx(0.20)
    assert summary["wall_clock_duration_seconds"] is not None

    results_manifest = json.loads((run_dir / "results" / "seed_manifest.json").read_text(encoding="utf-8"))
    assert results_manifest[0]["start_sequence"] == "AAAAAA"
    step_meta = json.loads((run_dir / "process" / "step_001" / "step_meta.json").read_text(encoding="utf-8"))
    assert step_meta["step_index"] == 1
    assert step_meta["observation_request"]["ok"] is True
    assert step_meta["action_request"]["ok"] is True


def test_run_experiment_records_backend_error_after_partial_progress(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, agent_workspace
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        raise BackendError("simulated timeout")

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert summary["action_count"] == 2
    assert summary["stop_code"] == "backend_error"
    assert summary["stop_reason"] == "backend_error: simulated timeout"
    assert summary["backend_force_stopped"] is True
    assert summary["backend_failure_count"] == 1
    assert summary["backend_recovery_attempt_count"] == 0
    assert summary["backend_terminal_failure_count"] == 1
    assert summary["backend_final_failure_classification"] == "terminal_backend_error"
    assert summary["backend_final_error"] == "simulated timeout"


def test_run_agent_step_persists_step_meta_when_action_request_fails(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    original_submit_action = JudgeHttpClient.submit_action

    def failing_submit_action(self, session_id: str, decision: AgentDecision):
        del session_id, decision
        raise RuntimeError("simulated submit failure")

    monkeypatch.setattr(JudgeHttpClient, "submit_action", failing_submit_action)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, agent_workspace
        try:
            run_agent_step(
                run_dir,
                AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"),
            )
        except RuntimeError as exc:
            raise BackendError(str(exc)) from exc
        finally:
            monkeypatch.setattr(JudgeHttpClient, "submit_action", original_submit_action)
        return {"thread_id": "thread-1"}

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    step_meta = json.loads((run_dir / "process" / "step_001" / "step_meta.json").read_text(encoding="utf-8"))
    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))

    assert step_meta["action_request"]["ok"] is False
    assert step_meta["action_request"]["error"] == "simulated submit failure"
    assert summary["stop_code"] == "backend_error"
    assert summary["stop_reason"] == "backend_error: simulated submit failure"


def test_run_experiment_records_backend_error_after_terminal_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, agent_workspace
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        run_agent_step(run_dir, AgentDecision(action="stop", reasoning="done"))
        raise BackendError("late failure")

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert summary["action_count"] == 2
    assert summary["stop_reason"] == "backend_error: late failure"


def test_run_experiment_preserves_resume_artifact_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, agent_workspace
        (run_dir / "results" / "codex_events.jsonl").write_text(
            '{"type":"turn.started"}\n'
            '{"type":"turn.completed","usage":{"input_tokens":1,"cached_input_tokens":0,"output_tokens":1}}\n',
            encoding="utf-8",
        )
        (run_dir / "results" / "codex_resume_meta.json").write_text(
            json.dumps(
                {
                    "version": 2,
                    "enabled": True,
                    "max_resume_attempts": 0,
                    "max_context_window_handoffs": -1,
                    "attempts_total": 2,
                    "resume_count": 1,
                    "handoff_count": 0,
                    "retryable_failure_count": 1,
                    "success": True,
                    "final_thread_id": "thread-1",
                    "attempts": [],
                }
            )
            + "\n",
            encoding="utf-8",
        )
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        run_agent_step(run_dir, AgentDecision(action="stop", reasoning="done"))
        return {"thread_id": "thread-1", "resume_meta_path": str(run_dir / "results" / "codex_resume_meta.json")}

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert summary["codex_thread_id"] == "thread-1"
    assert summary["codex_attempt_count"] == 2
    assert summary["codex_resume_count"] == 1
    assert summary["codex_handoff_count"] == 0
    assert summary["artifacts"]["codex_resume_meta_json"].endswith("codex_resume_meta.json")


def test_run_experiment_surfaces_handoff_counts_from_runtime_meta(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, agent_workspace
        (run_dir / "results" / "codex_events.jsonl").write_text(
            '{"type":"thread.started","thread_id":"thread-2"}\n'
            '{"type":"turn.started"}\n'
            '{"type":"turn.completed","usage":{"input_tokens":1,"cached_input_tokens":0,"output_tokens":1}}\n',
            encoding="utf-8",
        )
        (run_dir / "results" / "codex_final_result.json").write_text(
            json.dumps({"status": "completed", "stop_reason": "done", "action_count": 3}) + "\n",
            encoding="utf-8",
        )
        (run_dir / "results" / "codex_resume_meta.json").write_text(
            json.dumps(
                {
                    "version": 2,
                    "enabled": True,
                    "max_resume_attempts": 0,
                    "max_context_window_handoffs": -1,
                    "attempts_total": 2,
                    "resume_count": 0,
                    "handoff_count": 1,
                    "retryable_failure_count": 1,
                    "success": True,
                    "final_thread_id": "thread-2",
                    "attempts": [],
                }
            )
            + "\n",
            encoding="utf-8",
        )
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        run_agent_step(run_dir, AgentDecision(action="stop", reasoning="done"))
        return {"thread_id": "thread-2", "resume_meta_path": str(run_dir / "results" / "codex_resume_meta.json")}

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert summary["codex_thread_id"] == "thread-2"
    assert summary["codex_attempt_count"] == 2
    assert summary["codex_resume_count"] == 0
    assert summary["codex_handoff_count"] == 1
    assert summary["artifacts"]["codex_resume_meta_json"].endswith("codex_resume_meta.json")


def test_run_experiment_keeps_resume_artifact_when_retry_chain_still_fails(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, agent_workspace
        (run_dir / "results" / "codex_events.jsonl").write_text(
            '{"type":"turn.started"}\n{"type":"error","message":"stream disconnected before completion"}\n',
            encoding="utf-8",
        )
        (run_dir / "results" / "codex_events_attempt1.jsonl").write_text(
            '{"type":"thread.started","thread_id":"thread-1"}\n'
            '{"type":"error","message":"stream disconnected before completion"}\n',
            encoding="utf-8",
        )
        (run_dir / "results" / "codex_resume_meta.json").write_text(
            json.dumps(
                {
                    "version": 2,
                    "enabled": True,
                    "max_resume_attempts": 1,
                    "max_context_window_handoffs": -1,
                    "attempts_total": 2,
                    "resume_count": 1,
                    "handoff_count": 0,
                    "retryable_failure_count": 1,
                    "failure_count": 2,
                    "terminal_failure_count": 1,
                    "failure_classification_counts": {
                        "retryable_interruption": 1,
                        "terminal_backend_error": 1,
                    },
                    "success": False,
                    "final_thread_id": "thread-1",
                    "final_error": "simulated timeout after retry",
                    "attempts": [
                        {
                            "classification": "retryable_interruption",
                            "retryable": True,
                            "continuation_mode": "resume",
                            "stop_reason": "stream disconnected before completion",
                        },
                        {
                            "classification": "terminal_backend_error",
                            "retryable": False,
                            "continuation_mode": "terminal",
                            "stop_reason": "simulated timeout after retry",
                        },
                    ],
                }
            )
            + "\n",
            encoding="utf-8",
        )
        raise BackendError("simulated timeout after retry", thread_id="thread-1")

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert summary["stop_reason"] == "backend_error: simulated timeout after retry"
    assert summary["codex_thread_id"] == "thread-1"
    assert summary["codex_attempt_count"] == 2
    assert summary["codex_resume_count"] == 1
    assert summary["codex_handoff_count"] == 0
    assert summary["backend_force_stopped"] is True
    assert summary["backend_failure_count"] == 2
    assert summary["backend_retryable_failure_count"] == 1
    assert summary["backend_recovery_attempt_count"] == 1
    assert summary["backend_terminal_failure_count"] == 1
    assert summary["backend_failure_classification_counts"] == {
        "retryable_interruption": 1,
        "terminal_backend_error": 1,
    }
    assert summary["backend_final_failure_classification"] == "terminal_backend_error"
    assert summary["backend_final_error"] == "simulated timeout after retry"
    assert summary["artifacts"]["codex_resume_meta_json"].endswith("codex_resume_meta.json")


def test_run_experiment_reloads_relative_paths_from_snapshot_after_backend_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_relative_config(tmp_path, prepared_root)

    def fake_backend(config, *, run_dir, agent_workspace):
        del config, run_dir, agent_workspace
        raise BackendError("simulated timeout")

    monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)

    with _running_judge(config_path, tmp_path / "audit"):
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    assert summary["stop_reason"] == "backend_error: simulated timeout"
    config_snapshot = (run_dir / "config.toml").read_text(encoding="utf-8")
    assert f'prepared_root = "{prepared_root}"' in config_snapshot
    assert f'output_root = "{(tmp_path / "runs").resolve()}"' in config_snapshot


def test_assert_run_succeeded_rejects_backend_error(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    results_dir = run_dir / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    (results_dir / "summary.json").write_text(
        json.dumps({"stop_reason": "backend_error: simulated timeout"}) + "\n",
        encoding="utf-8",
    )

    with pytest.raises(RuntimeError, match="backend_error"):
        assert_run_succeeded(run_dir)


def test_run_experiment_requires_public_launch_script_injected_server_url(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)
    os.environ["TADACAMPAIGN_JUDGE_ADMIN_TOKEN"] = TEST_ADMIN_TOKEN

    try:
        with pytest.raises(RuntimeError, match="public launch script must inject \\[judge\\]\\.server_url"):
            run_experiment(config_path)
    finally:
        os.environ.pop("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", None)


def test_run_experiment_fails_closed_when_judge_is_unreachable(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root, judge_server_url="http://127.0.0.1:9")
    monkeypatch.setenv("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", TEST_ADMIN_TOKEN)

    with pytest.raises(RuntimeError, match="Judge request failed"):
        run_experiment(config_path)
