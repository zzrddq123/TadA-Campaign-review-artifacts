from pathlib import Path

import pytest

from tests.helpers import write_skill_market_bundle
from TadACampaign.environment import TadACampaignEnvironment
from TadACampaign.models import (
    AgentDecision,
    ExperimentConfig,
    LibraryDefinition,
    MineBatchOption,
    RewardTier,
    SeedDefinition,
)
from TadACampaign.skill_market import load_skill_market_catalog

AGENT_PRIVATE_PAYLOAD_KEYS = {"historical_round_id", "unlock_child_seed_ids", "revealed_child_seed_ids"}


def _assert_no_agent_private_payload_keys(payload) -> None:
    if isinstance(payload, dict):
        leaked = AGENT_PRIVATE_PAYLOAD_KEYS.intersection(payload)
        assert not leaked
        for value in payload.values():
            _assert_no_agent_private_payload_keys(value)
    elif isinstance(payload, list):
        for item in payload:
            _assert_no_agent_private_payload_keys(item)


def _config(
    tmp_path: Path,
    *,
    mine_batch_menu: tuple[MineBatchOption, ...] | None = None,
    max_experiment_days: float = 10.0,
    skill_market_manifest: Path | None = None,
    skill_market_enabled: bool = True,
    initial_owned_skill_ids: tuple[str, ...] = (),
    screening_noise_enabled: bool = True,
    screening_noise_sigma: float = 0.10,
    screening_noise_clip: float = 0.20,
) -> ExperimentConfig:
    return ExperimentConfig(
        name="env_test",
        prepared_root=tmp_path,
        variant="protein",
        output_root=tmp_path,
        seed=1,
        initial_cash=1000.0,
        base_asset_value=1000.0,
        baseline_activity=1.0,
        prepare_seed_cost=50.0,
        prepare_seed_days=1.0,
        prepare_library_cost=10.0,
        daily_burn_cost=2.0,
        prepare_library_days=1.0,
        confirm_hit_cost=30.0,
        confirm_hit_days=1.0,
        purchase_skill_days=1.0,
        mine_batch_menu=mine_batch_menu
        or (
            MineBatchOption(batch_size=1, cost=21.0, time_days=1.0),
            MineBatchOption(batch_size=2, cost=22.0, time_days=1.0),
        ),
        initial_visible_seeds=("seed1",),
        initial_prepared_seeds=(),
        max_experiment_days=max_experiment_days,
        agent_timeout_seconds=30,
        reward_tiers=(
            RewardTier(min_activity=1.0, max_activity=1.2, multiplier=1.0),
            RewardTier(min_activity=1.2, max_activity=1.5, multiplier=2.0),
            RewardTier(min_activity=1.5, max_activity=float("inf"), multiplier=4.0),
        ),
        linear_issue=None,
        agent_backend="codex",
        agent_model=None,
        agent_profile=None,
        agent_reasoning_effort=None,
        agent_verbosity=None,
        agent_codex_context_window_handoff_max_count=-1,
        skill_market_manifest=skill_market_manifest,
        skill_market_enabled=skill_market_enabled,
        initial_owned_skill_ids=initial_owned_skill_ids,
        judge_server_url=None,
        judge_request_timeout_seconds=10,
        screening_noise_enabled=screening_noise_enabled,
        screening_noise_sigma=screening_noise_sigma,
        screening_noise_clip=screening_noise_clip,
    )


def _seed_definitions() -> list[SeedDefinition]:
    return [
        SeedDefinition(
            seed_id="seed1",
            start_sequence="AAAAAA",
            parent_seed_candidates=(),
            parent_seed_id=None,
            parent_library_candidates=(),
            parent_library_id=None,
            parent_resolution_evidence={"rule": "root_seed"},
            historical_round_ids=("r1",),
            libraries=(
                LibraryDefinition(
                    library_id="seed1_library1",
                    seed_id="seed1",
                    historical_round_id="r1",
                    raw_domain_id=0,
                    start_sequence="AAAAAA",
                    interval_start_aa=2,
                    interval_end_aa=4,
                    unlock_child_seed_ids=("seed2", "seed3"),
                ),
            ),
        ),
        SeedDefinition(
            seed_id="seed2",
            start_sequence="AABBAA",
            parent_seed_candidates=("seed1",),
            parent_seed_id="seed1",
            parent_library_candidates=("seed1_library1",),
            parent_library_id="seed1_library1",
            parent_resolution_evidence={"rule": "single_parent"},
            historical_round_ids=("r2",),
            libraries=(
                LibraryDefinition(
                    library_id="seed2_library1",
                    seed_id="seed2",
                    historical_round_id="r2",
                    raw_domain_id=1,
                    start_sequence="AABBAA",
                    interval_start_aa=2,
                    interval_end_aa=4,
                ),
            ),
        ),
        SeedDefinition(
            seed_id="seed3",
            start_sequence="AACCAA",
            parent_seed_candidates=("seed1",),
            parent_seed_id="seed1",
            parent_library_candidates=("seed1_library1",),
            parent_library_id="seed1_library1",
            parent_resolution_evidence={"rule": "single_parent"},
            historical_round_ids=("r3",),
            libraries=(
                LibraryDefinition(
                    library_id="seed3_library1",
                    seed_id="seed3",
                    historical_round_id="r3",
                    raw_domain_id=2,
                    start_sequence="AACCAA",
                    interval_start_aa=2,
                    interval_end_aa=4,
                ),
            ),
        ),
    ]


def _prepared_rows() -> list[dict[str, object]]:
    return [
        {"sequence": "AABBAA", "activity": 1.2, "round_ids": ["r1", "r2"]},
        {"sequence": "AACCAA", "activity": 1.4, "round_ids": ["r1", "r3"]},
        {"sequence": "AADDAA", "activity": 1.1, "round_ids": ["r1"]},
    ]


def test_environment_bootstrap_exposes_visible_seed_without_prepared_libraries(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    state = env.get_state()
    actions = env.available_actions()

    assert env.visible_seed_ids == {"seed1"}
    assert env.prepared_seed_ids == set()
    assert env.prepared_library_ids == set()
    assert state["visible_seed_ids"] == ["seed1"]
    assert state["prepared_seed_ids"] == []
    assert state["prepared_library_ids"] == []
    assert actions["mine_library"] == []
    assert [item["seed_id"] for item in actions["prepare_seed"]] == ["seed1"]
    assert actions["prepare_library"] == []
    assert {item["seed_id"] for item in state["seeds"]} == {"seed1"}
    seed1 = state["seeds"][0]
    assert seed1["seed_status"] == "visible"
    assert seed1["start_sequence"] == "AAAAAA"
    assert seed1["libraries"][0]["library_status"] == "locked"
    assert "unlock_child_seed_ids" not in seed1["libraries"][0]
    assert "revealed_child_seed_ids" not in seed1["libraries"][0]
    _assert_no_agent_private_payload_keys(state)
    _assert_no_agent_private_payload_keys(actions)
    assert "screenable_sequence_count" not in seed1["libraries"][0]


def test_prepare_seed_only_marks_seed_prepared(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    record = env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    actions = env.available_actions()

    assert record["newly_visible_seed_ids"] == []
    assert env.visible_seed_ids == {"seed1"}
    assert env.prepared_seed_ids == {"seed1"}
    assert [item["seed_id"] for item in actions["prepare_seed"]] == []
    assert {item["seed_id"] for item in actions["prepare_library"]} == {"seed1"}
    assert all("unlock_child_seed_ids" not in item for item in actions["prepare_library"])
    _assert_no_agent_private_payload_keys(actions)
    state = env.get_state()
    seed1 = state["seeds"][0]
    assert seed1["seed_status"] == "prepared"
    assert "unlock_child_seed_ids" not in seed1["libraries"][0]
    assert "revealed_child_seed_ids" not in seed1["libraries"][0]
    _assert_no_agent_private_payload_keys(state)


def test_prepare_library_reveals_branch_children_without_preparing_them(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    record = env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open branch")
    )
    actions = env.available_actions()

    assert record["newly_visible_seed_ids"] == ["seed2", "seed3"]
    assert env.visible_seed_ids == {"seed1", "seed2", "seed3"}
    assert env.prepared_seed_ids == {"seed1"}
    assert env.prepared_library_ids == {"seed1_library1"}
    assert [item["seed_id"] for item in actions["prepare_seed"]] == ["seed2", "seed3"]
    assert actions["prepare_library"] == []
    state = env.get_state()
    per_seed = {item["seed_id"]: item for item in state["seeds"]}
    assert per_seed["seed1"]["libraries"][0]["library_status"] == "prepared"
    assert "unlock_child_seed_ids" not in per_seed["seed1"]["libraries"][0]
    assert "revealed_child_seed_ids" not in per_seed["seed1"]["libraries"][0]
    assert per_seed["seed1"]["libraries"][0]["screenable_sequence_count"] == 3
    assert per_seed["seed2"]["seed_status"] == "visible"
    assert per_seed["seed3"]["seed_status"] == "visible"
    _assert_no_agent_private_payload_keys(state)
    _assert_no_agent_private_payload_keys(actions)


def test_time_horizon_blocks_actions_that_do_not_fit_remaining_days(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(
            tmp_path,
            mine_batch_menu=(MineBatchOption(batch_size=1, cost=21.0, time_days=1.0),),
            max_experiment_days=1.0,
        ),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    actions = env.available_actions()

    assert actions["prepare_seed"] == []
    assert actions["prepare_library"] == []
    assert actions["mine_library"] == []
    assert actions["stop"] == {"action": "stop"}
    assert env.stop_reason == "已达到 max_experiment_days，实验结束"
    assert env.stop_code == "max_experiment_days"

def test_validate_decision_enforces_visibility_and_discrete_batch_menu(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    assert env.validate_decision(AgentDecision(action="prepare_seed", seed_id="seed3", reasoning="skip")) == (
        "不能 `prepare_seed` 不可见的 seed seed3"
    )
    detail = env.validate_decision_detail(AgentDecision(action="prepare_seed", seed_id="seed3", reasoning="skip"))
    assert detail is not None
    assert detail.code == "seed_not_visible"
    assert env.validate_decision(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="skip")
    ) == "不能在未 prepared 的 seed seed1 上执行 `prepare_library`"

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )

    assert env.validate_decision(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=4, reasoning="illegal")
    ) == "非法 `batch_size=4`；seed1/seed1_library1 的合法取值为 [1, 2]"
    batch_detail = env.validate_decision_detail(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=4, reasoning="illegal")
    )
    assert batch_detail is not None
    assert batch_detail.code == "illegal_batch_size"


def test_mining_library_does_not_change_visible_seed_set(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    visible_before = sorted(env.visible_seed_ids)
    record = env.apply(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="mine")
    )
    actions = env.available_actions()

    assert sorted(env.visible_seed_ids) == visible_before
    assert record["actual_batch_size"] == 2
    assert record["new_sequence_count"] == 2
    assert env.summary()["cash_final"] > 0.0
    assert record["reward_earned"] == pytest.approx(0.0)
    assert env.summary()["reward_earned_total"] == pytest.approx(0.0)
    assert env.confirmed_best_activity == pytest.approx(1.0)
    assert env.provisional_best_activity > env.confirmed_best_activity
    assert len(actions["confirm_hit"]) == 1
    assert actions["confirm_hit"][0]["observed_activity"] == pytest.approx(env.provisional_best_activity)


def test_confirm_hit_pays_reward_only_after_confirmation(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    mine_record = env.apply(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="screen")
    )
    confirm_actions = env.available_actions()["confirm_hit"]
    screen_record_id = int(confirm_actions[0]["screen_record_id"])

    assert mine_record["reward_earned"] == pytest.approx(0.0)
    cash_before_confirm = env.cash
    day_before_confirm = env.day

    confirm_record = env.apply(AgentDecision(action="confirm_hit", screen_record_id=screen_record_id, reasoning="confirm lead"))

    assert confirm_record["reward_earned"] > 0.0
    assert confirm_record["confirmed_best_before"] == pytest.approx(1.0)
    assert confirm_record["confirmed_best_after"] == pytest.approx(env.confirmed_best_activity)
    assert confirm_record["observed_activity"] == pytest.approx(env.provisional_best_activity)
    assert confirm_record["confirmed_activity"] == pytest.approx(env.confirmed_best_activity)
    assert env.total_reward_earned == pytest.approx(confirm_record["reward_earned"])
    assert env.cash == pytest.approx(
        cash_before_confirm - (env.config.confirm_hit_cost + env.config.confirm_hit_days * env.config.daily_burn_cost) + confirm_record["reward_earned"]
    )
    assert env.day == pytest.approx(day_before_confirm + env.config.confirm_hit_days)
    assert env.available_actions()["confirm_hit"] == []
    assert env.summary()["pending_confirmation_count"] == 0


def test_validate_confirm_hit_rejects_unknown_and_repeated_screen_record_ids(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    assert env.validate_decision(AgentDecision(action="confirm_hit", screen_record_id=0, reasoning="missing")) == (
        "未知 `screen_record_id`: 0"
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    env.apply(AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="screen"))
    confirm_actions = env.available_actions()["confirm_hit"]
    screen_record_id = int(confirm_actions[0]["screen_record_id"])

    assert env.validate_decision(AgentDecision(action="confirm_hit", screen_record_id=screen_record_id, reasoning="confirm")) is None
    env.apply(AgentDecision(action="confirm_hit", screen_record_id=screen_record_id, reasoning="confirm"))
    assert env.validate_decision(AgentDecision(action="confirm_hit", screen_record_id=screen_record_id, reasoning="repeat")) == (
        f"Screen record {screen_record_id} 已确认"
    )


def test_confirm_hit_is_not_legal_when_cash_cannot_cover_total_cost(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    env.apply(AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="screen"))

    env.cash = env._confirm_total_cost() - 0.01

    assert env.available_actions()["confirm_hit"] == []
    screen_record_id = int(env.pending_confirmation_screen_record_ids[0])
    assert env.validate_decision(AgentDecision(action="confirm_hit", screen_record_id=screen_record_id, reasoning="confirm")) == (
        f"现金不足，无法执行 `confirm_hit`；当前现金 {env.cash:.2f}，需要 {env._confirm_total_cost():.2f}"
    )


def test_state_exposes_economic_summary_for_budget_closure(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    summary = env.get_state()["economic_summary"]

    assert summary["action_total_costs"]["confirm_hit"] == pytest.approx(env._confirm_total_cost())
    assert summary["action_total_costs"]["mine_library_min"] == pytest.approx(
        env._mine_total_cost(env.config.mine_batch_menu[0])
    )
    assert summary["minimum_mine_then_confirm_total_cost"] == pytest.approx(
        env._mine_total_cost(env.config.mine_batch_menu[0]) + env._confirm_total_cost()
    )
    assert summary["configured_minimum_mine_then_confirm_total_cost"] == pytest.approx(
        env._mine_total_cost(env.config.mine_batch_menu[0]) + env._confirm_total_cost()
    )
    assert summary["minimum_mine_then_confirm_days"] == pytest.approx(
        env.config.mine_batch_menu[0].time_days + env.config.confirm_hit_days
    )
    assert summary["has_available_mine_option"] is False
    assert summary["available_mine_then_confirm_total_cost"] is None
    assert summary["cash_after_confirm_reserve"] == pytest.approx(env.cash - env._confirm_total_cost())
    assert summary["budget_regime"] == "can_mine_and_confirm"

    env.cash = env._confirm_total_cost() + 1.0
    constrained = env.get_state()["economic_summary"]

    assert constrained["can_afford_confirm_now"] is True
    assert constrained["can_afford_minimum_mine_then_confirm_now"] is False
    assert constrained["budget_regime"] == "confirm_only"

    env.cash = env._confirm_total_cost() - 1.0
    env.day = env.config.max_experiment_days - env.config.confirm_hit_days + 0.5
    blocked = env.get_state()["economic_summary"]

    assert blocked["can_afford_confirm_now"] is False
    assert blocked["has_time_for_confirm_now"] is False
    assert blocked["budget_regime"] == "cash_and_time_below_confirm"


def test_mine_batch_options_expose_confirm_reserve_capacity(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    cheapest_mine = env.config.mine_batch_menu[0]
    env.cash = env._mine_total_cost(cheapest_mine) + env._confirm_total_cost() - 0.01

    actions = env.available_actions()
    option = actions["mine_library"][0]["batch_options"][0]

    assert option["batch_size"] == cheapest_mine.batch_size
    assert option["total_cost"] == pytest.approx(env._mine_total_cost(cheapest_mine))
    assert option["cash_after_action_and_confirm_reserve"] == pytest.approx(-0.01)
    assert option["leaves_confirm_cash"] is False
    assert option["leaves_confirm_time"] is True
    assert option["leaves_confirm_capacity"] is False


def test_mine_batch_options_distinguish_confirmable_and_unconfirmable_batches(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    small_batch, large_batch = env.config.mine_batch_menu
    env.cash = env._mine_total_cost(small_batch) + env._confirm_total_cost() + 0.5

    actions = env.available_actions()
    options = {
        item["batch_size"]: item
        for item in actions["mine_library"][0]["batch_options"]
    }
    state_summary = env.get_state()["economic_summary"]

    assert set(options) == {small_batch.batch_size, large_batch.batch_size}
    assert options[small_batch.batch_size]["leaves_confirm_capacity"] is True
    assert options[small_batch.batch_size]["cash_after_action_and_confirm_reserve"] == pytest.approx(0.5)
    assert options[large_batch.batch_size]["leaves_confirm_capacity"] is False
    assert options[large_batch.batch_size]["cash_after_action_and_confirm_reserve"] == pytest.approx(-0.5)
    assert state_summary["has_available_mine_option"] is True
    assert state_summary["available_mine_then_confirm_total_cost"] == pytest.approx(
        env._mine_total_cost(small_batch) + env._confirm_total_cost()
    )


def test_available_actions_and_validation_hide_unaffordable_non_terminal_actions(tmp_path: Path) -> None:
    market_manifest = write_skill_market_bundle(tmp_path)
    config = _config(
        tmp_path,
        skill_market_manifest=market_manifest,
        mine_batch_menu=(MineBatchOption(batch_size=1, cost=100.0, time_days=1.0),),
    )
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=config,
        skill_market=load_skill_market_catalog(market_manifest),
    )

    env.cash = env._prepare_seed_total_cost() + 1.0
    actions = env.available_actions()

    assert [item["seed_id"] for item in actions["prepare_seed"]] == ["seed1"]
    assert actions["purchase_skill"] == []
    assert env.validate_decision(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter")) is None
    assert env.validate_decision(AgentDecision(action="purchase_skill", skill_id="protein-scout", reasoning="buy")) == (
        f"现金不足，无法执行 `purchase_skill`；当前现金 {env.cash:.2f}，需要 {env._purchase_total_cost('protein-scout'):.2f}"
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.cash = env._prepare_library_total_cost() + 1.0
    actions = env.available_actions()

    assert [item["library_id"] for item in actions["prepare_library"]] == ["seed1_library1"]
    assert env.validate_decision(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="prepare")
    ) is None

    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    env.cash = env._prepare_seed_total_cost() + 1.0
    actions = env.available_actions()

    assert actions["mine_library"] == []
    assert env.validate_decision(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="mine")
    ) == f"现金不足，无法执行 `mine_library`；当前现金 {env.cash:.2f}，需要至少 {env._mine_total_cost(env.config.mine_batch_menu[0]):.2f}"


def test_mine_pending_confirmation_legal_now_reflects_confirm_affordability(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    first_batch = env.config.mine_batch_menu[0]
    env.cash = env._mine_total_cost(first_batch) + env._confirm_total_cost() - 0.01

    record = env.apply(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="screen")
    )

    assert record["pending_confirmation_added"]["legal_now"] is False
    assert env.available_actions()["confirm_hit"] == []


def test_environment_runtime_state_roundtrip_preserves_progress(tmp_path: Path) -> None:
    config = _config(tmp_path)
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=config,
    )
    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    env.apply(AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="mine"))

    restored = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=config,
    )
    restored.restore_runtime_state(env.runtime_state())

    assert restored.get_state() == env.get_state()
    assert restored.get_history() == env.get_history()
    assert restored.summary() == env.summary()


def test_screening_noise_is_visible_publicly_but_true_activity_stays_hidden_until_confirm(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path, screening_noise_enabled=True, screening_noise_sigma=0.20, screening_noise_clip=0.20),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    env.apply(AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="screen"))

    public_screen_records = env.get_history()["recent_screen_records"]
    internal_screen_records = env.screen_record_history

    assert "observed_activity" in public_screen_records[0]
    assert "sequence" not in public_screen_records[0]
    assert public_screen_records[0]["sequence_prefix"] == internal_screen_records[0]["sequence"][:24]
    assert public_screen_records[0]["sequence_suffix"] == internal_screen_records[0]["sequence"][-24:]
    assert public_screen_records[0]["sequence_length"] == len(internal_screen_records[0]["sequence"])
    assert len(public_screen_records[0]["sequence_sha256"]) == 64
    assert "confirmed_activity" not in public_screen_records[0]
    assert "true_activity" not in public_screen_records[0]
    assert all("true_activity" in item for item in internal_screen_records)
    assert any(abs(float(item["observed_activity"]) - float(item["true_activity"])) > 1e-12 for item in internal_screen_records)
    assert all(
        abs((float(item["observed_activity"]) / float(item["true_activity"])) - 1.0) <= env.config.screening_noise_clip + 1e-9
        for item in internal_screen_records
    )


def test_agent_history_compacts_sequences_but_export_keeps_full_public_records(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path, screening_noise_enabled=False),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    mine_record = env.apply(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="screen")
    )

    history = env.get_history()
    recent_record = history["recent_screen_records"][0]
    recent_action = history["recent_actions"][-1]
    exported_record = env.public_screen_record_history()[0]

    assert recent_record["screen_record_id"] == exported_record["screen_record_id"]
    assert "sequence" not in recent_record
    assert "sequence" in exported_record
    assert recent_record["sequence_length"] == len(exported_record["sequence"])
    assert recent_record["sequence_prefix"] == exported_record["sequence"][:24]
    assert recent_record["sequence_suffix"] == exported_record["sequence"][-24:]
    assert "sequence" not in recent_action["best_update"]
    assert "sequence_prefix" in recent_action["best_update"]
    assert "sequence" not in recent_action["pending_confirmation_added"]
    assert "sequence_prefix" in recent_action["pending_confirmation_added"]
    assert mine_record["best_update"]["sequence"] == exported_record["sequence"]


def test_same_sequence_reuses_observed_activity_across_rediscovery(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path, screening_noise_enabled=True, screening_noise_sigma=0.20, screening_noise_clip=0.20),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    env.apply(AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="screen"))
    env.apply(AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="screen tail"))
    env.apply(AgentDecision(action="prepare_seed", seed_id="seed2", reasoning="enter child"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed2", library_id="seed2_library1", reasoning="open child")
    )
    env.apply(AgentDecision(action="mine_library", seed_id="seed2", library_id="seed2_library1", batch_size=1, reasoning="screen child"))

    aabb_entries = [item for item in env.screen_record_history if item["sequence"] == "AABBAA"]

    assert len(aabb_entries) == 2
    assert aabb_entries[0]["observed_activity"] == pytest.approx(aabb_entries[1]["observed_activity"])
    assert aabb_entries[0]["noise_fraction"] == pytest.approx(aabb_entries[1]["noise_fraction"])


def test_no_tail_mining_when_remaining_is_smaller_than_smallest_batch(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path, mine_batch_menu=(MineBatchOption(batch_size=2, cost=22.0, time_days=1.0),)),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open root")
    )
    env.apply(AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="mine"))
    actions = env.available_actions()

    assert actions["mine_library"] == []
    assert env.validate_decision(
        AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="tail")
    ) == (
        "Library seed1_library1 仍有剩余可筛序列，但没有任何合法 `batch_size` 能匹配当前 "
        "`remaining_screenable_sequence_count=1`"
    )


def test_realistic_large_batch_menu_hides_small_libraries_but_keeps_unlock_value(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path, mine_batch_menu=(MineBatchOption(batch_size=780, cost=1200.0, time_days=9.0),)),
    )

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    record = env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open branch")
    )
    actions = env.available_actions()

    assert record["screenable_sequence_count"] == 3
    assert record["newly_visible_seed_ids"] == ["seed2", "seed3"]
    assert actions["mine_library"] == []
    assert [item["seed_id"] for item in actions["prepare_seed"]] == ["seed2", "seed3"]


def test_reward_for_improvement_is_piecewise_across_tiers(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    reward = env._reward_for_improvement(1.1, 1.6)
    expected = 1000.0 * (
        (1.0 / 1.1 - 1.0 / 1.2)
        + 2.0 * (1.0 / 1.2 - 1.0 / 1.5)
        + 4.0 * (1.0 / 1.5 - 1.0 / 1.6)
    )

    assert reward == pytest.approx(expected)


def test_purchase_skill_updates_owned_skill_state_and_rejects_repurchase(tmp_path: Path) -> None:
    market_manifest = write_skill_market_bundle(tmp_path)
    config = _config(tmp_path, skill_market_manifest=market_manifest)
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=config,
        skill_market=load_skill_market_catalog(market_manifest),
    )

    actions = env.available_actions()
    assert [item["skill_id"] for item in actions["purchase_skill"]] == ["protein-scout"]

    record = env.apply(AgentDecision(action="purchase_skill", skill_id="protein-scout", reasoning="unlock playbook"))
    state = env.get_state()

    assert record["action"] == "purchase_skill"
    assert record["workspace_relative_source_dir"] == "owned_skills/protein-scout/source"
    assert state["owned_skill_ids"] == ["protein-scout"]
    assert state["owned_skill_count"] == 1
    assert state["total_skill_purchase_price_paid"] == pytest.approx(120.0)
    assert env.available_actions()["purchase_skill"] == []
    assert env.validate_decision(
        AgentDecision(action="purchase_skill", skill_id="protein-scout", reasoning="buy again")
    ) == "Skill protein-scout 已购买"


def test_forced_initial_owned_skill_hides_market_without_purchase_cost(tmp_path: Path) -> None:
    market_manifest = write_skill_market_bundle(tmp_path)
    config = _config(
        tmp_path,
        skill_market_manifest=market_manifest,
        skill_market_enabled=False,
        initial_owned_skill_ids=("protein-scout",),
    )
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=config,
        skill_market=load_skill_market_catalog(market_manifest),
    )

    state = env.get_state()
    summary = env.summary()
    actions = env.available_actions()

    assert state["skill_market_enabled"] is False
    assert state["skill_market_size"] == 0
    assert state["skill_catalog_size"] == 1
    assert state["initial_owned_skill_ids"] == ["protein-scout"]
    assert state["owned_skill_ids"] == ["protein-scout"]
    assert state["owned_skill_count"] == 1
    assert state["total_skill_purchase_price_paid"] == pytest.approx(0.0)
    assert summary["skill_market_enabled"] is False
    assert summary["skill_market_size"] == 0
    assert summary["skill_catalog_size"] == 1
    assert summary["initial_owned_skill_ids"] == ["protein-scout"]
    assert summary["owned_skill_ids"] == ["protein-scout"]
    assert summary["owned_skill_count"] == 1
    assert summary["total_skill_purchase_price_paid"] == pytest.approx(0.0)
    assert actions["purchase_skill"] == []
    assert env.validate_decision(
        AgentDecision(action="purchase_skill", skill_id="protein-scout", reasoning="buy")
    ) == "`purchase_skill` 当前未启用"


def test_available_actions_hide_actionable_entries_once_terminal(tmp_path: Path) -> None:
    env = TadACampaignEnvironment(
        variant="protein",
        seed_definitions=_seed_definitions(),
        prepared_rows=_prepared_rows(),
        config=_config(tmp_path),
    )

    env.apply(AgentDecision(action="stop", reasoning="done"))
    actions = env.available_actions()

    assert actions["prepare_seed"] == []
    assert actions["prepare_library"] == []
    assert actions["mine_library"] == []
    assert actions["confirm_hit"] == []
    assert actions["purchase_skill"] == []
    assert actions["stop"] == {"action": "stop"}
