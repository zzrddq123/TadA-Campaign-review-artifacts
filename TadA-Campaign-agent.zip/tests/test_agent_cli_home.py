from pathlib import Path

from TadACampaign.agent_cli_home import build_agent_cli_stage_paths, stage_agent_cli_home, stage_claude_home, stage_opencode_home


def test_stage_claude_home_copies_directory_and_state_file(tmp_path: Path) -> None:
    source_dir = tmp_path / "source" / ".claude"
    source_dir.mkdir(parents=True, exist_ok=True)
    (source_dir / "settings.json").write_text('{"model":"haiku"}\n', encoding="utf-8")
    (source_dir / "agents" / "demo").mkdir(parents=True, exist_ok=True)
    (source_dir / "agents" / "demo" / "agent.md").write_text("demo", encoding="utf-8")
    state_file = tmp_path / "source" / ".claude.json"
    state_file.write_text('{"oauth":{"token":"secret"}}\n', encoding="utf-8")

    paths = stage_claude_home(
        source_dir=source_dir,
        state_file=state_file,
        target_root=tmp_path / "target",
        clean_target=True,
    )

    assert paths.claude_home == build_agent_cli_stage_paths(tmp_path / "target").claude_home
    assert (paths.claude_home / "settings.json").read_text(encoding="utf-8") == '{"model":"haiku"}\n'
    assert (paths.claude_home / "agents" / "demo" / "agent.md").read_text(encoding="utf-8") == "demo"
    assert paths.claude_state_file.read_text(encoding="utf-8") == '{"oauth":{"token":"secret"}}\n'


def test_stage_opencode_home_copies_config_auth_and_project_only(tmp_path: Path) -> None:
    config_dir = tmp_path / "source" / ".config" / "opencode"
    data_dir = tmp_path / "source" / ".local" / "share" / "opencode"
    (config_dir / "agents").mkdir(parents=True, exist_ok=True)
    (config_dir / "plugin").mkdir(parents=True, exist_ok=True)
    (config_dir / "opencode.json").write_text('{"model":"qwen/qwen3coder"}\n', encoding="utf-8")
    (config_dir / "agents" / "demo.md").write_text("demo", encoding="utf-8")
    (config_dir / "plugin" / "host-only.js").write_text("throw new Error('host-only')\n", encoding="utf-8")
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "auth.json").write_text('{"token":"secret"}\n', encoding="utf-8")
    (data_dir / "project" / "p1").mkdir(parents=True, exist_ok=True)
    (data_dir / "project" / "p1" / "session.json").write_text("{}", encoding="utf-8")
    (data_dir / "log").mkdir(parents=True, exist_ok=True)
    (data_dir / "log" / "debug.log").write_text("noise", encoding="utf-8")

    paths = stage_opencode_home(
        config_dir=config_dir,
        data_dir=data_dir,
        target_root=tmp_path / "target",
        clean_target=True,
    )

    assert (paths.opencode_config_dir / "opencode.json").read_text(encoding="utf-8") == '{"model":"qwen/qwen3coder"}\n'
    assert (paths.opencode_config_dir / "agents" / "demo.md").read_text(encoding="utf-8") == "demo"
    assert not (paths.opencode_config_dir / "plugin").exists()
    assert (paths.opencode_data_dir / "auth.json").read_text(encoding="utf-8") == '{"token":"secret"}\n'
    assert (paths.opencode_data_dir / "project" / "p1" / "session.json").read_text(encoding="utf-8") == "{}"
    assert not (paths.opencode_data_dir / "log").exists()


def test_stage_agent_cli_home_dispatches_claude_and_opencode(tmp_path: Path) -> None:
    claude_root = tmp_path / "claude"
    (claude_root / ".claude").mkdir(parents=True, exist_ok=True)
    (claude_root / ".claude" / "settings.json").write_text("{}", encoding="utf-8")
    (claude_root / ".claude.json").write_text("{}", encoding="utf-8")

    opencode_root = tmp_path / "opencode"
    (opencode_root / ".config" / "opencode").mkdir(parents=True, exist_ok=True)
    (opencode_root / ".config" / "opencode" / "opencode.json").write_text("{}", encoding="utf-8")
    (opencode_root / ".local" / "share" / "opencode").mkdir(parents=True, exist_ok=True)

    stage_agent_cli_home(
        backend="claude",
        target_root=tmp_path / "claude-target",
        claude_source_dir=claude_root / ".claude",
        claude_state_file=claude_root / ".claude.json",
        clean_target=True,
    )
    stage_agent_cli_home(
        backend="opencode",
        target_root=tmp_path / "opencode-target",
        opencode_config_dir=opencode_root / ".config" / "opencode",
        opencode_data_dir=opencode_root / ".local" / "share" / "opencode",
        clean_target=True,
    )

    assert (tmp_path / "claude-target" / ".claude" / "settings.json").is_file()
    assert (tmp_path / "opencode-target" / ".config" / "opencode" / "opencode.json").is_file()


def test_stage_agent_cli_home_accepts_policy_backend_as_noop(tmp_path: Path) -> None:
    paths = stage_agent_cli_home(backend="policy", target_root=tmp_path / "policy-target", clean_target=True)

    assert paths.target_root == (tmp_path / "policy-target").resolve()
    assert paths.target_root.is_dir()
