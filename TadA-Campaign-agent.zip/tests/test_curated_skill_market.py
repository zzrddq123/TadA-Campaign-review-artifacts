import json
import tarfile
from pathlib import Path

import TadACampaign.curated_skill_market as curated
from tests.helpers import write_skill_market_bundle
from TadACampaign.curated_skill_market import CuratedSkillSpec, prepare_curated_skill_market
from TadACampaign.skill_market import load_skill_market_catalog, materialize_owned_skill


def test_prepare_curated_skill_market_copies_selected_sources(tmp_path, monkeypatch) -> None:
    source_root = tmp_path / "scout"
    source_dir = source_root / "repo-a" / "skills" / "skill-a"
    source_dir.mkdir(parents=True, exist_ok=True)
    (source_dir / "SKILL.md").write_text("# Skill A\n", encoding="utf-8")
    (source_dir / "notes.txt").write_text("offline notes\n", encoding="utf-8")

    monkeypatch.setattr(
        curated,
        "LAUNCH_SKILL_SPECS",
        (
            CuratedSkillSpec(
                skill_id="skill-a",
                display_name="Skill A",
                summary="Summary A",
                description="Description A",
                tags=("alpha",),
                source_repo="demo/repo-a",
                source_checkout_dir="repo-a",
                source_path="skills/skill-a",
            ),
        ),
    )

    manifest_path = prepare_curated_skill_market(source_root, tmp_path / "market")
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    audit_payload = json.loads((manifest_path.parent / "market_audit.json").read_text(encoding="utf-8"))

    assert manifest_path.is_file()
    assert (manifest_path.parent / "sources" / "skill-a" / "SKILL.md").is_file()
    assert (manifest_path.parent / "sources" / "skill-a" / "notes.txt").is_file()
    assert payload["skills"][0]["skill_id"] == "skill-a"
    assert payload["skills"][0]["price"] == curated.FIXED_SKILL_PRICE
    assert payload["skills"][0]["package_root"] == "sources/skill-a"
    assert audit_payload["skills"][0]["source_repo"] == "demo/repo-a"


def test_curated_skill_price_matches_exploratory_market_cost() -> None:
    assert curated.FIXED_SKILL_PRICE == 1000.0


def test_launch_market_includes_life_science_research_skills() -> None:
    skill_ids = {spec.skill_id for spec in curated.LAUNCH_SKILL_SPECS}

    assert curated.MARKET_ID == "TadACampaign-launch21"
    assert len(curated.LAUNCH_SKILL_SPECS) == 21
    assert {
        "lsr-research-router",
        "lsr-uniprot",
        "lsr-alphafold",
        "lsr-rcsb-pdb",
        "lsr-ncbi-blast",
    }.issubset(skill_ids)


def test_skill_market_snapshot_hides_source_provenance_from_agent_surface(tmp_path: Path) -> None:
    manifest_path = write_skill_market_bundle(tmp_path)
    catalog = load_skill_market_catalog(manifest_path)

    market_snapshot = catalog.market_snapshot(owned_skill_ids=set(), purchase_days=1.0, daily_burn_cost=2.0)
    owned_snapshot = catalog.owned_skills_snapshot(owned_skill_ids={"protein-scout"})

    card = market_snapshot["cards"][0]
    owned_item = owned_snapshot["skills"][0]

    assert "source_repo" not in card
    assert "source_path" not in card
    assert "source_repo" not in owned_item
    assert "source_path" not in owned_item


def test_materialize_owned_skill_falls_back_when_tar_extract_filter_is_unsupported(tmp_path, monkeypatch) -> None:
    manifest_path = write_skill_market_bundle(tmp_path)
    catalog = load_skill_market_catalog(manifest_path)
    index_item = catalog.owned_skills_snapshot(owned_skill_ids={"protein-scout"})["skills"][0]
    bundle_payload = catalog.owned_bundle_payload("protein-scout")
    skill_dir = tmp_path / "owned" / "protein-scout"

    original_extractall = tarfile.TarFile.extractall

    def extractall_without_filter_support(self, path=".", members=None, *, numeric_owner=False, filter=None):
        if filter is not None:
            raise TypeError("extractall() got an unexpected keyword argument 'filter'")
        return original_extractall(self, path=path, members=members, numeric_owner=numeric_owner)

    monkeypatch.setattr(tarfile.TarFile, "extractall", extractall_without_filter_support)

    materialize_owned_skill(skill_dir, bundle_payload=bundle_payload, index_item=index_item)

    assert (skill_dir / "skill.json").is_file()
    assert (skill_dir / "source" / "SKILL.md").read_text(encoding="utf-8").startswith("# Protein Scout")
