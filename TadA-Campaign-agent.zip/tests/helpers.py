import json
import re
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq


def write_minimal_prepared_bundle(prepared_root: Path) -> None:
    prepared_root.mkdir(parents=True, exist_ok=True)
    (prepared_root / "protein").mkdir(parents=True, exist_ok=True)
    rows = pa.table(
        {
            "sequence": pa.array(["AAAAAA", "AABBAA"], type=pa.string()),
            "value": pa.array([1.0, 1.3], type=pa.float64()),
            "source_split": pa.array(["train", "train"], type=pa.string()),
            "raw_domain_ids": pa.array([[0], [0, 1]], type=pa.list_(pa.int16())),
            "round_ids": pa.array([["r1"], ["r1", "r2"]], type=pa.list_(pa.string())),
        }
    )
    pq.write_table(rows, prepared_root / "protein" / "merged.parquet")

    manifest = {
        "version": 3,
        "raw_source": "synthetic",
        "domain_mapping": {"0": "r1", "1": "r2"},
        "variants": {
            "protein": {
                "data_path": "protein/merged.parquet",
                "seed_mapping": {
                    "0": {"historical_round_id": "r1", "seed_id": "seed1", "library_id": "seed1_library1"},
                    "1": {"historical_round_id": "r2", "seed_id": "seed2", "library_id": "seed2_library1"},
                },
                "seeds": [
                    {
                        "seed_id": "seed1",
                        "start_sequence": "AAAAAA",
                        "parent_seed_candidates": [],
                        "parent_seed_id": None,
                        "parent_library_candidates": [],
                        "parent_library_id": None,
                        "parent_resolution_evidence": {"rule": "root_seed"},
                        "historical_round_ids": ["r1"],
                        "libraries": [
                            {
                                "library_id": "seed1_library1",
                                "seed_id": "seed1",
                                "historical_round_id": "r1",
                                "raw_domain_id": 0,
                                "start_sequence": "AAAAAA",
                                "interval_start_aa": 2,
                                "interval_end_aa": 4,
                                "unlock_child_seed_ids": ["seed2"],
                            }
                        ],
                    },
                    {
                        "seed_id": "seed2",
                        "start_sequence": "AABBAA",
                        "parent_seed_candidates": ["seed1"],
                        "parent_seed_id": "seed1",
                        "parent_library_candidates": ["seed1_library1"],
                        "parent_library_id": "seed1_library1",
                        "parent_resolution_evidence": {"rule": "single_parent"},
                        "historical_round_ids": ["r2"],
                        "libraries": [
                            {
                                "library_id": "seed2_library1",
                                "seed_id": "seed2",
                                "historical_round_id": "r2",
                                "raw_domain_id": 1,
                                "start_sequence": "AABBAA",
                                "interval_start_aa": 2,
                                "interval_end_aa": 4,
                                "unlock_child_seed_ids": [],
                            }
                        ],
                    },
                ],
            }
        },
    }
    (prepared_root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")


def write_experiment_config(
    config_path: Path,
    *,
    name: str,
    prepared_root: Path,
    output_root: Path,
    judge_server_url: str | None = None,
    max_experiment_days: float,
    backend: str = "codex",
    skill_market_manifest: Path | None = None,
    skill_market_enabled: bool | None = None,
    initial_owned_skill_ids: tuple[str, ...] = (),
    purchase_skill_days: float = 1.0,
) -> Path:
    judge_lines = ["[judge]"]
    market_line = f'skill_market_manifest = "{skill_market_manifest}"\n' if skill_market_manifest is not None else ""
    market_enabled_line = (
        f"skill_market_enabled = {'true' if skill_market_enabled else 'false'}\n"
        if skill_market_enabled is not None
        else ""
    )
    initial_owned_line = (
        "initial_owned_skill_ids = "
        + json.dumps(list(initial_owned_skill_ids), ensure_ascii=False)
        + "\n"
        if initial_owned_skill_ids
        else ""
    )
    if judge_server_url is not None:
        judge_lines.append(f'server_url = "{judge_server_url}"')
    judge_lines.append("request_timeout_seconds = 5")
    config_path.write_text(
        (
            f'name = "{name}"\n'
            f'prepared_root = "{prepared_root}"\n'
            'variant = "protein"\n'
            f'output_root = "{output_root}"\n'
            "seed = 5\n"
            "initial_cash = 1000.0\n"
            "base_asset_value = 1000.0\n"
            "baseline_activity = 1.0\n"
            "screening_noise_enabled = true\n"
            "screening_noise_sigma = 0.10\n"
            "screening_noise_clip = 0.20\n"
            "prepare_seed_cost = 25.0\n"
            "prepare_library_cost = 10.0\n"
            "daily_burn_cost = 1.0\n"
            "prepare_seed_days = 1.0\n"
            "prepare_library_days = 1.0\n"
            "confirm_hit_cost = 5.0\n"
            "confirm_hit_days = 1.0\n"
            f"purchase_skill_days = {purchase_skill_days}\n"
            'initial_visible_seeds = ["seed1"]\n'
            'initial_prepared_seeds = []\n'
            f"max_experiment_days = {max_experiment_days}\n"
            "agent_timeout_seconds = 30\n"
        )
        + market_line
        + market_enabled_line
        + initial_owned_line
        + (
            "\n"
            "[[reward_tiers]]\n"
            "min_activity = 1.0\n"
            'max_activity = "inf"\n'
            "multiplier = 1.0\n"
            "\n"
            "[[mine_batch_menu]]\n"
            "batch_size = 1\n"
            "cost = 10.0\n"
            "time_days = 1.0\n"
            "\n"
            "[[mine_batch_menu]]\n"
            "batch_size = 2\n"
            "cost = 11.0\n"
            "time_days = 1.0\n"
            "\n"
            "[agent]\n"
            f'backend = "{backend}"\n'
            "\n"
        )
        + "\n".join(judge_lines)
        + "\n",
        encoding="utf-8",
    )
    return config_path


def write_skill_market_bundle(root: Path) -> Path:
    market_root = root / "market"
    package_root = market_root / "sources" / "protein-scout"
    package_root.mkdir(parents=True, exist_ok=True)
    (package_root / "SKILL.md").write_text("# Protein Scout\n\nUse this skill to prioritize promising branches.\n", encoding="utf-8")
    (package_root / "notes.txt").write_text("upstream notes\n", encoding="utf-8")

    manifest_path = market_root / "skill_market.json"
    manifest_path.write_text(
        json.dumps(
            {
                "version": 1,
                "skills": [
                    {
                        "skill_id": "protein-scout",
                        "display_name": "Protein Scout",
                        "price": 120.0,
                        "summary": "Offline protein prioritization playbook.",
                        "description": "Limited preview only before purchase.",
                        "tags": ["protein", "screening"],
                        "source_repo": "demo/offline-market",
                        "source_path": "sources/protein-scout",
                        "package_root": "sources/protein-scout",
                    }
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return manifest_path


def inject_judge_server_url(config_path: Path, judge_server_url: str) -> None:
    text = config_path.read_text(encoding="utf-8")
    if re.search(r"(?m)^server_url\s*=.*$", text):
        text = re.sub(
            r"(?m)^server_url\s*=.*$",
            f'server_url = "{judge_server_url}"',
            text,
            count=1,
        )
    elif re.search(r"(?m)^\[judge\]\s*$", text):
        text = re.sub(
            r"(?m)^\[judge\]\s*$",
            f'[judge]\nserver_url = "{judge_server_url}"',
            text,
            count=1,
        )
    else:
        text = text.rstrip() + f'\n\n[judge]\nserver_url = "{judge_server_url}"\n'
    config_path.write_text(text if text.endswith("\n") else text + "\n", encoding="utf-8")
