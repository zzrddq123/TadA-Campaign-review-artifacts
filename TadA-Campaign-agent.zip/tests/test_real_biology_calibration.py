import json
from pathlib import Path

import pytest

from TadACampaign.data import load_prepared_table, load_seed_definitions
from TadACampaign.environment import TadACampaignEnvironment
from TadACampaign.models import AgentDecision
from TadACampaign.models import MineBatchOption
from TadACampaign.runner import load_experiment_config


PUBLIC_PRESETS = (
    Path("config/experiments/TadACampaign_v2_smoke.toml"),
    Path("config/experiments/TadACampaign_v2_formal.toml"),
)


def test_public_presets_use_real_biology_calibration() -> None:
    smoke = load_experiment_config(PUBLIC_PRESETS[0])
    formal = load_experiment_config(PUBLIC_PRESETS[1])

    for config in (smoke, formal):
        assert config.initial_cash == pytest.approx(100000.0)
        assert config.base_asset_value == pytest.approx(100000.0)
        assert [tier.multiplier for tier in config.reward_tiers] == pytest.approx([1.5, 2.4, 18.0, 30.0])
        assert config.prepare_seed_cost == pytest.approx(365.0)
        assert config.prepare_seed_days == pytest.approx(3.0)
        assert config.prepare_library_cost == pytest.approx(142.0)
        assert config.prepare_library_days == pytest.approx(2.0)
        assert config.confirm_hit_cost == pytest.approx(467.0)
        assert config.confirm_hit_days == pytest.approx(12.0)
        assert config.purchase_skill_days == pytest.approx(1.0)
        assert config.daily_burn_cost == pytest.approx(800.0)
        assert config.mine_batch_menu == (
            MineBatchOption(batch_size=780, cost=1200.0, time_days=9.0),
            MineBatchOption(batch_size=880, cost=1260.0, time_days=9.0),
            MineBatchOption(batch_size=1020, cost=1340.0, time_days=10.0),
            MineBatchOption(batch_size=1280, cost=1400.0, time_days=10.0),
        )

    assert smoke.max_experiment_days == pytest.approx(60.0)
    assert formal.max_experiment_days == pytest.approx(180.0)
    assert smoke.agent_timeout_seconds == 1800
    assert formal.agent_timeout_seconds == 3600


def test_public_presets_expose_real_biology_total_costs() -> None:
    config = load_experiment_config(PUBLIC_PRESETS[1])

    assert config.prepare_seed_cost + config.prepare_seed_days * config.daily_burn_cost == pytest.approx(2765.0)
    assert config.prepare_library_cost + config.prepare_library_days * config.daily_burn_cost == pytest.approx(1742.0)
    assert config.mine_batch_menu[0].cost + config.mine_batch_menu[0].time_days * config.daily_burn_cost == pytest.approx(8400.0)
    assert config.confirm_hit_cost + config.confirm_hit_days * config.daily_burn_cost == pytest.approx(10067.0)
    assert 1000.0 + config.purchase_skill_days * config.daily_burn_cost == pytest.approx(1800.0)


def test_public_presets_only_differ_by_run_length_and_timeout() -> None:
    smoke_payload = _config_payload(PUBLIC_PRESETS[0])
    formal_payload = _config_payload(PUBLIC_PRESETS[1])

    smoke_payload.pop("name")
    formal_payload.pop("name")
    smoke_payload.pop("max_experiment_days")
    formal_payload.pop("max_experiment_days")
    smoke_payload.pop("agent_timeout_seconds")
    formal_payload.pop("agent_timeout_seconds")

    assert smoke_payload == formal_payload


def test_biology_context_is_repo_tracked_optional_context() -> None:
    text = Path("docs/biology_context.md").read_text(encoding="utf-8")
    playbook = Path("docs/agent_playbook.md").read_text(encoding="utf-8")
    output_reference = Path("docs/output_reference.md").read_text(encoding="utf-8")

    assert "biology_context.md" in playbook
    assert "biology_context.md" in output_reference
    assert "skill_analysis/" in playbook
    assert "skill_analysis/" in output_reference
    assert "tool use mandatory" in text
    assert "authoritative game state remains" in text
    assert "`mine_library` is a discovery screen" in text
    assert "`confirm_hit` is a per-candidate orthogonal validation step" in text
    assert "$365" in text
    assert "780" in text and "1280" in text


def test_repo_facing_cost_context_uses_dollar_or_unitless_scale() -> None:
    paths = [
        *Path("docs").glob("*.md"),
        *Path("config/experiments").glob("*.toml"),
    ]
    combined = "\n".join(path.read_text(encoding="utf-8") for path in paths if path.is_file())

    assert "$365" in combined
    assert "initial_cash = 100000.0" in combined
    assert "base_asset_value = 100000.0" in combined
    assert "multiplier = 30.0" in combined
    assert "daily_burn_cost = 800.0" in combined
    assert "prepare_seed_cost = 365.0" in combined
    assert "confirm_hit_cost = 467.0" in combined


def test_fresh_prepared_data_keeps_unlock_libraries_screenable() -> None:
    config = load_experiment_config(PUBLIC_PRESETS[1])
    if not config.prepared_root.is_dir():
        pytest.skip("ignored prepared data is not available in this checkout")

    seed_definitions = load_seed_definitions(config.prepared_root, config.variant)
    table = load_prepared_table(config.prepared_root, config.variant)
    activity_column = "activity" if "activity" in table.column_names else "value"
    prepared_rows = [
        {"sequence": sequence, "activity": float(activity), "round_ids": list(round_ids)}
        for sequence, activity, round_ids in zip(
            table["sequence"].to_pylist(),
            table[activity_column].to_pylist(),
            table["round_ids"].to_pylist(),
            strict=True,
        )
    ]
    env = TadACampaignEnvironment(
        variant=config.variant,
        seed_definitions=seed_definitions,
        prepared_rows=prepared_rows,
        config=config,
    )
    min_batch_size = min(option.batch_size for option in config.mine_batch_menu)

    unlock_counts = {
        library.library_id: env._known_library_counts(library.library_id)[0]
        for seed in seed_definitions
        for library in seed.libraries
        if library.unlock_child_seed_ids
    }

    assert unlock_counts == {
        "seed1_library3": 9439,
        "seed2_library4": 7032,
        "seed4_library1": 139374,
        "seed5_library7": 149617,
        "seed6_library2": 149660,
    }
    assert all(count >= min_batch_size for count in unlock_counts.values())

    env.apply(AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
    env.apply(
        AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library3", reasoning="open branch")
    )
    mine_actions_by_library = {
        item["library_id"]: item
        for item in env.available_actions()["mine_library"]
    }

    assert "seed1_library3" in mine_actions_by_library
    assert mine_actions_by_library["seed1_library3"]["batch_options"][0]["batch_size"] == 780
    assert env.visible_seed_ids == {"seed1", "seed2", "seed3"}


def _config_payload(path: Path) -> dict[str, object]:
    import tomllib

    return tomllib.loads(path.read_text(encoding="utf-8"))
