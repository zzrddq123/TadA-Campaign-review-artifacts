import inspect
import random
from dataclasses import replace
from pathlib import Path

import pytest

from tests.test_backends import _config
from TadACampaign.policies import POLICY_NAMES, make_policy_memory, select_action


def _observation() -> dict:
    return {
        "state": {
            "current_cash": 1000.0,
            "remaining_days": 100.0,
            "confirmed_best_activity": 1.0,
            "total_cost_paid": 0.0,
            "total_reward_earned": 0.0,
            "seeds": [
                {
                    "seed_id": "alpha",
                    "seed_status": "prepared",
                    "libraries": [
                        {"library_id": "lib_a", "library_status": "prepared"},
                        {"library_id": "lib_b", "library_status": "locked"},
                    ],
                },
                {"seed_id": "beta", "seed_status": "visible", "libraries": [{"library_id": "lib_c", "library_status": "locked"}]},
            ],
        },
        "history": {"recent_actions": [], "recent_screen_records": [], "recent_rejections": []},
        "available_actions": {
            "prepare_seed": [
                {"action": "prepare_seed", "seed_id": "alpha", "total_cost": 10.0},
                {"action": "prepare_seed", "seed_id": "beta", "total_cost": 10.0},
            ],
            "prepare_library": [
                {
                    "action": "prepare_library",
                    "seed_id": "alpha",
                    "library_id": "lib_a",
                    "interval_length_aa": 30,
                    "total_cost": 10.0,
                }
            ],
            "mine_library": [
                {
                    "action": "mine_library",
                    "seed_id": "alpha",
                    "library_id": "lib_a",
                    "screenable_sequence_count": 100,
                    "screened_sequence_count": 0,
                    "remaining_screenable_sequence_count": 100,
                    "batch_options": [
                        {
                            "batch_size": 1,
                            "total_cost": 10.0,
                            "leaves_confirm_capacity": True,
                        }
                    ],
                }
            ],
            "confirm_hit": [
                {
                    "action": "confirm_hit",
                    "screen_record_id": 3,
                    "observed_activity": 2.0,
                    "total_cost": 7.0,
                }
            ],
            "purchase_skill": [],
            "stop": {"action": "stop"},
        },
    }


@pytest.mark.parametrize(
    "policy_name",
    [
        "stop_now",
        "blind_random_legal",
        "budgeted_static_ranker",
        "scout_confirm_stop",
        "upside_greedy_explorer",
        "empirical_ev_planner",
    ],
)
def test_policy_selects_structured_decision(tmp_path: Path, policy_name: str) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    decision = select_action(
        policy_name,
        config=config,
        observation=_observation(),
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action in {"stop", "prepare_seed", "prepare_library", "mine_library", "confirm_hit"}
    assert decision.reasoning


@pytest.mark.parametrize("policy_name", sorted(POLICY_NAMES))
def test_policy_names_are_selectable(tmp_path: Path, policy_name: str) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    decision = select_action(
        policy_name,
        config=config,
        observation=_observation(),
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action in {"stop", "prepare_seed", "prepare_library", "mine_library", "confirm_hit"}


@pytest.mark.parametrize(
    "policy_name",
    ["budgeted_static_ranker", "scout_confirm_stop", "upside_greedy_explorer", "empirical_ev_planner"],
)
def test_upgraded_policies_stop_when_nonconfirm_action_would_break_confirm_runway(
    tmp_path: Path, policy_name: str
) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    observation = _observation()
    observation["available_actions"]["confirm_hit"] = []
    observation["state"]["current_cash"] = 16.0
    observation["state"]["remaining_days"] = 2.0

    decision = select_action(
        policy_name,
        config=config,
        observation=observation,
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action == "stop"
    assert "reserve" in decision.reasoning or "probe floor" in decision.reasoning or "stop" in decision.reasoning


@pytest.mark.parametrize(
    "policy_name",
    ["budgeted_static_ranker", "scout_confirm_stop", "upside_greedy_explorer", "empirical_ev_planner"],
)
def test_upgraded_policies_prioritize_positive_ev_confirm(tmp_path: Path, policy_name: str) -> None:
    config = replace(_config(tmp_path), agent_backend="policy", agent_policy=policy_name)
    observation = _observation()

    decision = select_action(
        policy_name,
        config=config,
        observation=observation,
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action == "confirm_hit"
    assert decision.screen_record_id == 3


def test_upside_greedy_explorer_prefers_largest_reserve_preserving_batch(tmp_path: Path) -> None:
    config = replace(
        _config(tmp_path),
        agent_backend="policy",
        agent_policy="upside_greedy_explorer",
        initial_cash=1000.0,
        confirm_hit_cost=5.0,
        confirm_hit_days=1.0,
        daily_burn_cost=2.0,
    )
    observation = _observation()
    observation["available_actions"]["confirm_hit"] = []
    observation["available_actions"]["mine_library"][0]["batch_options"] = [
        {"batch_size": 1, "total_cost": 10.0, "leaves_confirm_capacity": True},
        {"batch_size": 8, "total_cost": 100.0, "leaves_confirm_capacity": True},
        {"batch_size": 16, "total_cost": 1000.0, "leaves_confirm_capacity": False},
    ]

    decision = select_action(
        "upside_greedy_explorer",
        config=config,
        observation=observation,
        memory=make_policy_memory(),
        rng=random.Random(1),
    )

    assert decision.action == "mine_library"
    assert decision.batch_size == 8


def test_removed_fig2_aliases_are_rejected(tmp_path: Path) -> None:
    config = replace(_config(tmp_path), agent_backend="policy")

    for policy_name in ("visible_feature_ranker", "myopic_confirm", "frontier_probe_then_exploit"):
        with pytest.raises(ValueError, match="Unknown policy"):
            select_action(
                policy_name,
                config=config,
                observation=_observation(),
                memory=make_policy_memory(),
                rng=random.Random(1),
            )


def test_policy_module_does_not_import_hidden_benchmark_surfaces() -> None:
    import TadACampaign.policies as policies

    source = inspect.getsource(policies)
    assert "TadACampaign.specs" not in source
    assert "TadACampaign.data" not in source
    assert "TadACampaign.environment" not in source
    assert "prepared/manifest" not in source
