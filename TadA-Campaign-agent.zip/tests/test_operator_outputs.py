import argparse
import csv
import json
from pathlib import Path

from scripts.write_TadACampaign_operator_outputs import write_operator_outputs


def test_operator_outputs_include_backend_failure_statistics(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    results_dir = run_dir / "results"
    results_dir.mkdir(parents=True)
    (run_dir / "config.toml").write_text('seed = 5\nbaseline_activity = 1.0\n', encoding="utf-8")
    (results_dir / "summary.json").write_text(
        json.dumps(
            {
                "cash_final": 49751.0,
                "day_final": 54.0,
                "action_count": 1,
                "stop_code": "backend_error",
                "stop_reason": "backend_error: OpenCode output is missing a final JSON result",
                "confirmed_best_activity": 1.0,
                "rejected_action_count": 0,
                "agent_attempt_count": 2,
                "agent_resume_count": 0,
                "agent_handoff_count": 1,
                "backend_force_stopped": True,
                "backend_failure_count": 2,
                "backend_retryable_failure_count": 1,
                "backend_terminal_failure_count": 1,
                "backend_recovery_attempt_count": 1,
                "backend_missing_final_json_handoff_count": 1,
                "backend_recovery_success": False,
                "backend_final_failure_classification": "missing_final_json_handoff_required",
                "backend_final_error": "missing_final_json_handoff_limit_reached",
                "backend_failure_classifications": ["missing_final_json_handoff_required"],
                "backend_failure_classification_counts": {"missing_final_json_handoff_required": 2},
            }
        )
        + "\n",
        encoding="utf-8",
    )
    (results_dir / "action_log.jsonl").write_text(
        json.dumps(
            {
                "action": "prepare_seed",
                "seed_id": "seed1",
                "cash_after": 990.0,
                "elapsed_day_after": 1.0,
                "confirmed_best_before": 1.0,
                "confirmed_best_after": 1.0,
            }
        )
        + "\n",
        encoding="utf-8",
    )
    args = argparse.Namespace(
        run_dir=run_dir,
        figure_id="Fig. 4",
        experiment_theme="Agent effect on decision behavior",
        setting_id="fig4_agent_opencode_qwen3coder",
        setting_name="OpenCode-Qwen3Coder",
        agent_name="OpenCode-Qwen3Coder",
        initial_cash=100000.0,
        independent_variable="agent_backend_and_model",
        control_variables="test controls",
        purpose="test purpose",
        output_root="runs/paper_main/fig4_agent/opencode_qwen3coder",
        skill_condition="no_skill",
        market_condition="no_market",
        prompt_append_mode="unset",
        manifest_path="unset",
    )

    summary_path = write_operator_outputs(args)

    summary_text = summary_path.read_text(encoding="utf-8")
    assert "stop_code: `backend_error`" in summary_text
    assert "backend force stopped: `True`" in summary_text
    assert "backend failures/retryable/terminal: `2` / `1` / `1`" in summary_text
    assert "backend recovery attempts: `1`" in summary_text
    assert "backend failure classifications: `missing_final_json_handoff_required=2`" in summary_text

    with (results_dir / "operator_run_summary.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert rows[0]["stop_code"] == "backend_error"
    assert rows[0]["backend_force_stopped"] == "True"
    assert rows[0]["backend_failure_count"] == "2"
    assert rows[0]["backend_retryable_failure_count"] == "1"
    assert rows[0]["backend_terminal_failure_count"] == "1"
    assert rows[0]["backend_recovery_attempt_count"] == "1"
    assert rows[0]["backend_missing_final_json_handoff_count"] == "1"
    assert rows[0]["backend_failure_classification_counts"] == '{"missing_final_json_handoff_required": 2}'
