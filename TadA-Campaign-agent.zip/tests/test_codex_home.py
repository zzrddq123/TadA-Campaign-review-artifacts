from pathlib import Path

from TadACampaign.codex_home import (
    apply_secure_codex_policy,
    drop_mcp_server_sections,
    load_codex_api_settings,
    resolve_codex_home,
    stage_codex_home,
)


def test_drop_mcp_server_sections() -> None:
    original = """
[model]
name = "x"

[mcp_servers.linear]
url = "mcp-endpoint"

[notice]
hide = true
"""
    filtered = drop_mcp_server_sections(original)
    assert "mcp_servers.linear" not in filtered
    assert "[notice]" in filtered


def test_apply_secure_codex_policy_enforces_single_secure_profile() -> None:
    rendered = apply_secure_codex_policy(
        '[features]\nskills = true\nplugins = true\n',
        skills_enabled=False,
        drop_mcp_servers=False,
    )

    assert 'skills = false' in rendered
    assert 'plugins = false' in rendered
    assert 'approval_policy = "never"' in rendered
    assert 'sandbox_mode = "danger-full-access"' in rendered
    assert 'web_search = "disabled"' in rendered
    assert 'default_permissions = ' not in rendered
    assert "[permissions.workspace.network]" not in rendered


def test_stage_codex_home_copies_minimal_files(tmp_path: Path) -> None:
    source = tmp_path / "source"
    target = tmp_path / "target"
    (source / "skills" / "demo").mkdir(parents=True, exist_ok=True)
    (source / "config.toml").write_text(
        (
            'web_search = "live"\n'
            'default_permissions = "danger-full-access"\n'
            'model_catalog_json = "./model-catalog.json"\n'
            'notify = ["/missing/node", "/missing/notify.cjs"]\n'
            "js_repl_node_module_dirs = [\n"
            '  "/tmp/node_modules",\n'
            "]\n"
            "\n"
            "[mcp_servers.linear]\n"
            "url = 'x'\n"
            "\n"
            "[features]\n"
            "skills = true\n"
            "plugins = true\n"
        ),
        encoding="utf-8",
    )
    (source / "auth.json").write_text("{}", encoding="utf-8")
    (source / "skills" / "demo" / "SKILL.md").write_text("demo", encoding="utf-8")
    agents = tmp_path / "AGENTS.md"
    agents.write_text("global agents\n", encoding="utf-8")

    stage_codex_home(
        source_dir=source,
        target_dir=target,
        include_credentials=True,
        skills_mode="demo",
        mcp_server_filter_mode="drop_all",
        global_agents_path=agents,
        clean_target=True,
    )

    assert (target / "config.toml").is_file()
    assert (target / "auth.json").is_file()
    assert (target / "AGENTS.md").read_text(encoding="utf-8") == "global agents\n"
    assert (target / "skills" / "demo" / "SKILL.md").is_file()
    config_text = (target / "config.toml").read_text(encoding="utf-8")
    assert "mcp_servers" not in config_text
    assert 'web_search = "disabled"' in config_text
    assert 'approval_policy = "never"' in config_text
    assert 'sandbox_mode = "danger-full-access"' in config_text
    assert 'default_permissions = ' not in config_text
    assert "model_catalog_json" not in config_text
    assert "notify" not in config_text
    assert "js_repl_node_module_dirs" not in config_text
    assert 'plugins = false' in config_text
    assert "[permissions.workspace.filesystem]" not in config_text


def test_load_codex_api_settings_reads_base_url_and_api_key(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        (
            'model_provider = "sub"\n'
            '\n'
            '[model_providers.sub]\n'
            'base_url = "provider-config"\n'
            "requires_openai_auth = true\n"
        ),
        encoding="utf-8",
    )
    (codex_home / "auth.json").write_text('{"OPENAI_API_KEY":"secret"}\n', encoding="utf-8")

    assert resolve_codex_home(codex_home) == codex_home.resolve()
    base_url, api_key = load_codex_api_settings(codex_home)
    assert base_url == "provider-config"
    assert api_key == "secret"
