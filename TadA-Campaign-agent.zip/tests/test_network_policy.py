from pathlib import Path

import pytest

from TadACampaign.codex_home import stage_codex_home
from TadACampaign.judge.client import JudgeHttpClient
from TadACampaign.network_policy import (
    NetworkEndpoint,
    merge_no_proxy,
    resolve_backend_egress_allowlist,
    resolve_backend_proxy_bypass_hosts,
)


@pytest.mark.parametrize(
    "stored_auth",
    (
        '{"auth_mode":"apikey","OPENAI_API_KEY":"test-key"}',
        '{"OPENAI_API_KEY":"test-key"}',
    ),
)
def test_resolve_backend_egress_allowlist_uses_staged_openai_api_key(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, stored_auth: str
) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("CODEX_BASE_URL", raising=False)
    source = tmp_path / "source"
    source.mkdir()
    (source / "auth.json").write_text(stored_auth, encoding="utf-8")
    codex_home = tmp_path / "codex-home"
    stage_codex_home(
        source_dir=source,
        target_dir=codex_home,
        include_credentials=True,
        skills_mode="none",
    )

    endpoints = resolve_backend_egress_allowlist(
        "codex",
        codex_home=codex_home,
        env={},
        extra_urls=("http://host.docker.internal:36465",),
    )

    assert endpoints == (
        NetworkEndpoint(host="api.openai.com", port=443),
        NetworkEndpoint(host="host.docker.internal", port=36465),
    )


@pytest.mark.parametrize(
    "stored_auth",
    (None, '{"auth_mode":"chatgpt","tokens":{}}'),
)
def test_resolve_backend_egress_allowlist_requires_file_backed_key_for_default_provider(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, stored_auth: str | None
) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-host-only-key")
    monkeypatch.delenv("CODEX_BASE_URL", raising=False)
    if stored_auth is not None:
        (tmp_path / "auth.json").write_text(stored_auth, encoding="utf-8")

    with pytest.raises(ValueError, match="file-backed API-key login"):
        resolve_backend_egress_allowlist("codex", codex_home=tmp_path, env={})


def test_resolve_backend_egress_allowlist_uses_openai_base_url_override(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("CODEX_BASE_URL", raising=False)
    (tmp_path / "config.toml").write_text(
        'openai_base_url = "https://api.example.test/v1"\n',
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist("codex", codex_home=tmp_path, env={})

    assert endpoints == (NetworkEndpoint(host="api.example.test", port=443),)


def test_resolve_backend_egress_allowlist_prefers_proxy_and_rewrites_localhost(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        '[model_providers.openai]\nbase_url = "provider-config"\n',
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist(
        "codex",
        codex_home=codex_home,
        env={"HTTPS_PROXY": "http://localhost:7890"},
    )

    assert endpoints == (
        NetworkEndpoint(host="host.docker.internal", port=7890),
        NetworkEndpoint(host="provider-config", port=443),
    )


def test_resolve_backend_egress_allowlist_keeps_judge_endpoint_when_proxy_is_present(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        '[model_providers.openai]\nbase_url = "provider-config"\n',
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist(
        "codex",
        codex_home=codex_home,
        env={"HTTPS_PROXY": "http://localhost:7890"},
        extra_urls=("http://host.docker.internal:36465",),
    )

    assert endpoints == (
        NetworkEndpoint(host="host.docker.internal", port=7890),
        NetworkEndpoint(host="provider-config", port=443),
        NetworkEndpoint(host="host.docker.internal", port=36465),
    )


def test_resolve_backend_egress_allowlist_uses_codex_provider_when_no_proxy(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        (
            'model_provider = "sub"\n'
            '\n'
            '[model_providers.sub]\n'
            'base_url = "http://localhost:5205/v1"\n'
        ),
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist("codex", codex_home=codex_home, env={})

    assert endpoints == (NetworkEndpoint(host="host.docker.internal", port=5205),)


def test_resolve_backend_proxy_bypass_hosts_skips_public_provider(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        '[model_providers.openai]\nbase_url = "provider-config"\n',
        encoding="utf-8",
    )

    hosts = resolve_backend_proxy_bypass_hosts("codex", codex_home=codex_home)

    assert hosts == ()


def test_resolve_backend_egress_allowlist_adds_judge_endpoint_without_proxy(tmp_path: Path) -> None:
    codex_home = tmp_path / "codex-home"
    codex_home.mkdir(parents=True, exist_ok=True)
    (codex_home / "config.toml").write_text(
        (
            'model_provider = "sub"\n'
            '\n'
            '[model_providers.sub]\n'
            'base_url = "http://localhost:5205/v1"\n'
        ),
        encoding="utf-8",
    )

    endpoints = resolve_backend_egress_allowlist(
        "codex",
        codex_home=codex_home,
        env={},
        extra_urls=("http://host.docker.internal:36465",),
    )

    assert endpoints == (
        NetworkEndpoint(host="host.docker.internal", port=5205),
        NetworkEndpoint(host="host.docker.internal", port=36465),
    )


def test_merge_no_proxy_adds_host_docker_internal_without_duplicates() -> None:
    rendered = merge_no_proxy("127.0.0.1,localhost", "localhost", "host.docker.internal")
    assert rendered == "127.0.0.1,localhost,host.docker.internal"


def test_judge_client_bypasses_proxy_for_host_docker_internal(monkeypatch) -> None:
    client = JudgeHttpClient("http://host.docker.internal:8080", timeout_seconds=5, session_token="token")
    observed: dict[str, object] = {"build_opener_called": False, "urlopen_called": False}

    class FakeOpener:
        def open(self, request, timeout=None):
            observed["build_opener_called"] = True
            observed["request_url"] = request.full_url
            observed["timeout"] = timeout
            raise RuntimeError("stop")

    monkeypatch.setattr("urllib.request.build_opener", lambda *args: FakeOpener())
    monkeypatch.setattr(
        "urllib.request.urlopen",
        lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("unexpected direct urlopen")),
    )

    try:
        client.healthcheck()
    except RuntimeError as exc:
        assert str(exc) == "stop"

    assert observed["build_opener_called"] is True
    assert observed["request_url"] == "http://host.docker.internal:8080/healthz"
