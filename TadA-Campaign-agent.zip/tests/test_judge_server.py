import json
import os
import shutil
import threading
from contextlib import contextmanager
from pathlib import Path

import pytest

from tests.helpers import inject_judge_server_url, write_experiment_config, write_minimal_prepared_bundle, write_skill_market_bundle
from TadACampaign.judge import JudgeHttpClient, create_judge_http_server
from TadACampaign.models import AgentDecision
from TadACampaign.runner import load_experiment_config, run_agent_step, run_experiment

TEST_ADMIN_TOKEN = "test-admin-token"


def _write_server_config(tmp_path: Path, prepared_root: Path) -> Path:
    return write_experiment_config(
        tmp_path / "experiment_server.toml",
        name="judge_server_test",
        prepared_root=prepared_root,
        output_root=tmp_path / "runs",
        max_experiment_days=10.0,
    )


@contextmanager
def _started_server(config_path: Path, audit_root: Path):
    config = load_experiment_config(config_path)
    previous_admin_token = os.environ.get("TADACAMPAIGN_JUDGE_ADMIN_TOKEN")
    os.environ["TADACAMPAIGN_JUDGE_ADMIN_TOKEN"] = TEST_ADMIN_TOKEN
    server = create_judge_http_server(
        config,
        host="127.0.0.1",
        port=0,
        audit_root=audit_root,
        admin_token=TEST_ADMIN_TOKEN,
    )
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        base_url = f"http://127.0.0.1:{server.server_port}"
        inject_judge_server_url(config_path, base_url)
        yield base_url
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()
        if previous_admin_token is None:
            os.environ.pop("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", None)
        else:
            os.environ["TADACAMPAIGN_JUDGE_ADMIN_TOKEN"] = previous_admin_token


def test_authoritative_judge_rejects_illegal_action_and_records_audit(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    audit_root = tmp_path / "audit"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_server_config(tmp_path, prepared_root)

    with _started_server(config_path, audit_root) as base_url:
        admin_client = JudgeHttpClient(base_url, timeout_seconds=5, admin_token=TEST_ADMIN_TOKEN)
        created = admin_client.create_session(run_name="judge-audit")
        session_id = str(created["session_id"])
        session_client = JudgeHttpClient(
            base_url,
            timeout_seconds=5,
            session_token=str(created["session_token"]),
        )

        result = session_client.submit_action(
            session_id,
            AgentDecision(action="mine_library", seed_id="seed2", library_id="seed2_library1", batch_size=1, reasoning="illegal"),
        )
        exported = admin_client.export_session(session_id)
        audit_text = admin_client.fetch_audit(session_id)

    assert result["accepted"] is False
    assert result["rejection_code"] == "seed_not_visible"
    assert str(result["rejection_reason"]).startswith("不能在不可见的 seed")
    assert created["seed_manifest"][0]["start_sequence"] == "AAAAAA"
    assert exported["summary"]["request_count"] == 1
    assert exported["seed_manifest"][0]["start_sequence"] == "AAAAAA"
    assert len(exported["rejection_history"]) == 1
    assert exported["rejection_history"][0]["rejection_code"] == "seed_not_visible"
    assert '"event": "action.rejected"' in audit_text
    assert '"rejection_code": "seed_not_visible"' in audit_text
    assert '"request_received_at":' in audit_text
    assert '"response_sent_at":' in audit_text
    assert '"duration_seconds":' in audit_text
    assert "不能在不可见的 seed seed2 上执行 `mine_library`" in audit_text


def test_authoritative_judge_initial_observation_exposes_prepare_seed_path(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    audit_root = tmp_path / "audit"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_server_config(tmp_path, prepared_root)

    with _started_server(config_path, audit_root) as base_url:
        admin_client = JudgeHttpClient(base_url, timeout_seconds=5, admin_token=TEST_ADMIN_TOKEN)
        created = admin_client.create_session(run_name="judge-bootstrap")

    state = created["observation"]["state"]
    actions = created["observation"]["available_actions"]

    assert state["visible_seed_ids"] == ["seed1"]
    assert state["prepared_seed_ids"] == []
    assert [item["seed_id"] for item in actions["prepare_seed"]] == ["seed1"]
    assert actions["prepare_library"] == []
    assert actions["mine_library"] == []


def test_authoritative_judge_serves_purchased_skill_bundle(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    audit_root = tmp_path / "audit"
    write_minimal_prepared_bundle(prepared_root)
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = write_experiment_config(
        tmp_path / "experiment_server.toml",
        name="judge_server_skill_test",
        prepared_root=prepared_root,
        output_root=tmp_path / "runs",
        max_experiment_days=10.0,
        skill_market_manifest=market_manifest,
    )

    with _started_server(config_path, audit_root) as base_url:
        admin_client = JudgeHttpClient(base_url, timeout_seconds=5, admin_token=TEST_ADMIN_TOKEN)
        created = admin_client.create_session(run_name="judge-skill")
        session_id = str(created["session_id"])
        session_client = JudgeHttpClient(
            base_url,
            timeout_seconds=5,
            session_token=str(created["session_token"]),
        )
        purchase = session_client.submit_action(
            session_id,
            AgentDecision(action="purchase_skill", skill_id="protein-scout", reasoning="unlock"),
        )
        bundle = session_client.fetch_owned_skill_bundle(session_id, "protein-scout")

    assert purchase["accepted"] is True
    assert bundle["skill_id"] == "protein-scout"
    assert bundle["bundle_sha256"]
    assert bundle["archive_base64"]


def test_authoritative_judge_initial_observation_exposes_forced_skill_without_market(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    audit_root = tmp_path / "audit"
    write_minimal_prepared_bundle(prepared_root)
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = write_experiment_config(
        tmp_path / "experiment_server.toml",
        name="judge_server_forced_skill_test",
        prepared_root=prepared_root,
        output_root=tmp_path / "runs",
        max_experiment_days=10.0,
        skill_market_manifest=market_manifest,
        skill_market_enabled=False,
        initial_owned_skill_ids=("protein-scout",),
    )

    with _started_server(config_path, audit_root) as base_url:
        admin_client = JudgeHttpClient(base_url, timeout_seconds=5, admin_token=TEST_ADMIN_TOKEN)
        created = admin_client.create_session(run_name="judge-forced-skill")

    state = created["observation"]["state"]
    actions = created["observation"]["available_actions"]
    skill_market = created["observation"]["skill_market"]
    owned_index = created["observation"]["owned_skills_index"]

    assert state["skill_market_enabled"] is False
    assert state["skill_market_size"] == 0
    assert state["skill_catalog_size"] == 1
    assert state["initial_owned_skill_ids"] == ["protein-scout"]
    assert state["owned_skill_ids"] == ["protein-scout"]
    assert state["total_skill_purchase_price_paid"] == 0.0
    assert actions["purchase_skill"] == []
    assert skill_market["market_enabled"] is False
    assert skill_market["cards"] == []
    assert owned_index["owned_skill_ids"] == ["protein-scout"]
    assert owned_index["owned_skill_count"] == 1


def test_run_experiment_server_mode_writes_judge_audit_and_rejections(tmp_path: Path, monkeypatch) -> None:
    prepared_root = tmp_path / "prepared"
    audit_root = tmp_path / "audit"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_server_config(tmp_path, prepared_root)

    with _started_server(config_path, audit_root) as base_url:

        def fake_backend(config, *, run_dir, agent_workspace):
            del config, agent_workspace
            run_agent_step(
                run_dir,
                AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"),
            )
            run_agent_step(
                run_dir,
                AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open"),
            )
            run_agent_step(
                run_dir,
                AgentDecision(action="mine_library", seed_id="seed2", library_id="seed2_library1", batch_size=1, reasoning="illegal"),
            )
            run_agent_step(
                run_dir,
                AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=1, reasoning="mine"),
            )
            run_agent_step(run_dir, AgentDecision(action="stop", reasoning="done"))
            return {"thread_id": "thread-server"}

        monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)
        run_dir = run_experiment(config_path)

    summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
    rejections = [json.loads(line) for line in (run_dir / "results" / "rejection_log.jsonl").read_text(encoding="utf-8").splitlines()]
    audit_text = (run_dir / "results" / "judge_audit.jsonl").read_text(encoding="utf-8")
    results_manifest = json.loads((run_dir / "results" / "seed_manifest.json").read_text(encoding="utf-8"))

    assert summary["execution_model"] == "docker_agent_host_judge"
    assert summary["judge_session_id"]
    assert summary["codex_thread_id"] == "thread-server"
    assert summary["artifacts"]["judge_audit_jsonl"].endswith("judge_audit.jsonl")
    assert summary["artifacts"]["runtime_timeline_jsonl"].endswith("runtime_timeline.jsonl")
    assert summary["stop_code"] == "agent_stop"
    assert rejections[0]["rejection_code"] == "seed_not_prepared"
    assert rejections[0]["rejection_reason"].startswith("不能在未 prepared 的 seed")
    assert '"event": "action.rejected"' in audit_text
    assert results_manifest[0]["start_sequence"] == "AAAAAA"


def test_run_experiment_server_mode_uses_authoritative_seed_manifest_without_local_prepared(
    tmp_path: Path, monkeypatch
) -> None:
    prepared_root = tmp_path / "prepared"
    audit_root = tmp_path / "audit"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_server_config(tmp_path, prepared_root)

    with _started_server(config_path, audit_root) as base_url:
        admin_client = JudgeHttpClient(base_url, timeout_seconds=5, admin_token=TEST_ADMIN_TOKEN)

        def fake_backend(config, *, run_dir, agent_workspace):
            del config, agent_workspace
            run_agent_step(
                run_dir,
                AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"),
            )
            run_agent_step(run_dir, AgentDecision(action="stop", reasoning="done"))
            return {"thread_id": "thread-server-manifest"}

        monkeypatch.setattr("TadACampaign.runner.run_backend_episode", fake_backend)
        shutil.rmtree(prepared_root)
        run_dir = run_experiment(config_path)

        summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
        exported = admin_client.export_session(str(summary["judge_session_id"]))

    results_manifest = json.loads((run_dir / "results" / "seed_manifest.json").read_text(encoding="utf-8"))

    assert summary["execution_model"] == "docker_agent_host_judge"
    assert summary["codex_thread_id"] == "thread-server-manifest"
    assert results_manifest == exported["seed_manifest"]
    assert results_manifest[0]["start_sequence"] == "AAAAAA"


def test_run_experiment_server_mode_fails_closed_when_judge_is_unreachable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_server_config(tmp_path, prepared_root)
    inject_judge_server_url(config_path, "http://127.0.0.1:9")
    monkeypatch.setenv("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", TEST_ADMIN_TOKEN)

    with pytest.raises(RuntimeError, match="Judge request failed"):
        run_experiment(config_path)
