import pytest

from pathlib import Path

from TadACampaign.cli import build_parser
from TadACampaign.cli import main


PUBLIC_SURFACE_PATHS = [
    Path("README.md"),
    Path("AGENTS.md"),
    Path("config/AGENTS.md"),
    *sorted(Path("docs").glob("*.md")),
    *sorted(Path("config/experiments").glob("*.toml")),
    *sorted(Path("scripts").glob("*.sh")),
]

FORBIDDEN_SNIPPETS = [
    "run_experiment.sh",
    "run_isolated_experiment.sh",
    "TadACampaign_v2_formal_smoke",
    "TadACampaign_v2_formal_long",
    "scripts/run_TadACampaign_v2.sh both",
    "--judge-url",
    "TADACAMPAIGN_JUDGE_URL",
    "TadACampaign run --config",
    "both",
    "local mode",
    "server-only",
    "local-only",
    "resume-only",
    "full_auto",
    "dangerously_bypass_approvals",
    "codex_auto_resume",
    "EXPERIMENT_AGENT_INTERNET",
    "internet-mode",
    "my_experiment.toml",
    "wrapper",
]


def test_public_surface_exposes_only_single_supported_runtime_model() -> None:
    offending: list[str] = []
    for path in PUBLIC_SURFACE_PATHS:
        text = path.read_text(encoding="utf-8")
        for snippet in FORBIDDEN_SNIPPETS:
            if snippet in text:
                offending.append(f"{path}: {snippet}")
    assert offending == []


def test_public_cli_help_hides_internal_commands() -> None:
    help_text = build_parser().format_help()
    assert "{prepare-data,prepare-skill-market,summarize}" in help_text
    assert "agent-step" not in help_text
    assert "judge-server" not in help_text
    assert "==SUPPRESS==" not in help_text


def test_public_cli_rejects_removed_internal_command_name() -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["run", "--config", "config/experiments/TadACampaign_v2_formal.toml"])

    assert exc_info.value.code == 2


def test_wrapper_uses_isolated_container_output_mount() -> None:
    script_text = Path("scripts/run_TadACampaign_v2.sh").read_text(encoding="utf-8")

    assert "smoke 为短程预检 preset（60 days）" in script_text
    assert "formal 为正式长程 preset（180 days）" in script_text
    assert 'CONTAINER_OUTPUT_ROOT="${RUNTIME_ROOT}/output"' in script_text
    assert '-v "${CONTAINER_OUTPUT_ROOT}:/workspace/output"' in script_text
    assert '-v "${OUTPUT_ROOT}:/workspace/output"' not in script_text
    assert '-v "${RUNTIME_CONFIG_PATH}:/workspace/runtime/runtime-config.toml:ro"' in script_text
    assert '-v "${RUNTIME_ROOT}:/workspace/runtime"' not in script_text
    assert "--network host" not in script_text
    assert '--add-host="${JUDGE_ADVERTISE_HOST}:host-gateway"' in script_text
    assert 'NETWORK_POLICY_JSON="$(resolve_backend_egress_policy "${AGENT_BACKEND}" "${CODEX_STAGE_DIR}" "${JUDGE_URL}")"' in script_text
    assert 'resolve_backend_proxy_bypass_hosts "${AGENT_BACKEND}" "${CODEX_STAGE_DIR}"' in script_text
    assert 'BACKEND_PROXY_BYPASS_HOSTS+=("${bypass_host}")' in script_text
    assert 'wait_for_container_judge_health "${JUDGE_URL}"' in script_text
    assert 'judge-server 已就绪，但 experiment container 无法访问' in script_text
    assert 'STAGED_RUN_DIR="$(resolve_run_dir_from_container_log "${CONTAINER_LOG}" "${CONTAINER_OUTPUT_ROOT}")"' in script_text
    assert 'mv "${STAGED_RUN_DIR}" "${RUN_DIR}"' in script_text
    assert 'cp "${CONFIG_PATH}" "${RUN_DIR}/setting.toml"' in script_text
    assert 'TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE 只支持 formal preset' in script_text
    assert 'CONFIG_PATH="$(resolve_optional_file_path "${TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE}")"' in script_text
    assert 'cp "${CONFIG_PATH}" "${RUN_DIR}/results/host_runtime/source-config.toml"' in script_text
    assert 'git -C "${REPO_ROOT}" worktree list' not in script_text


def test_wrapper_stages_single_runtime_agents_source() -> None:
    script_text = Path("scripts/run_TadACampaign_v2.sh").read_text(encoding="utf-8")
    dockerfile_text = Path("docker/experiment.Dockerfile").read_text(encoding="utf-8")

    assert 'CONFIG_AGENTS_FILE="${REPO_ROOT}/config/AGENTS.md"' in script_text
    assert 'RUNTIME_AGENTS_FILE="${RUNTIME_ROOT}/AGENTS.md"' in script_text
    assert 'write_runtime_agents_file "${CONFIG_AGENTS_FILE}" "${RUNTIME_AGENTS_FILE}" "${SKILL_SURFACE_ENABLED}"' in script_text
    assert 'CODEX_SKILLS_MODE="none"' in script_text
    assert 'CODEX_SKILLS_MODE="${DEFAULT_SKILLS_MODE}"' in script_text
    assert '--skills-mode "${CODEX_SKILLS_MODE}"' in script_text
    assert '--global-agents-file "${RUNTIME_AGENTS_FILE}"' in script_text
    assert 'write_agents_copy_proof "${RUNTIME_AGENTS_FILE}" "${CODEX_STAGE_DIR}/AGENTS.md"' in script_text
    assert 'agents_inventory.txt' in script_text
    assert 'COPY pyproject.toml uv.lock AGENTS.md README.md /app/' not in dockerfile_text
    assert "COPY pyproject.toml uv.lock README.md /app/" in dockerfile_text
    assert "COPY src /app/src" not in dockerfile_text
    assert "COPY config /app/config" not in dockerfile_text
    assert "COPY config/experiments /app/config/experiments" in dockerfile_text
    assert "COPY docs/biology_context.md /app/docs/biology_context.md" in dockerfile_text
    assert "COPY src/TadACampaign/specs.py" not in dockerfile_text
    assert "COPY src/TadACampaign/data.py" not in dockerfile_text
    assert "COPY src/TadACampaign/environment.py" not in dockerfile_text
    assert "COPY src/TadACampaign/judge/core.py" not in dockerfile_text
    assert "COPY src/TadACampaign/judge/http.py" not in dockerfile_text
    assert "COPY src/TadACampaign/runner.py /app/src/TadACampaign/runner.py" in dockerfile_text
    assert "COPY src/TadACampaign/policies.py /app/src/TadACampaign/policies.py" in dockerfile_text
    assert "COPY src/TadACampaign/judge/client.py /app/src/TadACampaign/judge/client.py" in dockerfile_text
    assert "iptables" in dockerfile_text
    assert "jq" in dockerfile_text
    assert 'ENV PATH="/root/.local/bin:/usr/local/bin:${PATH}"' in dockerfile_text
    assert "command -v uv" in dockerfile_text


def test_runtime_agents_guides_economic_exploration_instead_of_non_stop_pressure() -> None:
    config_agents_text = Path("config/AGENTS.md").read_text(encoding="utf-8")
    script_text = Path("scripts/run_TadACampaign_v2.sh").read_text(encoding="utf-8")

    expected = (
        "additional exploration can discover higher-activity proteins; "
        "higher confirmed activity can produce substantially higher reward and improve final cash"
    )
    stop_guard = (
        "stop when the remaining actions no longer offer a credible risk-adjusted path "
        "to higher `cash_final`"
    )

    for text in (config_agents_text, script_text):
        assert expected in text
        assert stop_guard in text
        assert "If at least one meaningful legal non-stop action exists" not in text
        assert "Keep acting until the helper reports" not in text
