import json
from pathlib import Path

from TadACampaign.codex_resume import CodexEventError
from TadACampaign.codex_resume import classify_failure, inspect_event_stream, validate_event_stream


def _jsonl(*payloads: dict) -> str:
    return "".join(json.dumps(payload, ensure_ascii=False) + "\n" for payload in payloads)


def test_classify_failure_ignores_non_retryable_markers_inside_agent_stdout(tmp_path: Path) -> None:
    events_path = tmp_path / "codex_events.jsonl"
    stdout = _jsonl(
        {"type": "thread.started", "thread_id": "thread-1"},
        {"type": "turn.started"},
        {
            "type": "item.completed",
            "item": {
                "id": "msg-1",
                "type": "agent_message",
                "text": "I am checking whether the context window budget is still safe before acting.",
            },
        },
    )
    events_path.write_text(stdout, encoding="utf-8")

    snapshot = inspect_event_stream(events_path, allow_incomplete_tail=True)
    failure = classify_failure(
        snapshot=snapshot,
        process_error="Codex returned non-zero exit code 1; see stderr",
        stdout=stdout,
        stderr="stream disconnected before completion",
        validation_error=None,
    )

    assert failure.classification == "retryable_interruption"
    assert failure.retryable is True
    assert failure.continuation_mode == "resume"
    assert failure.stop_reason == "stream disconnected before completion"


def test_classify_failure_treats_missing_turn_completed_as_retryable_when_thread_exists(tmp_path: Path) -> None:
    events_path = tmp_path / "codex_events.jsonl"
    stdout = _jsonl(
        {"type": "thread.started", "thread_id": "thread-1"},
        {"type": "turn.started"},
        {
            "type": "item.completed",
            "item": {
                "id": "msg-1",
                "type": "agent_message",
                "text": "still working",
            },
        },
    )
    events_path.write_text(stdout, encoding="utf-8")

    snapshot = inspect_event_stream(events_path, allow_incomplete_tail=True)
    failure = classify_failure(
        snapshot=snapshot,
        process_error=None,
        stdout=stdout,
        stderr="",
        validation_error=CodexEventError(f"Codex event stream is missing turn.completed: {events_path}"),
    )

    assert failure.classification == "retryable_missing_turn_completed"
    assert failure.retryable is True
    assert failure.continuation_mode == "resume"


def test_classify_failure_treats_premature_completion_as_retryable(tmp_path: Path) -> None:
    events_path = tmp_path / "codex_events.jsonl"
    stdout = _jsonl(
        {"type": "thread.started", "thread_id": "thread-1"},
        {"type": "turn.started"},
        {
            "type": "item.completed",
            "item": {
                "id": "msg-1",
                "type": "agent_message",
                "text": '{"status":"completed","stop_reason":"premature","action_count":0,"summary":"not terminal"}',
            },
        },
        {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
    )
    events_path.write_text(stdout, encoding="utf-8")

    snapshot = inspect_event_stream(events_path, allow_incomplete_tail=True)
    failure = classify_failure(
        snapshot=snapshot,
        process_error=None,
        stdout=stdout,
        stderr="",
        validation_error=CodexEventError(f"Codex final JSON result was emitted before benchmark terminal state: {events_path}"),
    )

    assert failure.classification == "retryable_premature_completion"
    assert failure.retryable is True
    assert failure.continuation_mode == "resume"


def test_classify_failure_routes_context_window_exhaustion_to_fresh_handoff(tmp_path: Path) -> None:
    events_path = tmp_path / "codex_events.jsonl"
    stdout = _jsonl(
        {"type": "thread.started", "thread_id": "thread-ctx"},
        {"type": "turn.started"},
        {"type": "error", "message": "context_window_exceeded"},
    )
    events_path.write_text(stdout, encoding="utf-8")

    snapshot = inspect_event_stream(events_path, allow_incomplete_tail=True)
    failure = classify_failure(
        snapshot=snapshot,
        process_error="Codex returned non-zero exit code 1; see stderr",
        stdout=stdout,
        stderr="context_window_exceeded",
        validation_error=None,
    )

    assert failure.classification == "fresh_handoff_required"
    assert failure.retryable is True
    assert failure.continuation_mode == "handoff"


def test_validate_event_stream_accepts_completed_turn_with_transient_error_events(tmp_path: Path) -> None:
    events_path = tmp_path / "codex_events.jsonl"
    events_path.write_text(
        _jsonl(
            {"type": "thread.started", "thread_id": "thread-1"},
            {"type": "turn.started"},
            {"type": "error", "message": "stream disconnected before completion"},
            {
                "type": "item.completed",
                "item": {
                    "id": "msg-1",
                    "type": "agent_message",
                    "text": '{"status":"completed","stop_reason":"done","action_count":2,"summary":"ok"}',
                },
            },
            {"type": "turn.completed", "usage": {"input_tokens": 1, "cached_input_tokens": 0, "output_tokens": 1}},
        ),
        encoding="utf-8",
    )

    assert validate_event_stream(events_path) == "thread-1"
