import argparse
import csv
import json
from pathlib import Path

import tomllib

from scripts.create_formal_setting import create_setting
from scripts.write_TadACampaign_operator_outputs import write_operator_outputs


class Args:
    baseline: Path
    output: Path
    name: str
    initial_cash: float
    agent_backend: str
    agent_model: str | None
    agent_reasoning_effort: str | None
    agent_profile: str | None
    agent_verbosity: str | None
    seed: int | None
    prepared_root: Path
    run_output_root: Path | None
    skill_market_manifest: Path | None = None
    skill_market_enabled: bool = True
    initial_owned_skill_ids: list[str] = []


def test_create_formal_setting_overrides_only_requested_fields(tmp_path: Path) -> None:
    args = Args()
    args.baseline = Path("templates/TadACampaign_v2_formal_baseline.toml")
    args.output = tmp_path / "settings" / "fig3_budget_cash100000.toml"
    args.prepared_root = tmp_path / "prepared"
    args.run_output_root = tmp_path / "runs" / "paper_main" / "fig3_budget" / "cash100000"
    args.name = "TadACampaign_v2_formal_fig3_budget_cash100000"
    args.initial_cash = 100000.0
    args.agent_backend = "codex"
    args.agent_model = None
    args.agent_reasoning_effort = None
    args.agent_profile = None
    args.agent_verbosity = None
    args.seed = None

    output_path = create_setting(args)
    payload = tomllib.loads(output_path.read_text(encoding="utf-8"))
    baseline = tomllib.loads(Path("templates/TadACampaign_v2_formal_baseline.toml").read_text(encoding="utf-8"))

    assert payload["name"] == "TadACampaign_v2_formal_fig3_budget_cash100000"
    assert payload["initial_cash"] == 100000.0
    assert payload["agent"] == {"backend": "codex"}

    comparable = dict(payload)
    comparable["name"] = baseline["name"]
    comparable["prepared_root"] = baseline["prepared_root"]
    comparable["output_root"] = baseline["output_root"]
    comparable["initial_cash"] = baseline["initial_cash"]
    assert comparable == baseline
    assert payload["prepared_root"] == str(args.prepared_root.resolve())
    assert payload["output_root"] == str(args.run_output_root.resolve())


def test_create_formal_setting_can_override_seed(tmp_path: Path) -> None:
    args = Args()
    args.baseline = Path("templates/TadACampaign_v2_formal_baseline.toml")
    args.output = tmp_path / "settings" / "fig3_budget_cash100000_seed20260101.toml"
    args.prepared_root = tmp_path / "prepared"
    args.run_output_root = tmp_path / "runs" / "paper_main" / "fig3_budget" / "cash100000" / "seed20260101"
    args.name = "TadACampaign_v2_formal_fig3_budget_cash100000_seed20260101"
    args.seed = 20260101
    args.initial_cash = 100000.0
    args.agent_backend = "codex"
    args.agent_model = None
    args.agent_reasoning_effort = None
    args.agent_profile = None
    args.agent_verbosity = None

    output_path = create_setting(args)
    payload = tomllib.loads(output_path.read_text(encoding="utf-8"))
    baseline = tomllib.loads(Path("templates/TadACampaign_v2_formal_baseline.toml").read_text(encoding="utf-8"))

    assert payload["seed"] == 20260101
    assert payload["name"] == "TadACampaign_v2_formal_fig3_budget_cash100000_seed20260101"
    assert payload["output_root"] == str(args.run_output_root.resolve())

    comparable = dict(payload)
    comparable["name"] = baseline["name"]
    comparable["seed"] = baseline["seed"]
    comparable["prepared_root"] = baseline["prepared_root"]
    comparable["output_root"] = baseline["output_root"]
    comparable["initial_cash"] = baseline["initial_cash"]
    assert comparable == baseline


def test_create_formal_setting_sets_agent_model_fields(tmp_path: Path) -> None:
    args = Args()
    args.baseline = Path("templates/TadACampaign_v2_formal_baseline.toml")
    args.output = tmp_path / "settings" / "codex53.toml"
    args.prepared_root = tmp_path / "prepared"
    args.run_output_root = None
    args.name = "TadACampaign_v2_formal_app_codex53_xhigh_cash100000"
    args.initial_cash = 100000.0
    args.agent_backend = "codex"
    args.agent_model = "gpt-5.3-codex"
    args.agent_reasoning_effort = "xhigh"
    args.agent_profile = None
    args.agent_verbosity = None
    args.seed = None

    payload = tomllib.loads(create_setting(args).read_text(encoding="utf-8"))

    assert payload["name"] == "TadACampaign_v2_formal_app_codex53_xhigh_cash100000"
    assert payload["initial_cash"] == 100000.0
    assert payload["agent"] == {
        "backend": "codex",
        "model": "gpt-5.3-codex",
        "reasoning_effort": "xhigh",
    }


def test_create_formal_setting_supports_fig4_codex_agent_model_variants(tmp_path: Path) -> None:
    variants = [
        ("fig4_agent_codex_gpt54", "gpt-5.4", "codex_gpt54"),
        ("fig4_agent_codex_gpt53", "gpt-5.3-codex", "codex_gpt53"),
        ("fig4_agent_codex_gpt51", "gpt-5.1-codex", "codex_gpt51"),
    ]

    for setting_id, model, output_slug in variants:
        args = Args()
        args.baseline = Path("templates/TadACampaign_v2_formal_baseline.toml")
        args.output = tmp_path / "settings" / f"{setting_id}_seed20260101.toml"
        args.prepared_root = tmp_path / "prepared"
        args.run_output_root = tmp_path / "runs" / "paper_main" / "fig4_agent" / output_slug / "seed20260101"
        args.name = f"TadACampaign_v2_formal_{setting_id}_cash100000_seed20260101"
        args.seed = 20260101
        args.initial_cash = 100000.0
        args.agent_backend = "codex"
        args.agent_model = model
        args.agent_reasoning_effort = None
        args.agent_profile = None
        args.agent_verbosity = None

        payload = tomllib.loads(create_setting(args).read_text(encoding="utf-8"))

        assert payload["name"] == f"TadACampaign_v2_formal_{setting_id}_cash100000_seed20260101"
        assert payload["seed"] == 20260101
        assert payload["output_root"] == str(args.run_output_root.resolve())
        assert payload["agent"] == {
            "backend": "codex",
            "model": model,
        }


def test_create_formal_setting_writes_forced_initial_owned_skill_fields(tmp_path: Path) -> None:
    manifest_path = tmp_path / "market" / "skill_market.json"
    manifest_path.parent.mkdir(parents=True)
    manifest_path.write_text('{"version": 1, "skills": []}\n', encoding="utf-8")
    args = Args()
    args.baseline = Path("templates/TadACampaign_v2_formal_baseline.toml")
    args.output = tmp_path / "settings" / "fig5a_campaign_manager.toml"
    args.prepared_root = tmp_path / "prepared"
    args.run_output_root = tmp_path / "runs" / "paper_main" / "fig5a_single_skill" / "campaign_manager"
    args.name = "TadACampaign_v2_formal_fig5a_single_skill_campaign_manager_cash100000"
    args.initial_cash = 100000.0
    args.agent_backend = "codex"
    args.agent_model = None
    args.agent_reasoning_effort = None
    args.agent_profile = None
    args.agent_verbosity = None
    args.seed = None
    args.skill_market_manifest = manifest_path
    args.skill_market_enabled = False
    args.initial_owned_skill_ids = ["pds-campaign-manager"]

    payload = tomllib.loads(create_setting(args).read_text(encoding="utf-8"))

    assert payload["judge"]["skill_market_manifest"] == str(manifest_path.resolve())
    assert payload["judge"]["skill_market_enabled"] is False
    assert payload["judge"]["initial_owned_skill_ids"] == ["pds-campaign-manager"]


def test_operator_outputs_summarize_generic_skill_analysis_artifacts(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    results_dir = run_dir / "results"
    skill_analysis_dir = run_dir / "process" / "agent_workspace" / "skill_analysis"
    results_dir.mkdir(parents=True)
    skill_analysis_dir.mkdir(parents=True)
    (run_dir / "config.toml").write_text(
        'name = "operator_test"\nseed = 20260329\nbaseline_activity = 1.0\n',
        encoding="utf-8",
    )
    (results_dir / "summary.json").write_text(
        json.dumps(
            {
                "cash_final": 123.0,
                "day_final": 4.0,
                "action_count": 1,
                "stop_reason": "done",
                "confirmed_best_activity": 1.5,
                "skill_market_enabled": False,
                "skill_market_size": 0,
                "skill_catalog_size": 1,
                "initial_owned_skill_ids": ["generic-skill"],
                "owned_skill_count": 1,
                "owned_skill_ids": ["generic-skill"],
                "total_skill_purchase_price_paid": 0.0,
                "rejected_action_count": 0,
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (results_dir / "action_log.jsonl").write_text(
        json.dumps(
            {
                "action": "stop",
                "cash_after": 123.0,
                "elapsed_day_after": 4.0,
                "confirmed_best_before": 1.0,
                "confirmed_best_after": 1.5,
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (skill_analysis_dir / "skill_result.json").write_text(
        json.dumps(
            {
                "summary": "structure check supports stopping",
                "key_findings": ["no attractive follow-up path"],
                "usage_semantics": "optional_decision_support_not_judge_state",
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (skill_analysis_dir / "notes.log").write_text("tool ran\n", encoding="utf-8")

    args = argparse.Namespace(
        run_dir=run_dir,
        figure_id="Fig. 5a",
        experiment_theme="Single-skill effect on agent behavior",
        setting_id="fig5a_single_skill_generic",
        setting_name="Generic Skill",
        agent_name="Codex",
        initial_cash=100000.0,
        independent_variable="forced_initial_owned_skill",
        control_variables="test controls",
        purpose="test purpose",
        output_root="runs/paper_main/fig5a_single_skill/generic",
        skill_condition="Generic Skill",
        market_condition="no_market",
        prompt_append_mode="unset",
        manifest_path="/tmp/manifest.json",
    )

    summary_path = write_operator_outputs(args)

    summary_text = summary_path.read_text(encoding="utf-8")
    assert "optional skill analysis artifact count: `2`" in summary_text
    assert "process/agent_workspace/skill_analysis/skill_result.json" in summary_text
    assert "structure check supports stopping" in summary_text
    with (results_dir / "operator_run_summary.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert rows[0]["replay_seed"] == "20260329"
    assert rows[0]["skill_analysis_artifact_count"] == "2"
    assert "process/agent_workspace/skill_analysis/notes.log" in rows[0]["skill_analysis_artifacts"]


def test_operator_outputs_omit_skill_artifact_section_for_no_skill_setting(tmp_path: Path) -> None:
    run_dir = tmp_path / "run"
    results_dir = run_dir / "results"
    results_dir.mkdir(parents=True)
    (run_dir / "config.toml").write_text(
        'name = "operator_test"\nseed = 20260329\nbaseline_activity = 1.0\n',
        encoding="utf-8",
    )
    (results_dir / "summary.json").write_text(
        json.dumps(
            {
                "cash_final": 123.0,
                "day_final": 4.0,
                "action_count": 1,
                "stop_reason": "done",
                "confirmed_best_activity": 1.5,
                "skill_market_enabled": True,
                "skill_market_size": 0,
                "skill_catalog_size": 0,
                "initial_owned_skill_ids": [],
                "owned_skill_count": 0,
                "owned_skill_ids": [],
                "total_skill_purchase_price_paid": 0.0,
                "rejected_action_count": 0,
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    (results_dir / "action_log.jsonl").write_text(
        json.dumps(
            {
                "action": "stop",
                "cash_after": 123.0,
                "elapsed_day_after": 4.0,
                "confirmed_best_before": 1.0,
                "confirmed_best_after": 1.5,
            },
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )

    args = argparse.Namespace(
        run_dir=run_dir,
        figure_id="Fig. 3",
        experiment_theme="Budget effect on agent behavior",
        setting_id="fig3_budget_cash100000",
        setting_name="cash100000",
        agent_name="Codex",
        initial_cash=100000.0,
        independent_variable="initial_cash",
        control_variables="test controls",
        purpose="test purpose",
        output_root="runs/paper_main/fig3_budget/cash100000",
        skill_condition="no_skill",
        market_condition="no_market",
        prompt_append_mode="unset",
        manifest_path="unset",
    )

    summary_path = write_operator_outputs(args)

    summary_text = summary_path.read_text(encoding="utf-8")
    assert "Optional Skill Tool-Use Artifacts" not in summary_text
    assert "optional skill analysis artifact count" not in summary_text
    assert "未观察到 `process/agent_workspace/skill_analysis/`" not in summary_text
    assert "skill market enabled" not in summary_text
    with (results_dir / "operator_run_summary.csv").open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        run_summary_fields = ",".join(reader.fieldnames or [])
        run_summary_fields = handle.readline()
    assert "skill_analysis_artifact_count" not in rows[0]
    assert "skill_market_enabled" not in rows[0]
    assert "num_purchase_skill" not in rows[0]
    assert "owned_skill_ids" not in rows[0]
    assert "skill_analysis_artifacts" not in rows[0]
    assert "skill" not in run_summary_fields
    with (results_dir / "operator_event_log.csv").open(encoding="utf-8", newline="") as handle:
        event_header = handle.readline()
    assert "skill_id" not in event_header
    assert "skill_name" not in event_header
