from TadACampaign.specs import build_round_definitions, build_seed_definitions


def test_build_round_definitions_expands_to_31_rounds() -> None:
    dna_rounds = build_round_definitions("dna")
    protein_rounds = build_round_definitions("protein")
    per_round = {round_def.round_id: round_def for round_def in dna_rounds}

    assert len(dna_rounds) == 31
    assert len(protein_rounds) == 31
    assert dna_rounds[0].round_id == "r1"
    assert dna_rounds[-1].round_id == "r31"
    assert per_round["r9"].parent_candidates == ("r4",)
    assert per_round["r21"].parent_candidates == ("r16",)
    assert dna_rounds[28].parent_candidates == tuple(f"r{i}" for i in range(22, 29))
    assert dna_rounds[29].parent_candidates == tuple(f"r{i}" for i in range(22, 29))
    assert dna_rounds[30].parent_candidates == ("r29", "r30")
    assert per_round["r2"].interval_start_aa == 129
    assert per_round["r2"].interval_end_aa == 159
    assert per_round["r4"].interval_start_aa == 38
    assert per_round["r4"].interval_end_aa == 68
    assert protein_rounds[0].start_sequence.startswith("MSEVEF")


def test_build_seed_definitions_regroups_rounds_into_7_seed_library_tree() -> None:
    dna_seeds = build_seed_definitions("dna")

    assert [seed.seed_id for seed in dna_seeds] == [f"seed{i}" for i in range(1, 8)]
    assert [seed.library_count for seed in dna_seeds] == [8, 8, 4, 1, 7, 2, 1]

    per_seed = {seed.seed_id: seed for seed in dna_seeds}

    assert per_seed["seed1"].parent_seed_candidates == ()
    assert per_seed["seed2"].parent_seed_candidates == ("seed1",)
    assert per_seed["seed3"].parent_seed_candidates == ("seed1",)
    assert per_seed["seed4"].parent_seed_id == "seed2"
    assert per_seed["seed4"].parent_library_id == "seed2_library4"
    assert per_seed["seed5"].parent_library_id == "seed4_library1"
    assert per_seed["seed6"].parent_library_candidates == tuple(f"seed5_library{i}" for i in range(1, 8))
    assert per_seed["seed7"].parent_library_id == "seed6_library2"

    seed1_libraries = {library.library_id: library for library in per_seed["seed1"].libraries}
    seed2_libraries = {library.library_id: library for library in per_seed["seed2"].libraries}
    seed3_libraries = {library.library_id: library for library in per_seed["seed3"].libraries}

    assert seed1_libraries["seed1_library3"].historical_round_id == "r4"
    assert seed1_libraries["seed1_library3"].unlock_child_seed_ids == ("seed2", "seed3")
    assert seed1_libraries["seed1_library8"].historical_round_id == "r2"
    assert seed2_libraries["seed2_library4"].historical_round_id == "r16"
    assert seed2_libraries["seed2_library4"].unlock_child_seed_ids == ("seed4",)
    assert seed3_libraries["seed3_library1"].historical_round_id == "r20"
    assert per_seed["seed4"].libraries[0].unlock_child_seed_ids == ("seed5",)
    assert per_seed["seed4"].libraries[0].historical_round_id == "r21"
    assert per_seed["seed7"].libraries[0].historical_round_id == "r31"
