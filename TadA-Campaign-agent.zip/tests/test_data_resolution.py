import json

from TadACampaign.data import _resolve_parent_rounds, load_seed_definitions
from TadACampaign.models import RoundDefinition


def test_resolve_parent_rounds_picks_latest_eligible_candidate() -> None:
    rounds = [
        RoundDefinition("r29", 28, "SEQ29", 0, 1, tuple(f"r{i}" for i in range(22, 29))),
        RoundDefinition("r30", 29, "SEQ30", 0, 1, tuple(f"r{i}" for i in range(22, 29))),
        RoundDefinition("r31", 30, "SEQ31", 0, 1, ("r29", "r30")),
    ]
    observations = {
        "r29": ["r22", "r24", "r25", "r26", "r27", "r28", "r29", "r30"],
        "r30": ["r22", "r24", "r25", "r26", "r27", "r28", "r29", "r30"],
        "r31": ["r30", "r31"],
    }

    resolved = {item.round_id: item for item in _resolve_parent_rounds(rounds, observations)}

    assert resolved["r29"].parent_round_id == "r28"
    assert resolved["r30"].parent_round_id == "r28"
    assert resolved["r31"].parent_round_id == "r30"


def test_load_seed_definitions_accepts_legacy_round_fields(tmp_path) -> None:
    prepared_root = tmp_path / "prepared"
    (prepared_root / "protein").mkdir(parents=True)
    (prepared_root / "protein" / "merged.parquet").write_bytes(b"PAR1")
    (prepared_root / "manifest.json").write_text(
        json.dumps(
            {
                "variants": {
                    "protein": {
                        "data_path": "protein/merged.parquet",
                        "seed_mapping": {},
                        "seeds": [
                            {
                                "seed_id": "seed1",
                                "start_sequence": "AAAA",
                                "legacy_round_ids": ["r1"],
                                "libraries": [
                                    {
                                        "library_id": "seed1_library1",
                                        "seed_id": "seed1",
                                        "legacy_round_id": "r1",
                                        "raw_domain_id": 0,
                                        "start_sequence": "AAAA",
                                        "interval_start_aa": 0,
                                        "interval_end_aa": 2,
                                        "unlock_child_seed_ids": [],
                                    }
                                ],
                            }
                        ],
                    }
                }
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    definitions = load_seed_definitions(prepared_root, "protein")

    assert definitions[0].historical_round_ids == ("r1",)
    assert definitions[0].libraries[0].historical_round_id == "r1"
