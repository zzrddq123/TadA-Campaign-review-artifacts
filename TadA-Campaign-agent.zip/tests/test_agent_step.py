import json
import os
import subprocess
from contextlib import contextmanager
from pathlib import Path
from threading import Thread

from tests.helpers import inject_judge_server_url, write_experiment_config, write_minimal_prepared_bundle, write_skill_market_bundle
from TadACampaign.judge.http import JudgeService, _JudgeHTTPServer
from TadACampaign.models import AgentDecision
from TadACampaign.runner import _load_agent_playbook_text, _start_run_session, load_experiment_config, run_agent_step

TEST_ADMIN_TOKEN = "test-admin-token"
AGENT_PRIVATE_PAYLOAD_KEYS = {"historical_round_id", "unlock_child_seed_ids", "revealed_child_seed_ids"}


def _assert_no_agent_private_payload_keys(payload) -> None:
    if isinstance(payload, dict):
        leaked = AGENT_PRIVATE_PAYLOAD_KEYS.intersection(payload)
        assert not leaked
        for value in payload.values():
            _assert_no_agent_private_payload_keys(value)
    elif isinstance(payload, list):
        for item in payload:
            _assert_no_agent_private_payload_keys(item)


def _write_config(
    tmp_path: Path,
    prepared_root: Path,
    *,
    max_experiment_days: float = 10.0,
    skill_market_manifest: Path | None = None,
    skill_market_enabled: bool | None = None,
    initial_owned_skill_ids: tuple[str, ...] = (),
) -> Path:
    return write_experiment_config(
        tmp_path / "experiment.toml",
        name="agent_step_test",
        prepared_root=prepared_root,
        output_root=tmp_path / "runs",
        max_experiment_days=max_experiment_days,
        skill_market_manifest=skill_market_manifest,
        skill_market_enabled=skill_market_enabled,
        initial_owned_skill_ids=initial_owned_skill_ids,
    )


@contextmanager
def _running_judge(config_path: Path, audit_root: Path):
    config = load_experiment_config(config_path)
    previous_admin_token = os.environ.get("TADACAMPAIGN_JUDGE_ADMIN_TOKEN")
    os.environ["TADACAMPAIGN_JUDGE_ADMIN_TOKEN"] = TEST_ADMIN_TOKEN
    service = JudgeService(config, audit_root=audit_root, admin_token=TEST_ADMIN_TOKEN)
    server = _JudgeHTTPServer(("127.0.0.1", 0), service)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        base_url = f"http://127.0.0.1:{server.server_port}"
        inject_judge_server_url(config_path, base_url)
        yield base_url
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()
        if previous_admin_token is None:
            os.environ.pop("TADACAMPAIGN_JUDGE_ADMIN_TOKEN", None)
        else:
            os.environ["TADACAMPAIGN_JUDGE_ADMIN_TOKEN"] = previous_admin_token


def test_run_agent_step_exposes_prepare_seed_path_and_updates_workspace(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        config, run_dir = _start_run_session(config_path)
        expected_playbook = _load_agent_playbook_text(config)
        initial_state = json.loads((run_dir / "process" / "agent_workspace" / "state.json").read_text(encoding="utf-8"))
        initial_actions = json.loads(
            (run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8")
        )
        initial_playbook = (run_dir / "process" / "agent_workspace" / "agent_playbook.md").read_text(encoding="utf-8")
        biology_context = (run_dir / "process" / "agent_workspace" / "biology_context.md").read_text(encoding="utf-8")
        run_config = (run_dir / "config.toml").read_text(encoding="utf-8")

        assert initial_state["visible_seed_ids"] == ["seed1"]
        assert initial_state["prepared_seed_ids"] == []
        assert initial_state["economic_summary"]["budget_regime"] == "can_mine_and_confirm"
        assert initial_state["economic_summary"]["minimum_mine_then_confirm_total_cost"] > 0.0
        assert [item["seed_id"] for item in initial_actions["prepare_seed"]] == ["seed1"]
        assert initial_actions["prepare_library"] == []
        _assert_no_agent_private_payload_keys(initial_state)
        _assert_no_agent_private_payload_keys(initial_actions)
        assert initial_playbook == expected_playbook
        assert "base_asset_value = 1000.0" in initial_playbook
        assert "tier 1: `[1.0, +inf)`" in initial_playbook
        assert "For example, under the current config:" in initial_playbook
        assert "optional `biology_context.md`" in initial_playbook
        assert "Optional Skill Tool Use" not in initial_playbook
        assert "follow the skill documentation, analyze the returned result" not in initial_playbook
        assert "skill_analysis/" not in initial_playbook
        assert "purchase_skill" not in initial_playbook
        assert "skill_market.json" not in initial_playbook
        assert "owned_skills_index.json" not in initial_playbook
        assert "Budget-Closure Strategy" in initial_playbook
        assert "leaves_confirm_capacity" in initial_playbook
        assert "Agent-Visible Information" in initial_playbook
        assert "You are an in-campaign operator. Decide only from the current refreshed workspace files" in initial_playbook
        assert "current visible seeds and which visible seeds are prepared" in initial_playbook
        assert "the exploration path actually revealed by previous actions" in initial_playbook
        assert "prepared-library screenable sequence count, screened count, remaining count, and legal batch options" in initial_playbook
        assert "must read relevant `owned_skills" not in initial_playbook
        assert "TadA-Campaign Biology Context" in biology_context
        assert "At each decision point, only the currently visible seeds" in biology_context
        assert "Branch structure is learned through actions." in biology_context
        assert "Branch value and immediate activity value are different." in biology_context
        assert "purchase_skill" not in biology_context
        assert "owned_skills" not in biology_context
        assert "unlock_child_seed_ids" not in initial_playbook
        assert "unlock_child_seed_ids" not in biology_context
        assert "historical_round_id" not in initial_playbook
        assert "historical_round_id" not in biology_context
        assert "seed1_library3" not in biology_context
        assert "state.json" not in initial_state
        assert "purchase_skill" not in initial_actions
        assert "skill_market_enabled" not in initial_state
        assert not (run_dir / "process" / "agent_workspace" / "skill_market.json").exists()
        assert not (run_dir / "process" / "agent_workspace" / "owned_skills_index.json").exists()
        assert not (run_dir / "process" / "agent_workspace" / "owned_skills").exists()
        assert "skill_market_manifest" not in run_config
        assert "skill_market_enabled" not in run_config
        assert "initial_owned_skill_ids" not in run_config
        assert "owned_skill" not in run_config
        assert "purchase_skill" not in run_config
        assert "skill_analysis" not in run_config
        assert not (run_dir / "process" / "agent_workspace" / "AGENTS.md").exists()

        payload = run_agent_step(
            run_dir,
            AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"),
        )

        assert payload["accepted"] is True
        assert payload["terminal"] is False
        state = json.loads((run_dir / "process" / "agent_workspace" / "state.json").read_text(encoding="utf-8"))
        actions = json.loads((run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8"))
        history = json.loads((run_dir / "process" / "agent_workspace" / "history.json").read_text(encoding="utf-8"))
        refreshed_playbook = (run_dir / "process" / "agent_workspace" / "agent_playbook.md").read_text(encoding="utf-8")

    assert state["visible_seed_ids"] == ["seed1"]
    assert state["prepared_seed_ids"] == ["seed1"]
    assert actions["prepare_seed"] == []
    assert {item["seed_id"] for item in actions["prepare_library"]} == {"seed1"}
    assert "purchase_skill" not in actions
    assert "skill_market_enabled" not in state
    _assert_no_agent_private_payload_keys(state)
    _assert_no_agent_private_payload_keys(actions)
    _assert_no_agent_private_payload_keys(history)
    assert refreshed_playbook == expected_playbook
    assert (run_dir / "process" / "agent_workspace" / "biology_context.md").is_file()
    assert (run_dir / "process" / "step_001" / "chosen_action.json").is_file()
    assert not (run_dir / "process" / "agent_workspace" / "AGENTS.md").exists()


def test_run_agent_step_keeps_runtime_workspace_topology_blind_after_library_prepare(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        payload = run_agent_step(
            run_dir,
            AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open branch"),
        )
        workspace = run_dir / "process" / "agent_workspace"
        state = json.loads((workspace / "state.json").read_text(encoding="utf-8"))
        actions = json.loads((workspace / "available_actions.json").read_text(encoding="utf-8"))
        history = json.loads((workspace / "history.json").read_text(encoding="utf-8"))
        judge_response = json.loads((run_dir / "process" / "step_002" / "judge_response.json").read_text(encoding="utf-8"))

    assert payload["accepted"] is True
    assert payload["action_record"]["newly_visible_seed_ids"] == ["seed2"]
    assert state["visible_seed_ids"] == ["seed1", "seed2"]
    assert [item["seed_id"] for item in actions["prepare_seed"]] == ["seed2"]
    _assert_no_agent_private_payload_keys(payload)
    _assert_no_agent_private_payload_keys(judge_response)
    _assert_no_agent_private_payload_keys(state)
    _assert_no_agent_private_payload_keys(actions)
    _assert_no_agent_private_payload_keys(history)


def test_run_agent_step_rejects_illegal_action_without_forcing_stop(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        payload = run_agent_step(
            run_dir,
            AgentDecision(
                action="mine_library",
                seed_id="seed2",
                library_id="seed2_library1",
                batch_size=1,
                reasoning="illegal",
            ),
        )

    assert payload["accepted"] is False
    assert payload["terminal"] is False
    assert payload["rejection_code"] == "seed_not_visible"
    assert str(payload["rejection_reason"]).startswith("不能在不可见的 seed")
    chosen = json.loads((run_dir / "process" / "step_001" / "chosen_action.json").read_text(encoding="utf-8"))
    assert chosen["action"] == "mine_library"
    judge_response = json.loads((run_dir / "process" / "step_001" / "judge_response.json").read_text(encoding="utf-8"))
    assert judge_response["accepted"] is False
    assert judge_response["rejection_code"] == "seed_not_visible"
    step_meta = json.loads((run_dir / "process" / "step_001" / "step_meta.json").read_text(encoding="utf-8"))
    assert step_meta["rejection_code"] == "seed_not_visible"


def test_run_agent_step_rejects_prepare_library_for_unprepared_seed(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        payload = run_agent_step(
            run_dir,
            AgentDecision(
                action="prepare_library",
                seed_id="seed1",
                library_id="seed1_library1",
                reasoning="skip prepare_seed",
            ),
        )

    assert payload["accepted"] is False
    assert payload["terminal"] is False
    assert str(payload["rejection_reason"]).startswith("不能在未 prepared 的 seed")
    judge_response = json.loads((run_dir / "process" / "step_001" / "judge_response.json").read_text(encoding="utf-8"))
    assert judge_response["accepted"] is False


def test_run_agent_step_forces_stop_after_time_horizon(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root, max_experiment_days=1.0)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        payload = run_agent_step(
            run_dir,
            AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"),
        )

    assert payload["terminal"] is True
    assert payload["summary"]["stop_reason"] == "已达到 max_experiment_days，实验结束"


def test_generated_helper_script_runs_from_agent_workspace(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        helper_path = run_dir / "process" / "agent_workspace" / "TadACampaign-agent-step"

        completed = subprocess.run(
            [str(helper_path), "--action", "stop", "--reasoning", "done"],
            cwd=helper_path.parent,
            check=True,
            capture_output=True,
            text=True,
        )

        payload = json.loads(completed.stdout)

    assert payload["terminal"] is True
    assert payload["stop_reason"] == "done"
    assert (run_dir / "process" / "step_001" / "chosen_action.json").is_file()


def test_generated_helper_help_hides_skill_action_without_manifest(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        helper_path = run_dir / "process" / "agent_workspace" / "TadACampaign-agent-step"

        help_result = subprocess.run(
            [str(helper_path), "--help"],
            cwd=helper_path.parent,
            check=True,
            capture_output=True,
            text=True,
        )
        purchase_result = subprocess.run(
            [str(helper_path), "--action", "purchase_skill", "--reasoning", "buy"],
            cwd=helper_path.parent,
            check=False,
            capture_output=True,
            text=True,
        )

    assert "purchase_skill" not in help_result.stdout
    assert "--skill-id" not in help_result.stdout
    assert purchase_result.returncode != 0
    assert "purchase_skill" in purchase_result.stderr
    assert "--skill-id" not in purchase_result.stderr


def test_runtime_agent_step_bare_help_defaults_to_no_skill_surface() -> None:
    help_result = subprocess.run(
        ["python", "-m", "TadACampaign.runtime_entrypoints", "agent-step", "--help"],
        check=True,
        capture_output=True,
        text=True,
    )

    assert "purchase_skill" not in help_result.stdout
    assert "--skill-id" not in help_result.stdout


def test_generated_helper_help_shows_skill_action_with_manifest(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = _write_config(tmp_path, prepared_root, skill_market_manifest=market_manifest)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        helper_path = run_dir / "process" / "agent_workspace" / "TadACampaign-agent-step"

        help_result = subprocess.run(
            [str(helper_path), "--help"],
            cwd=helper_path.parent,
            check=True,
            capture_output=True,
            text=True,
        )

    assert "purchase_skill" in help_result.stdout
    assert "--skill-id" in help_result.stdout


def test_run_agent_step_supports_confirm_hit(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        run_agent_step(
            run_dir,
            AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open"),
        )
        pre_mine_actions = json.loads(
            (run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8")
        )
        batch_option = pre_mine_actions["mine_library"][0]["batch_options"][0]
        assert "cash_after_action_and_confirm_reserve" in batch_option
        assert "remaining_days_after_action_and_confirm_reserve" in batch_option
        assert "leaves_confirm_capacity" in batch_option
        mine_payload = run_agent_step(
            run_dir,
            AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="screen"),
        )
        assert mine_payload["accepted"] is True
        actions = json.loads((run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8"))
        screen_record_id = int(actions["confirm_hit"][0]["screen_record_id"])

        confirm_payload = run_agent_step(
            run_dir,
            AgentDecision(action="confirm_hit", screen_record_id=screen_record_id, reasoning="confirm lead"),
        )
        state = json.loads((run_dir / "process" / "agent_workspace" / "state.json").read_text(encoding="utf-8"))

    assert confirm_payload["accepted"] is True
    assert confirm_payload["action_record"]["reward_earned"] > 0.0
    assert state["confirmed_best_activity"] > 1.0
    assert state["pending_confirmation_count"] == 0
    chosen = json.loads((run_dir / "process" / "step_004" / "chosen_action.json").read_text(encoding="utf-8"))
    assert chosen["action"] == "confirm_hit"
    assert chosen["screen_record_id"] == screen_record_id


def test_agent_step_stdout_compacts_sequences_but_workspace_keeps_confirm_target(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        run_agent_step(
            run_dir,
            AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open"),
        )
        mine_payload = run_agent_step(
            run_dir,
            AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="screen"),
        )
        actions = json.loads((run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8"))
        history = json.loads((run_dir / "process" / "agent_workspace" / "history.json").read_text(encoding="utf-8"))
        judge_response = json.loads((run_dir / "process" / "step_003" / "judge_response.json").read_text(encoding="utf-8"))

    assert mine_payload["accepted"] is True
    assert mine_payload["confirmed_best_sequence"] is None
    assert "provisional_best_sequence" not in mine_payload
    assert "provisional_best_sequence_summary" in mine_payload
    assert "sequence" not in mine_payload["action_record"]["best_update"]
    assert "sequence_prefix" in mine_payload["action_record"]["best_update"]
    assert "sequence" not in history["recent_actions"][-1]["best_update"]
    assert "sequence_prefix" in history["recent_actions"][-1]["best_update"]
    assert "sequence" not in history["recent_screen_records"][0]
    assert "sequence_prefix" in history["recent_screen_records"][0]
    assert "sequence" in actions["confirm_hit"][0]
    assert judge_response["action_record"]["pending_confirmation_added"]["sequence"] == actions["confirm_hit"][0]["sequence"]


def test_run_agent_step_returns_structured_rejection_when_confirm_hit_lacks_cash(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)
    config_path.write_text(
        config_path.read_text(encoding="utf-8")
        .replace("initial_cash = 1000.0\n", "initial_cash = 80.0\n")
        .replace("confirm_hit_cost = 5.0\n", "confirm_hit_cost = 40.0\n"),
        encoding="utf-8",
    )

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        run_agent_step(run_dir, AgentDecision(action="prepare_seed", seed_id="seed1", reasoning="enter root"))
        run_agent_step(
            run_dir,
            AgentDecision(action="prepare_library", seed_id="seed1", library_id="seed1_library1", reasoning="open"),
        )
        run_agent_step(
            run_dir,
            AgentDecision(action="mine_library", seed_id="seed1", library_id="seed1_library1", batch_size=2, reasoning="screen"),
        )

        actions = json.loads((run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8"))
        assert actions["confirm_hit"] == []
        history = json.loads((run_dir / "process" / "agent_workspace" / "history.json").read_text(encoding="utf-8"))
        screen_record_id = max(int(item["screen_record_id"]) for item in history["recent_screen_records"])

        payload = run_agent_step(
            run_dir,
            AgentDecision(action="confirm_hit", screen_record_id=screen_record_id, reasoning="confirm even though cash is short"),
        )

    assert payload["accepted"] is False
    assert payload["terminal"] is False
    assert payload["rejection_reason"] == "现金不足，无法执行 `confirm_hit`；当前现金 31.00，需要 41.00"


def test_run_agent_step_purchase_skill_materializes_owned_skill_tree(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = _write_config(tmp_path, prepared_root, skill_market_manifest=market_manifest)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        initial_market = json.loads((run_dir / "process" / "agent_workspace" / "skill_market.json").read_text(encoding="utf-8"))
        assert initial_market["cards"][0]["skill_id"] == "protein-scout"
        assert (run_dir / "process" / "agent_workspace" / "owned_skills_index.json").is_file()

        payload = run_agent_step(
            run_dir,
            AgentDecision(action="purchase_skill", skill_id="protein-scout", reasoning="unlock offline guide"),
        )

        owned_index = json.loads(
            (run_dir / "process" / "agent_workspace" / "owned_skills_index.json").read_text(encoding="utf-8")
        )
        materialized_skill = run_dir / "process" / "agent_workspace" / "owned_skills" / "protein-scout" / "source" / "SKILL.md"

    assert payload["accepted"] is True
    assert payload["owned_skills_dir"].endswith("owned_skills")
    assert owned_index["owned_skill_ids"] == ["protein-scout"]
    assert materialized_skill.read_text(encoding="utf-8").startswith("# Protein Scout")
    chosen = json.loads((run_dir / "process" / "step_001" / "chosen_action.json").read_text(encoding="utf-8"))
    assert chosen["skill_id"] == "protein-scout"


def test_run_agent_step_skill_config_keeps_skill_guidance_visible(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = _write_config(tmp_path, prepared_root, skill_market_manifest=market_manifest)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        workspace = run_dir / "process" / "agent_workspace"
        playbook = (workspace / "agent_playbook.md").read_text(encoding="utf-8")
        biology_context = (workspace / "biology_context.md").read_text(encoding="utf-8")

    assert "Optional Skill Tool Use" in playbook
    assert "skill_analysis/" in playbook
    assert "purchase_skill" in playbook
    assert "owned_skills/<skill_id>/source/SKILL.md" in playbook
    assert "Skill Use" in biology_context
    assert "skill_analysis/" in biology_context


def test_run_agent_step_materializes_forced_initial_owned_skill_at_start(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    market_manifest = write_skill_market_bundle(tmp_path)
    config_path = _write_config(
        tmp_path,
        prepared_root,
        skill_market_manifest=market_manifest,
        skill_market_enabled=False,
        initial_owned_skill_ids=("protein-scout",),
    )

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        workspace = run_dir / "process" / "agent_workspace"
        skill_market = json.loads((workspace / "skill_market.json").read_text(encoding="utf-8"))
        owned_index = json.loads((workspace / "owned_skills_index.json").read_text(encoding="utf-8"))
        state = json.loads((workspace / "state.json").read_text(encoding="utf-8"))
        actions = json.loads((workspace / "available_actions.json").read_text(encoding="utf-8"))
        materialized_skill = workspace / "owned_skills" / "protein-scout" / "source" / "SKILL.md"

    assert skill_market["market_enabled"] is False
    assert skill_market["market_size"] == 0
    assert skill_market["cards"] == []
    assert owned_index["owned_skill_ids"] == ["protein-scout"]
    assert owned_index["owned_skill_count"] == 1
    assert state["skill_market_enabled"] is False
    assert state["skill_market_size"] == 0
    assert state["skill_catalog_size"] == 1
    assert state["initial_owned_skill_ids"] == ["protein-scout"]
    assert state["total_skill_purchase_price_paid"] == 0.0
    assert actions["purchase_skill"] == []
    assert materialized_skill.read_text(encoding="utf-8").startswith("# Protein Scout")


def test_run_agent_step_server_mode_rejects_illegal_action_and_keeps_state_alive(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        initial_state = json.loads((run_dir / "process" / "agent_workspace" / "state.json").read_text(encoding="utf-8"))
        initial_actions = json.loads(
            (run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8")
        )
        assert initial_state["visible_seed_ids"] == ["seed1"]
        assert [item["seed_id"] for item in initial_actions["prepare_seed"]] == ["seed1"]
        payload = run_agent_step(
            run_dir,
            AgentDecision(action="mine_library", seed_id="seed2", library_id="seed2_library1", batch_size=1, reasoning="illegal"),
        )
        state_after_rejection = json.loads((run_dir / "process" / "agent_workspace" / "state.json").read_text(encoding="utf-8"))
        actions_after_rejection = json.loads(
            (run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8")
        )

    assert payload["accepted"] is False
    assert payload["terminal"] is False
    assert str(payload["rejection_reason"]).startswith("不能在不可见的 seed")
    judge_response = json.loads((run_dir / "process" / "step_001" / "judge_response.json").read_text(encoding="utf-8"))
    assert judge_response["accepted"] is False
    assert state_after_rejection["visible_seed_ids"] == ["seed1"]
    assert state_after_rejection["prepared_seed_ids"] == []
    assert [item["seed_id"] for item in actions_after_rejection["prepare_seed"]] == ["seed1"]
    assert not (run_dir / "results" / "seed_manifest.json").exists()


def test_run_agent_step_server_mode_terminal_workspace_hides_actionable_actions(tmp_path: Path) -> None:
    prepared_root = tmp_path / "prepared"
    write_minimal_prepared_bundle(prepared_root)
    config_path = _write_config(tmp_path, prepared_root)

    with _running_judge(config_path, tmp_path / "audit"):
        _, run_dir = _start_run_session(config_path)
        payload = run_agent_step(
            run_dir,
            AgentDecision(action="stop", reasoning="done"),
        )

    assert payload["terminal"] is True
    workspace_actions = json.loads(
        (run_dir / "process" / "agent_workspace" / "available_actions.json").read_text(encoding="utf-8")
    )
    assert workspace_actions["prepare_seed"] == []
    assert workspace_actions["prepare_library"] == []
    assert workspace_actions["mine_library"] == []
    assert "purchase_skill" not in workspace_actions
    assert workspace_actions["stop"] == {"action": "stop"}
