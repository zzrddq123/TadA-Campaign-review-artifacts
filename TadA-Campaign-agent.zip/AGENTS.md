# Repo Notes

## Execution Policy

- The repo supports exactly one public execution model:
  - Docker-hosted agent
  - host-side authoritative judge server
  - prepared benchmark data consumed only by the host judge
- The only public runtime entrypoint is `bash scripts/run_TadACampaign_v2.sh smoke|formal [output-root]`.
- Public presets are limited to `smoke` and `formal`.
- Do not reintroduce host-run agent workflows, alternate runtime entry scripts, or judge-mode branching in code, docs, scripts, configs, or tests.

## Network Troubleshooting

- If external network access fails, a temporary HTTP/HTTPS proxy may be used.
- Do not leave the proxy enabled globally when the current task depends on local services such as `127.0.0.1:8080`; that can break local experiment traffic.
- Prefer command-scoped or subshell-scoped proxy exports, and keep localhost bypassed.

```bash
export NO_PROXY=127.0.0.1,localhost,::1
export no_proxy=127.0.0.1,localhost,::1
```

- If a run needs direct localhost access again, clear the proxy first:

```bash
unset HTTP_PROXY HTTPS_PROXY http_proxy https_proxy
```
