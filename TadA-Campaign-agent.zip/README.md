# TadA-Campaign

TadA-Campaign is a replayable, biology-grounded benchmark for long-horizon AI operation in protein engineering. Each run casts an agent as the operator of a budgeted TadA directed-evolution campaign: it prepares seed backgrounds, opens mutational libraries, screens variants through noisy discovery batches, confirms promising hits, may acquire optional BioSkill workflows, and decides when to stop.

The terminal objective is `cash_final`. Confirmed high-activity TadA variants can produce reward, while every action consumes direct cost and elapsed campaign time. The benchmark therefore evaluates whether an agent can manage uncertain experimental evidence, branch-opening decisions, validation timing, budget risk, and stopping decisions rather than simply emit a single prediction.

The Python package and command-line tool use the `TadACampaign` name throughout.

## Execution Model

TadA-Campaign exposes one public runtime path:

- the agent runs inside a Docker experiment container
- the authoritative judge server runs on the host
- prepared benchmark data is loaded only by the host-side judge
- the agent advances the experiment only through the staged helper and judge API

This boundary keeps future candidates, true activities, and settlement state out of the agent container while preserving a replayable audit trail.

## Requirements

- Python `>=3.11` available as `python3`, `uv`, and Bash `>=4.4`
- A running Docker Engine on Linux with Linux containers and permission to run Docker without `sudo`
- Network access to Hugging Face, the build dependency registries, and your model provider
- Codex CLI and your own credentials for a model available to that account

The repository uses `uv` for Python dependency resolution. The experiment container is built by the public launch script.

## Quick Start

TadA-Bench is a publicly available dataset. Place the raw dataset archive at
`data/TadABench-1M.zip`, then prepare the benchmark tables:

```bash
uv sync --locked
uv run TadACampaign prepare-data --zip-path data/TadABench-1M.zip --output-dir prepared
```

For an OpenAI API-key login, set `OPENAI_API_KEY` in your local shell and use
Codex's file-backed login:

```bash
printenv OPENAI_API_KEY | codex login -c 'cli_auth_credentials_store="file"' --with-api-key
codex login status
```

The launcher stages the login from `~/.codex/auth.json` and uses your local
Codex model configuration. Keep the credentials outside the repository.

Run a short preflight episode:

```bash
bash scripts/run_TadACampaign_v2.sh smoke runs/quickstart-smoke
```

Run the formal long-horizon preset:

```bash
bash scripts/run_TadACampaign_v2.sh formal runs/quickstart-formal
```

The second argument is an output root. The launcher creates a timestamped run directory under that root and prints the final run path when execution completes.

Data preparation must be performed in the same checkout used for the run. The launcher does not search other checkouts or worktrees for `prepared/`.

## Public Entry Points

Use only these supported runtime commands:

```bash
bash scripts/run_TadACampaign_v2.sh smoke [output-root]
bash scripts/run_TadACampaign_v2.sh formal [output-root]
```

Internal CLI subcommands and runtime modules exist to support this launch path. They are not the public experiment interface.

## Public Presets

The public presets are:

- `config/experiments/TadACampaign_v2_smoke.toml`
- `config/experiments/TadACampaign_v2_formal.toml`

The `smoke` preset is a 60-day preflight setting intended to validate the data, Docker, judge, backend, and output pipeline. The `formal` preset is a 180-day long-horizon setting intended for full experimental evaluation.

Current public settings use:

- variant: `dna`
- initial visible seed: `seed1`
- initial prepared seeds: none
- initial cash: `$100000`
- daily burn cost: `$800`
- noisy screening enabled with `screening_noise_sigma = 0.10` and `screening_noise_clip = 0.20`
- mining batch sizes: `780`, `880`, `1020`, and `1280`

## Benchmark Mechanics

TadA-Campaign is built around a historical TadA directed-evolution campaign that is exposed to the agent as a library-triggered exploration graph. Backgrounds and mutational-window libraries become available through legal experimental actions; downstream backgrounds are derived from improved variants and therefore can offer greater activity upside than their ancestors, without guaranteeing improvement.

The legal action families are:

- `prepare_seed`: activate a visible seed background for later library work
- `prepare_library`: build one mutational-window library and possibly reveal downstream seed backgrounds
- `mine_library`: screen a prepared library and observe noisy activity evidence
- `confirm_hit`: run an orthogonal validation for a screened candidate and settle confirmed activity
- `purchase_skill`: acquire an optional local BioSkill decision-support asset when a skill market is configured
- `stop`: end the campaign and preserve the current terminal cash state

Only confirmed activity can update `confirmed_best_activity` and trigger reward. Screening results are provisional evidence until a candidate is confirmed.

## Runtime Workspace

During a run, the agent container receives a staged workspace containing the current public state and helper files. The authoritative state remains with the host judge.

Important agent-facing files include:

- `state.json`
- `available_actions.json`
- `history.json`
- `skill_market.json`
- `owned_skills_index.json`
- `biology_context.md`

`state.json` and `available_actions.json` define the current legal decision surface. `history.json` is a rolling summary for long runs. `biology_context.md` explains action-level biology, costs, timing, branch semantics, and skill use, but it is not an authority for action legality.

## Output Layout

A completed run has this top-level shape:

```text
<run-dir>/
  setting.toml
  config.toml
  process/
  results/
```

Key result files:

- `results/summary.json`
- `results/summary.md`
- `results/action_log.jsonl`
- `results/screen_record_history.jsonl`
- `results/rejection_log.jsonl`
- `results/judge_audit.jsonl`
- `results/runtime_timeline.jsonl`
- `results/seed_manifest.json`
- `results/cash_curve.csv`
- `results/cash_curve.png`
- `results/agent_stdout.log`
- `results/agent_stderr.log`
- `results/agent_final_result.json`

Useful process files:

- `process/agent_workspace/state.json`
- `process/agent_workspace/available_actions.json`
- `process/agent_workspace/history.json`
- `process/agent_workspace/biology_context.md`
- `process/step_<N>/chosen_action.json`
- `process/step_<N>/judge_response.json`
- `process/step_<N>/step_meta.json`

For final performance, start with `results/summary.json`. For behavioral analysis, inspect `results/action_log.jsonl`, `results/screen_record_history.jsonl`, `results/rejection_log.jsonl`, and the final `process/agent_workspace/` state.

## Optional Skill Market

TadA-Campaign can expose offline BioSkill workflows as optional decision-support assets. A configured market shows limited preview cards before purchase. After purchase, the full skill source appears under:

```text
owned_skills/<skill_id>/source/
```

Forced-skill settings can also start a run with one or more owned skills already present. In that case the skill is an experimental condition rather than a purchase action, and it does not consume cash or elapsed days.

Skill outputs are decision-support artifacts only. They do not change judge state, cannot make illegal actions legal, and should be interpreted through the current `state.json` and `available_actions.json`.

## Formal Runs

The formal preset typically runs longer than three minutes. Use `tmux` or an equivalent session manager for long experiments:

```bash
tmux new -s TadA-Campaign-formal
bash scripts/run_TadACampaign_v2.sh formal runs/formal
```

For paper-style settings, generate a dedicated `setting.toml` with:

```bash
uv run python scripts/create_formal_setting.py --help
```

Then launch the formal preset with the repository-supported override environment variable documented in `docs/formal_experiment_prompts.md` and `docs/output_reference.md`.

## Trust Boundary

The host judge is the only authority for:

- prepared data access
- legal action validation
- cost and time accounting
- noisy screening observations
- confirmation settlement
- reward calculation
- terminal conditions
- exported audit logs and summaries

The agent container does not directly read prepared parquet data, host judge memory, or historical runs under the same output root. A run's final artifacts are published only after the isolated staging run directory is complete.

## Documentation

More detailed references:

- `docs/operator_playbook.md`
- `docs/game_rules.md`
- `docs/biology_context.md`
- `docs/config_reference.md`
- `docs/output_reference.md`
- `docs/trust_model.md`
- `docs/formal_experiment_prompts.md`

These documents describe operator procedures, state semantics, configuration fields, output artifacts, and the host-judge trust model.
