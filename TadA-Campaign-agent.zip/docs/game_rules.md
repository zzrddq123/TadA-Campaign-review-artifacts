# TadA-Campaign Game Rules

## One-Sentence Version

TadA-Campaign models a TadA directed-evolution campaign as a long-horizon experimental-operations benchmark with budget, time, branch reveal, screening cost, confirmation cost, and optional skill-purchase cost. The final score is `cash_final`.

## 1. Basic Objects

The campaign begins with one visible background and gradually reveals additional backgrounds through legal library actions. Each revealed background has its own starting sequence and mutational-window libraries. A downstream or deeper background is derived from an improved variant and therefore has a higher prior for activity potential than its ancestor, but it is not guaranteed to be best. After each `prepare_library`, the action-response JSON field `newly_visible_seed_ids` and the refreshed `visible_seed_ids` record which backgrounds were actually opened. The agent maintains its exploration tree from actions that have occurred.

The agent is an in-campaign operator. It should decide from current visible sequences, mutational windows, screening/confirmation history, budget-closure capacity, the exploration path actually revealed by actions, and available skill analysis.

Fresh sessions default to:

- `initial_visible_seeds = ["seed1"]`
- `initial_prepared_seeds = []`

## 2. What The Agent Knows

The authoritative judge continuously refreshes these workspace files:

- `state.json`
- `available_actions.json`
- `history.json`
- `skill_market.json`
- `owned_skills_index.json`

The experiment state in the runtime workspace is defined by these files.

The workspace also provides optional `biology_context.md`. It is not authoritative state and is not expanded at every step. The agent may read it when it needs experiment semantics, cost/timing interpretation, or branch context.

Owned skills in the workspace are optional decision-support capabilities. The agent may follow `owned_skills/<skill_id>/source/SKILL.md`, call tools, scripts, checklists, or query workflows, analyze returned results, and then decide the next action. Optional outputs should be saved under `skill_analysis/`; those outputs do not change judge state or action legality.

At each decision point, the agent may use:

- current visible seeds and which seeds are prepared
- each visible seed's `start_sequence`, seed status, parent candidate ids, and the exploration path actually revealed by actions
- each visible library's `library_id`, `seed_id`, mutational window, window length, and prepared/locked status
- prepared-library screenable sequence count, screened count, remaining count, and current legal batch options
- current cash, elapsed days, remaining days, action costs, time costs, whether a mine action preserves confirmation capacity, and budget-closure fields in `economic_summary`
- screening history, pending confirmations, confirmed best, provisional best, confirmed activity values, reward records, and cost records
- local files for owned skills, `skill_analysis/` results, and the agent's own sequence, candidate, and cost-benefit analysis

### `state.json`

Core fields include:

- `current_cash`
- `elapsed_day`
- `remaining_days`
- `confirmed_best_activity`
- `confirmed_best_sequence`
- `provisional_best_activity`
- `provisional_best_sequence`
- `visible_seed_ids`
- `prepared_seed_ids`
- `prepared_library_ids`
- `screen_record_count`
- `confirmed_screen_record_count`
- `pending_confirmation_count`
- `pending_confirmations`
- `economic_summary`
- `skill_market_enabled`
- `skill_market_size`
- `skill_catalog_size`
- `initial_owned_skill_ids`
- `owned_skill_count`
- `owned_skill_ids`
- `total_skill_purchase_price_paid`
- `action_count`
- `rejected_action_count`
- `request_count`
- `total_reward_earned`
- `total_cost_paid`
- `stop_code`
- `stop_reason`
- `screening_noise_enabled`
- `screening_noise_sigma`
- `screening_noise_clip`
- `seeds`

Each seed payload provides:

- `seed_id`
- `parent_seed_candidate_ids`
- `parent_library_candidate_ids`
- `start_sequence`
- `seed_status`
- `libraries`

Each library payload provides:

- `library_id`
- `mutable_interval_aa`
- `interval_length_aa`
- `library_status`

When `library_status = "prepared"`, the payload also provides:

- `screenable_sequence_count`
- `screened_sequence_count`
- `remaining_screenable_sequence_count`

### `available_actions.json`

The structure is fixed:

- `prepare_seed`: array
- `prepare_library`: array
- `mine_library`: array
- `confirm_hit`: array
- `purchase_skill`: array
- `stop`: single object

Important details:

- prepared libraries expose `screenable_sequence_count`, `screened_sequence_count`, and `remaining_screenable_sequence_count` in `state.json` and `available_actions.json`
- `mine_library` can use only discrete `batch_options`
- `confirm_hit` can use only currently listed `screen_record_id` values
- `purchase_skill` can use only currently listed `skill_id` values
- current public preset `mine_library` batch size is variant throughput; the menu is `780`, `880`, `1020`, and `1280`

### `history.json`

Current public history exposes:

- `recent_actions`
- `recent_screen_records`
- `recent_rejections`

The stable screening-record identifier is `screen_record_id`.

`history.json` is a rolling summary for long-run decisions, not a full archive. To avoid repeatedly expanding long sequences after large screening batches, sequences in `recent_screen_records` and `recent_actions` are compacted to `sequence_length`, `sequence_prefix`, `sequence_suffix`, and `sequence_sha256`. Confirmable candidates still keep full sequences in `state.pending_confirmations` and `available_actions.confirm_hit`. The complete public screening record is written to final `results/screen_record_history.jsonl`.

Before confirmation, public history exposes only `observed_activity`. After confirmation, it also adds `confirmed_activity` and `noise_fraction`.

## 3. Library Screening-Pool Semantics

After a library is prepared, the agent sees its total screenable sequence count, screened count, and remaining count. After `mine_library`, the action response, refreshed `state.pending_confirmations`, `available_actions.confirm_hit`, and `history.recent_screen_records` show the public screening records produced by that batch.

Each library has a fixed-order screenable sequence pool. Construction rules:

1. outside `mutable_interval_aa`, the row sequence must match the owning seed's `start_sequence`
2. entries within one library are deterministically shuffled by `config.seed + library key`

Therefore:

- the same config and prepared data produce the same within-library order
- `mine_library` samples forward along that fixed order and does not backfill
- sequence confirmation activity affects reward, but does not directly reveal new seeds
- screening exposes noisy `observed_activity`, not final confirmed value

## 4. Action Families

### `prepare_seed`

Preconditions:

- the seed is visible
- the seed is not yet prepared

Effects:

- charges the cash and day cost of `prepare_seed`
- marks the seed as prepared
- makes libraries under that seed eligible for `prepare_library`

### `prepare_library`

Preconditions:

- the owning seed is visible
- the owning seed is prepared
- the library is currently `locked`

Effects:

- charges the cash and day cost of `prepare_library`
- marks the library as `prepared`
- if the library opens a downstream path, the action-response JSON field `newly_visible_seed_ids` and refreshed `visible_seed_ids` show the newly visible seeds
- from this step onward, that library's `screenable_sequence_count`, `screened_sequence_count`, and `remaining_screenable_sequence_count` appear in state

### `mine_library`

Preconditions:

- the owning seed is visible
- the owning seed is prepared
- the library is prepared
- `batch_size` must come exactly from current `batch_options`

Effects:

- charges cash and day cost for the selected `batch_option`
- samples one batch from the fixed-order sequence pool for that library
- writes each result into `screen_record_history`
- generates stable noisy `observed_activity` for each sequence
- updates `provisional_best_activity` and `provisional_best_sequence`
- if the batch contains a candidate above current `confirmed_best_activity`, a corresponding `screen_record_id` appears in `confirm_hit`
- `mine_library` itself does not directly pay reward
- if a prepared library has fewer remaining screenable sequences than the minimum batch size, it does not appear in `mine_library`; preparing that library may still have branch-unlock value

### `confirm_hit`

Preconditions:

- `screen_record_id` must appear in current `confirm_hit` candidates
- enough time remains for the confirmation action
- that `screen_record_id` has not already been confirmed

Effects:

- charges cash and day cost for `confirm_hit`
- marks the screening record as confirmed and reveals `confirmed_activity`
- if confirmed activity exceeds current `confirmed_best_activity`, updates:
  - `confirmed_best_activity`
  - `confirmed_best_sequence`
- pays reward according to reward tiers
- `confirm_hit` is per-candidate: each action confirms one current `screen_record_id`; confirmation cost is spent once started, and whether the candidate beats current best affects only reward and confirmed-best updates

### `purchase_skill`

Preconditions:

- `skill_id` must appear in current `purchase_skill` candidates
- enough time remains for the purchase action
- the skill is not already owned

Effects:

- charges the skill's fixed price and purchase time
- materializes full skill content under `owned_skills/<skill_id>/source/`
- the local content remains readable in later steps
- after purchase, the agent may call tools or workflows described by the skill and use analysis results in later decisions; tool use is not a legality requirement

### Forced Skill At Start

Some formal settings provide an owned skill at episode start:

- `initial_owned_skill_ids` lists skills owned at start
- `owned_skills_index.json` shows the skill before step 1
- full content is materialized directly under `owned_skills/<skill_id>/source/`
- this is not a `purchase_skill` action, does not charge skill price, and does not consume `purchase_skill_days`
- if `skill_market_enabled = false`, `skill_market.json.cards` is empty and `purchase_skill` is illegal
- forced skill means "the episode starts with this capability"; the agent may call it and use the result for decisions, but Fig. 5a does not require every run to produce a tool-backed artifact

### `stop`

Effects:

- ends the episode immediately
- `stop_reason` records the agent's reason or the system terminal reason

## 5. Reward And Cost

Every action has direct cost. Every elapsed day is also charged through `daily_burn_cost`.

Public presets use a `$` scale or equivalent budget units. Values are calibrated to realistic reagent, service, and opportunity-cost magnitudes, but benchmark settlement uses numeric values. In the current interpretation, `daily_burn_cost` is opportunity cost per elapsed day.

Current built-in action-level economics:

| Action | Direct cost | Days |
| --- | ---: | ---: |
| `prepare_seed` | `$365` | `3` |
| `prepare_library` | `$142` | `2` |
| `mine_library` | `$1200-$1400` | `9-10` |
| `confirm_hit` | `$467` | `12` |
| `purchase_skill` | market price | `1` |
| `stop` | `$0` | `0` |

Reward is paid only after `confirm_hit`, and only if the new confirmed activity exceeds current `confirmed_best_activity`. `provisional_best_activity` means a good candidate was seen during screening; it does not mean cash has been earned.

Reward is computed over `reward_tiers`:

```text
for each crossed tier segment [lower, upper]:
  reward += base_asset_value
            * baseline_activity
            * tier.multiplier
            * ((1 / lower) - (1 / upper))
```

Consequences:

- marginal improvements in higher tiers are usually more valuable
- seeing a strong hit in `mine_library` is not the same as earning reward
- confirmation decisions must consider reward increment, confirmation cost, and time burn

### Budget Closure

Low-budget TadA-Campaign settings do not ask the agent to explore as much as possible. They ask the agent to preserve enough cash and time to turn discoveries into confirmed best activity.

`state.economic_summary` exposes current economic state:

- `action_total_costs.confirm_hit`: total cash cost to confirm a pending hit, including `confirm_hit_days * daily_burn_cost`
- `configured_minimum_mine_then_confirm_total_cost`: minimum cash reserve for the cheapest screen plus one confirmation under current config; it does not include `prepare_seed` or `prepare_library` needed to reach a screenable library
- `configured_minimum_mine_then_confirm_days`: minimum day reserve for the cheapest screen plus one confirmation under current config
- `has_available_mine_option`: whether a prepared library can currently be screened
- `available_mine_then_confirm_total_cost` / `available_mine_then_confirm_days`: when a screenable library is already available, the minimum reserve to complete one screen plus one confirmation from the current state
- `cash_after_confirm_reserve` / `remaining_days_after_confirm_reserve`: cash and days left after reserving one confirmation now
- `budget_regime`: `can_mine_and_confirm`, `confirm_only`, `cash_below_confirm`, `time_below_confirm`, or `cash_and_time_below_confirm`

`available_actions.mine_library[*].batch_options[*]` also exposes post-screen confirmation-reserve fields:

- `cash_after_action_and_confirm_reserve`
- `remaining_days_after_action_and_confirm_reserve`
- `leaves_confirm_cash`
- `leaves_confirm_time`
- `leaves_confirm_capacity`

These fields do not change action legality; they are decision hints. A batch can be legal while leaving too little cash or time to confirm a new hit. In low-budget runs, prefer screen closures with `leaves_confirm_capacity = true`, or explicitly explain in `reasoning` why unconfirmable risk is accepted.

## 6. Terminal Conditions

An episode reaches terminal state in one of these cases:

- `max_experiment_days` is reached: `stop_code = "max_experiment_days"`
- remaining time is insufficient for any legal action: `stop_code = "time_insufficient"`
- no visible experimental path remains: `stop_code = "no_visible_path"`
- current cash is insufficient for any legal action: `stop_code = "cash_insufficient"`
- the agent submits `stop`: `stop_code = "agent_stop"`

If the runner force-stops the session because of agent/backend failure, `stop_code = "backend_error"` and `stop_reason` starts with `backend_error:`.

## 7. Skill Market

- `skill_market.json` provides only pre-purchase card information
- before purchase, the agent is isolated from full skill content
- after purchase, full content appears only under `owned_skills/<skill_id>/source/`
- skill pricing is one-time; there is no daily salary, dismissal, or refund
- forced-skill settings reuse the same skill package source, but close the market purchase surface; the agent sees only skills owned at start
- tool-backed skill use is optional decision support. The agent should use it when it can improve branch opening, mining, confirmation, purchase, or stop decisions; if used, save results under `skill_analysis/` and cite key findings in action `reasoning`

## 8. Result Files

When analyzing a run, start with:

1. `results/summary.json`
2. `results/action_log.jsonl`
3. `results/screen_record_history.jsonl`
4. `results/rejection_log.jsonl`
5. `results/judge_audit.jsonl`
6. `results/runtime_timeline.jsonl`

To understand why the agent stopped, inspect:

- `summary.json.stop_code`
- `summary.json.stop_reason`
- final `available_actions.json`
- final actions in `action_log.jsonl`
- `screen_record_history.jsonl` and `pending_confirmation_count`

To confirm noisy screening behavior, inspect:

- `screening_noise_enabled`, `screening_noise_sigma`, and `screening_noise_clip` in `state.json` / `summary.json`
- `observed_activity` during screening in `screen_record_history.jsonl`
- `confirmed_activity` and `noise_fraction` in `confirm_hit` records in `action_log.jsonl`
