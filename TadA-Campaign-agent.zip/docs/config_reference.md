# Config Reference

This repository keeps two public presets:

- `config/experiments/TadACampaign_v2_smoke.toml`
- `config/experiments/TadACampaign_v2_formal.toml`

The fixed public launch commands are:

```bash
bash scripts/run_TadACampaign_v2.sh smoke [output-root]
bash scripts/run_TadACampaign_v2.sh formal [output-root]
```

At run start, the runner writes the effective configuration snapshot to `config.toml` in the run directory. This snapshot resolves paths to absolute paths and adds the runtime judge URL.

If `TADACAMPAIGN_SKILL_MARKET_MANIFEST` is set, the public launch script injects that local skill-market manifest into the runtime configuration snapshot. For formal experiments, prefer writing the manifest into a per-setting TOML so that `setting.toml`, `config.toml`, and operator cards directly audit the skill condition.

For formal paper experiments, do not repeatedly edit the built-in formal preset. Generate a dedicated setting from the baseline template:

```bash
python3 scripts/create_formal_setting.py \
  --output runs/paper_main/fig3_budget/cash100000/setting.toml \
  --run-output-root runs/paper_main/fig3_budget/cash100000 \
  --name TadACampaign_v2_formal_fig3_budget_cash100000 \
  --initial-cash 100000.0 \
  --agent-backend codex

export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE="$PWD/runs/paper_main/fig3_budget/cash100000/setting.toml"
bash scripts/run_TadACampaign_v2.sh formal runs/paper_main/fig3_budget/cash100000
```

`TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` applies only to the `formal` preset. The public launch command stays the same, but each setting has its own source TOML. The final run directory stores `setting.toml`, `results/host_runtime/source-config.toml`, and runtime `config.toml`.

## Top-Level Fields

| Field | Required | Meaning |
| --- | --- | --- |
| `name` | yes | Run-name prefix. |
| `prepared_root` | yes | Prepared data directory. May be relative. |
| `variant` | yes | `dna` or `protein`. |
| `output_root` | yes | Default output root. |
| `seed` | yes | Random seed for hidden sequence ordering. |
| `initial_cash` | yes | Starting cash. |
| `base_asset_value` | yes | Asset base value used in the reward formula. |
| `baseline_activity` | yes | Activity baseline for reward tiers. |
| `screening_noise_enabled` | no | Whether screening noise is enabled; default `true`. |
| `screening_noise_sigma` | no | Standard deviation for relative screening error; default `0.10`. |
| `screening_noise_clip` | no | Clip bound for relative screening error; default `0.20`. |
| `prepare_seed_cost` | no | Direct cost for preparing one seed; default `0.0`. |
| `prepare_seed_days` | no | Days consumed by preparing one seed; default `0.0`. |
| `prepare_library_cost` | yes | Direct cost for preparing one library. |
| `prepare_library_days` | yes | Days consumed by preparing one library. |
| `confirm_hit_cost` | no | Direct cost for confirming one provisional hit; default `0.0`. |
| `confirm_hit_days` | no | Days consumed by confirming one provisional hit; default `0.0`. |
| `purchase_skill_days` | no | Days consumed by buying one skill; default `1.0`. |
| `daily_burn_cost` | yes | Opportunity cost per elapsed day. |
| `initial_visible_seeds` | yes | Initial visible seed list. |
| `initial_prepared_seeds` | yes | Initial prepared seed list. |
| `max_experiment_days` | yes | Fixed benchmark time horizon. |
| `agent_timeout_seconds` | no | Timeout for one backend attempt; default `300`. |
| `linear_issue` | no | Tracking metadata only. |

## Skill Market And Forced-Skill Fields

Skill-related fields may be placed at the top level or under `[judge]`. If a field appears in each location, `[judge]` wins. Formal paper settings should place them under `[judge]`.

| Field | Required | Meaning |
| --- | --- | --- |
| `skill_market_manifest` | no | Local skill-market manifest path. Supported for the Codex backend; other backends do not support this field. |
| `skill_market_enabled` | no | Whether to expose market cards and the `purchase_skill` action; default `true`. |
| `initial_owned_skill_ids` | no | Skill ids owned and materialized into the workspace at run start; requires `skill_market_manifest`. |

Main experiment semantics:

- Skill-market condition: set `skill_market_manifest`, keep `skill_market_enabled = true`, and use `initial_owned_skill_ids = []`. The agent may buy skills through `purchase_skill`; purchase charges the skill price plus `purchase_skill_days * daily_burn_cost`.
- Fig. 5a forced-skill condition: set `skill_market_manifest`, `skill_market_enabled = false`, and `initial_owned_skill_ids = ["<skill_id>"]`. The agent can read `owned_skills/<skill_id>/source/SKILL.md` from the start; market cards are empty, `purchase_skill` is unavailable, and no purchase price or purchase time is charged.

These fields only define whether a skill is visible, purchasable, or owned at start. They do not force the agent to run a tool and do not change action legality. After owning or buying a skill, the agent may follow the skill documentation, call tools or workflows, write optional analysis artifacts under `skill_analysis/`, and use concrete findings in later action `reasoning`.

## `[[reward_tiers]]`

Each reward tier provides:

- `min_activity`
- `max_activity`
- `multiplier`

Intervals must be continuous, non-overlapping, and cover all activity from `baseline_activity` upward. `max_activity` may be `"inf"`.

Reward is paid only when `confirm_hit` increases `confirmed_best_activity`. It is not a lookup on the new activity alone. It is computed by splitting the improvement from `previous_best_activity` to `new_best_activity` across crossed tier segments:

```text
for each crossed tier segment [lower, upper]:
  reward += base_asset_value
            * baseline_activity
            * tier.multiplier
            * ((1 / lower) - (1 / upper))
```

Thus `reward_tiers` define marginal value weights for activity intervals. If one confirmation crosses multiple tiers, each segment is computed with that tier's `multiplier` and then summed. `mine_library` produces only noisy provisional signal and does not directly pay reward.

Current public presets use empirically calibrated tiers:

- `[1.0, 1.314) -> x1.5`
- `[1.314, 3.78) -> x2.4`
- `[3.78, 7.44) -> x18.0`
- `[7.44, inf) -> x30.0`

## `[[mine_batch_menu]]`

Each discrete batch option provides:

- `batch_size`
- `cost`
- `time_days`

Constraints:

- `mine_batch_menu` must be nonempty
- `batch_size` must be a positive integer and must not repeat
- runtime sorts options by `batch_size`

Built-in presets use real-throughput semantics: `batch_size` is the number of screened variants, not the price. The current menu is `780`, `880`, `1020`, and `1280`.

## `[agent]`

Public agent configuration includes CLI-agent model-selection fields and the algorithmic policy fields needed for Fig. 2 policy baselines:

| Field | Meaning |
| --- | --- |
| `backend` | `codex`, `claude`, `opencode`, or `policy`; built-in presets default to `codex`. |
| `model` | Optional. |
| `profile` | Optional. |
| `reasoning_effort` | Optional. |
| `verbosity` | Optional. |
| `policy` | Required only when `backend = "policy"`; Fig. 2 defaults use `stop_now`, `blind_random_legal`, `budgeted_static_ranker`, `scout_confirm_stop`, `upside_greedy_explorer`, and `empirical_ev_planner`. |
| `policy_params` | Optional table; the policy backend supports parameters such as `max_steps`, `confirm_margin`, `max_exploration_spend`, `max_batches_per_library`, `max_scout_libraries`, `probe_batches_per_library`, `min_probe_libraries`, and `min_confirmed_activity_gain`. |

The `policy` backend is a pure Python algorithmic policy. It does not launch Codex, OpenCode, or Claude. It still submits actions through the same authoritative judge and `run_agent_step` path, so it produces normal `process/step_*`, `results/action_log.jsonl`, `results/summary.json`, and cash-curve artifacts. Non-oracle policies must remain semi-blind: they may use only the current public observation, legal actions, public history, and action responses that have actually occurred.

Other backend controls are not part of the public invocation surface.

## `[judge]`

The public judge configuration field is:

| Field | Meaning |
| --- | --- |
| `request_timeout_seconds` | Judge HTTP request timeout. |

Runtime-injected field:

- `server_url`

`server_url` is injected by the public launch script; do not fill it manually.

## Built-In Presets

The two built-in presets share the same economics and state semantics:

- `initial_cash = 100000.0`
- `base_asset_value = 100000.0`
- `baseline_activity = 1.0`
- `screening_noise_enabled = true`
- `screening_noise_sigma = 0.10`
- `screening_noise_clip = 0.20`
- `prepare_seed_cost = 365.0`
- `prepare_seed_days = 3.0`
- `prepare_library_cost = 142.0`
- `prepare_library_days = 2.0`
- `confirm_hit_cost = 467.0`
- `confirm_hit_days = 12.0`
- `purchase_skill_days = 1.0`
- `daily_burn_cost = 800.0`
- `mine_batch_menu = 780/880/1020/1280`

Cost fields use the `$` scale or equivalent budget units; runtime settlement uses numeric values.

Main differences:

| Item | `TadACampaign_v2_smoke` | `TadACampaign_v2_formal` |
| --- | --- | --- |
| `max_experiment_days` | `60.0` | `180.0` |
| `agent_timeout_seconds` | `1800` | `3600` |

Use `smoke` for pipeline preflight and `formal` for formal long-horizon experiments.
