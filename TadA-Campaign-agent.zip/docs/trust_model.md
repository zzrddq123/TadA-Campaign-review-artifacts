# Trust Model

TadA-Campaign supports one trust-boundary model:

- the host-side authoritative judge owns benchmark data and state authority
- the Docker-contained agent advances the experiment through the HTTP judge API
- the agent does not directly read prepared benchmark data

## 1. Host Judge

The host judge is responsible for:

- loading `prepared/` data
- creating and maintaining sessions
- validating action legality
- settling time, cost, reward, and terminal conditions
- exporting audit logs and final summaries

The judge is the only authoritative state source.

## 2. Docker Agent

The agent inside the Docker container can access current-run runtime material, including:

- repository code and runtime dependencies under `/app`
- `~/.codex/AGENTS.md`
- `agent_playbook.md`
- `state.json`
- `available_actions.json`
- `history.json`
- helper scripts
- current-run runtime staging
- current-run isolated output workspace

The agent should not and does not need to access:

- prepared parquet data
- host judge memory state
- historical run directories under the same `output_root`
- bypass runtime logic in repository source

## 3. Public Launch Script Responsibility

`scripts/run_TadACampaign_v2.sh` connects the two sides safely:

1. selects a public preset
2. starts the host judge
3. injects the runtime `server_url`
4. stages a safe CLI home for `[agent].backend`; for `codex`, it also stages `config/AGENTS.md` unchanged into container `~/.codex/AGENTS.md`
5. creates an isolated staging output directory for the current run
6. starts the Docker agent
7. publishes the current run's final artifacts back to the requested `output_root`

This is the only supported public runtime path in the repository.

## 4. Security Benefits

This fixed model addresses the main safety issues:

- the agent cannot bypass the judge by reading host benchmark data files
- judge-side state evolution is fully auditable
- results do not depend on alternate execution models
- docs, scripts, tests, and configs all point to the same execution path, so operators do not mistake internal implementation paths for equivalent public entry points
