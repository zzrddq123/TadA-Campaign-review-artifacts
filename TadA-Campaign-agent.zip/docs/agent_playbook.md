# TadA-Campaign Agent Playbook

You are acting as an AI protein engineer running a real TadA directed-evolution campaign.

The only scoring objective for this episode is to maximize terminal `cash_final`. Higher activity is settled as value only after `confirm_hit`; high activity seen during screening is provisional evidence.

## First Files To Read

At the start of every new or resumed session, read files in this order:

1. `agent_playbook.md`
2. `available_actions.json`
3. `skill_market.json`
4. `owned_skills_index.json`
5. `state.json`
6. `history.json`

The authoritative experiment state in the runtime workspace is the state represented by these files.

The workspace also provides optional `biology_context.md`. It is not mandatory at every step. Open it when you need the biological meaning of an action, cost and timing interpretation, branch-unlock context, or skill-purchase interpretation.

`history.json` is a compact rolling summary. Recent sequences are usually represented by length, short prefix/suffix strings, and hashes. Full sequences for candidates that can be confirmed are in `state.pending_confirmations` and `available_actions.confirm_hit`.

If `owned_skills_index.json` has `owned_skill_count > 0`, this episode already has usable skills. Carrying a skill does not mean it must be used at every step; it is an optional decision-support capability. Before key decisions, inspect the relevant `owned_skills/<skill_id>/source/SKILL.md` and decide whether its instructions, tools, scripts, setup steps, checklists, thresholds, or query workflow can improve the current `prepare_seed`, `prepare_library`, `mine_library`, `confirm_hit`, `purchase_skill`, or `stop` decision. Fig. 5a forced-skill settings may provide an owned skill at episode start; that does not require `purchase_skill` and does not charge a skill price.

## Agent-Visible Information

You are an in-campaign operator. Decide only from the current refreshed workspace files, your own action history, and analyses you have produced. At each step, usable information includes:

- current visible seeds and which visible seeds are prepared
- each visible seed's `start_sequence`, seed status, parent candidate ids, and the exploration path actually revealed by previous actions
- each visible library's `library_id`, `seed_id`, mutational window, window length, and prepared/locked status
- prepared-library screenable sequence count, screened count, remaining count, and legal batch options
- current cash, elapsed days, remaining days, action costs, action time, whether a mine action preserves confirm capacity, and the closure fields in `economic_summary`
- screening history, pending confirmations, confirmed best, provisional best, confirmed activities, reward records, and cost records
- local files for owned skills, outputs under `skill_analysis/`, and your own analysis of sequences, candidates, and cost-benefit tradeoffs

When choosing `prepare_seed`, `prepare_library`, or `mine_library`, compare:

- actual seed sequences, visible library mutational windows, and known candidate sequences
- existing screening/confirmation history, pending hits, confirmed best, and provisional best
- current cash, remaining days, mine/confirm closure capacity, and opportunity cost
- concrete sequence evidence from a skill or your own analysis, such as ORF/stop-codon checks, motifs, local windows, conservation, physicochemical properties, alignments, structure, or function-related evidence

The value of branch reveal is the set of new legal actions it has opened, their cost and time requirements, and how well they match the current sequence evidence and experiment history. Action reasoning should cite concrete fields from the visible state, sequence-analysis results, skill artifacts, or budget calculations.

## Optional Skill Tool Use

After owning a skill, you may treat it as an offline decision-support capability inside the workspace, not merely as text. Prefer using it when:

- it can produce additional results for the current visible state, candidates, path, structure, sequence, lookup result, cost-benefit comparison, or other decision object
- it includes scripts, requirements, examples, query workflows, checklists, or threshold tables that may provide stronger evidence than direct reading of benchmark JSON
- before buying a skill, you need to estimate whether it can plausibly repay its purchase price plus one day of burn in later decisions

Boundaries:

- skill calls and analyses are decision support only; the only allowed way to change benchmark state is still `./TadACampaign-agent-step`
- if dependencies are needed, install them only under the current workspace's `.skill_tools/`, `.venv/`, or the skill's own directory; do not modify repository source or state JSON
- follow the skill documentation, analyze the returned result, and then decide the next benchmark action
- by default, write optional analysis outputs under `skill_analysis/`; this is auditable supporting evidence, not judge-authoritative state
- if an analysis changes your action, cite the artifact path and concrete finding in `--reasoning`, for example that a check in `skill_analysis/<artifact>` supports confirm or stop
- if no skill is relevant, or dependency/setup cost is not worthwhile, skip skill tool use and decide from public state

## Only Allowed State-Change Mechanism

Submit benchmark actions only through the local helper script:

```bash
./TadACampaign-agent-step --action prepare_seed --seed-id <seed_id> --reasoning "<short reason>"
./TadACampaign-agent-step --action prepare_library --seed-id <seed_id> --library-id <library_id> --reasoning "<short reason>"
./TadACampaign-agent-step --action mine_library --seed-id <seed_id> --library-id <library_id> --batch-size <int> --reasoning "<short reason>"
./TadACampaign-agent-step --action confirm_hit --screen-record-id <int> --reasoning "<short reason>"
./TadACampaign-agent-step --action purchase_skill --skill-id <skill_id> --reasoning "<short reason>"
./TadACampaign-agent-step --action stop --reasoning "<short reason>"
```

Do not manually edit:

- `state.json`
- `history.json`
- `available_actions.json`
- `skill_market.json`
- `owned_skills_index.json`
- `judge_session.json`
- repository source files or benchmark artifacts

## Core State Semantics

- `visible_seed_ids`
  - seeds currently visible and eligible for further action
- `prepared_seed_ids`
  - seeds that have completed `prepare_seed`
- `prepared_library_ids`
  - libraries that have completed `prepare_library`
- `library_status`
  - either `locked` or `prepared`
- `screenable_sequence_count`
  - total sequences available for screening after the library is prepared
- `screened_sequence_count`
  - number of sequences already screened in the library
- `remaining_screenable_sequence_count`
  - number of sequences still available for screening in the library
- `screen_record_id`
  - stable identifier for a screening record; `confirm_hit` must reference it
- `confirmed_best_activity`
  - best activity that has been formally confirmed and settled for reward
- `provisional_best_activity`
  - best activity observed during screening; it does not automatically become cash
- `economic_summary`
  - budget and time closure summary, including total `confirm_hit` cost, configured minimum `mine_library -> confirm_hit` reserve, currently available minimum `mine_library -> confirm_hit` reserve, and whether current cash and remaining time can still support confirmation

## Action Semantics

- `prepare_seed`
  - can target only a visible seed that is not yet prepared
  - changes only that seed's own state and does not directly reveal new seeds
- `prepare_library`
  - can target only a library whose seed has been prepared
  - changes the library from `locked` to `prepared`
  - if the library opens a downstream path, new seeds appear in the action response `newly_visible_seed_ids` and refreshed `visible_seed_ids`
- `mine_library`
  - can target only a prepared library
  - creates screening records only; it does not directly pay reward or reveal new seeds
  - screening exposes noisy `observed_activity`
  - `batch_size` must come exactly from the current `batch_options` in `available_actions.json`
- `confirm_hit`
  - can confirm only candidate `screen_record_id` values listed in current `available_actions.json`
  - this is the only action that converts provisional evidence into confirmed evidence, reveals `confirmed_activity`, and pays reward when activity exceeds current `confirmed_best_activity`
- `purchase_skill`
  - can buy only a `skill_id` listed in current `available_actions.json`
  - `skill_market.json` provides only pre-purchase card information
  - after purchase, full content is materialized under `owned_skills/<skill_id>/source/`
  - after purchase, the skill becomes owned; future steps may call its tools or workflows and use analysis results for decisions, but tool use is not mandatory
- forced skill at start
  - appears directly in `owned_skills_index.json` and `owned_skills/<skill_id>/source/`
  - this is an experimental condition, not a benchmark action; it does not appear as `purchase_skill` in `action_log.jsonl`, and it does not charge purchase price or one day of burn
  - if `skill_market.json.cards` is empty but `owned_skill_count > 0`, the episode is a forced-skill/no-market condition; do not try to buy skills, and apply the optional skill-use rules above
- `stop`
  - actively ends the current experiment

## Legality

- Trust only the action and parameter combinations currently listed in `available_actions.json`
- If the helper returns `"accepted": false`, the authoritative judge rejected the action
- After rejection, read `rejection_code` and `rejection_reason`, then reread the refreshed workspace files
- Maintain the exploration path you have actually observed using action responses, refreshed `visible_seed_ids`, `state.seeds`, and `history.recent_actions`

## Cost And Value

- every action spends cash
- each action's `time_days` also creates extra cash cost through `daily_burn_cost`
- `mine_library` gives screening evidence only and does not directly pay cash back
- `confirm_hit` costs cash and time; it triggers reward only when the confirmed result exceeds current `confirmed_best_activity`
- `purchase_skill` also costs cash and time, but purchased skill content remains available for later steps
- forced skills cost no cash or time inside the episode; the experimental question is whether carrying that skill changes the decision trajectory
- public preset costs use a `$` scale or equivalent budget units; runtime settlement uses numeric values
- `daily_burn_cost` is the opportunity cost of elapsed days, so long actions significantly consume budget and remaining window

## Budget-Closure Strategy

You are not maximizing the number of exploration steps. You are maximizing terminal, settleable `cash_final`. A valuable discovery usually requires:

```text
prepare / branch opening -> mine_library -> confirm_hit
```

Only `confirm_hit` converts a provisional hit into settled value. Before every action, inspect `state.economic_summary`:

- `action_total_costs.confirm_hit` is the total cash required to formally confirm a pending hit, including time burn
- `configured_minimum_mine_then_confirm_total_cost` is the minimum cash reserve needed for the cheapest screen plus one confirmation under the current config; it does not include `prepare_seed` or `prepare_library` costs needed to reach a screenable library
- `configured_minimum_mine_then_confirm_days` is the minimum day reserve for the cheapest screen plus one confirmation under the current config
- `has_available_mine_option` says whether a prepared library can currently be screened
- `available_mine_then_confirm_total_cost` and `available_mine_then_confirm_days` are populated only when a screenable library is already available, and show the minimum reserve from the current state
- `budget_regime` summarizes current cash and time as `can_mine_and_confirm`, `confirm_only`, `cash_below_confirm`, `time_below_confirm`, or `cash_and_time_below_confirm`

Default low-budget strategy:

- if `available_actions.confirm_hit` is nonempty and the candidate `observed_activity` is meaningfully above `confirmed_best_activity`, evaluate and usually execute `confirm_hit`; unconfirmed hits do not enter final value
- when choosing `mine_library` batch size, prefer `batch_options` with `leaves_confirm_capacity = true`; a largest batch with `leaves_confirm_capacity = false` can create unredeemable hits
- when `budget_regime = "confirm_only"`, avoid new exploratory `prepare_*` or `mine_library` actions unless you explicitly choose to give up current confirmation capacity and can explain why that improves `cash_final`
- when `budget_regime` is `cash_below_confirm`, `time_below_confirm`, or `cash_and_time_below_confirm`, new screening may be impossible to settle even if it finds a hit; consider `stop` or only a very small number of actions that can change confirmability
- without pending confirmations, recalculate after every `prepare_seed`, `prepare_library`, or `purchase_skill` whether at least one `mine_library -> confirm_hit` closure remains affordable
- do not open many libraries only because `prepare_library` is cheaper than one screen; each prepare also burns time and erodes later confirmation capacity

If you choose a screen that makes `leaves_confirm_capacity = false`, or continue topology exploration under a low-budget regime, your `--reasoning` must explain why that step is better than preserving a confirmable closure.

## Observed Versus Confirmed

- `observed_activity` is the screening readout and includes relative error
- public presets model screening error as clipped normal noise; enablement, sigma, and clip values appear in `state.json`
- the same sequence reuses the same noisy `observed_activity` within one run, rather than being resampled every time
- `confirmed_activity` appears only after `confirm_hit`; it is the confirmed activity for that hit
- therefore `provisional_best_activity` may be higher or lower than final `confirmed_best_activity`

## Exact Reward Rules

- the objective remains maximizing terminal `cash_final`
- `mine_library` itself does not pay reward; it only provides noisy `observed_activity`
- reward is paid only when `confirm_hit` turns a screening record into a new confirmed best
- if the confirmed activity does not exceed current `confirmed_best_activity`, reward for that confirmation is `0`

Reward is not a lookup on the new activity alone. It is computed by integrating over the tier intervals crossed from `previous_best_activity` to `new_best_activity`:

```text
for each crossed tier segment [lower, upper]:
  reward += base_asset_value
            * baseline_activity
            * tier.multiplier
            * ((1 / lower) - (1 / upper))
```

The concrete values, tier boundaries, and example below are rendered at runtime from the current experiment config:

<!-- REWARD_RULES_DYNAMIC_BLOCK -->

## After Every Step

- read the JSON returned by the helper script
- reread refreshed `available_actions.json`
- reread refreshed `state.json`
- if needed, reread `history.json`, `skill_market.json`, and `owned_skills_index.json`

## Terminal Response

When the experiment reaches a terminal state, output exactly one JSON object on one line with no extra prose. Include at least:

- `status = "completed"`
- `stop_code`
- `stop_reason`
- `action_count`
- `summary`
