# TadA-Campaign Formal Experiment Prompts

This document is an operator manual for running paper-style formal experiments in the current review-artifact checkout. Copy one setting prompt into a new Codex window, and the agent should run that setting as five serial formal repeats. Each repeat uses its own replay seed, `setting.toml`, output root, and `tmux` session. Run one seed at a time; after the current seed finishes and operator outputs are written, start the next seed.

The current workflow does not use a separate worktree per setting and does not repeatedly edit `config/experiments/TadACampaign_v2_formal.toml`. Every formal setting is generated from the same baseline template into an independent `setting.toml`, then run through the same public entry point. The final run directory preserves the setting file so later experiments cannot inherit prior parameters silently.

## One-Pass Workflow

1. Open Codex at the repository root.
2. Copy one setting prompt from this document.
3. Paste it into Codex.
4. Use canonical repeat seeds `601`, `602`, `603`, `604`, and `605`.
5. For each seed, call `scripts/create_formal_setting.py --seed <SEED>` to generate `<output-root>/seed<SEED>/setting.toml` from `templates/TadACampaign_v2_formal_baseline.toml`.
6. For the current seed, set `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE=<output-root>/seed<SEED>/setting.toml` and start `bash scripts/run_TadACampaign_v2.sh formal <output-root>/seed<SEED>` inside `tmux`.
7. Monitor the current seed's `tmux` session until it ends, find the run directory, read the results, and write `EXPERIMENT_CARD.md`, `results/operator_summary.md`, `results/operator_event_log.csv`, and `results/operator_run_summary.csv`.
8. Run seeds `601` through `605` serially. Do not start the next seed until the previous seed is complete and operator outputs are saved.
9. Each seed run directory stores that seed's `setting.toml`, runtime `config.toml`, process records, and result files.

## Public Entry Point

The repository supports one public formal entry point:

```bash
bash scripts/run_TadACampaign_v2.sh formal [output-root]
```

Do not call internal runners directly, do not add bypass launch scripts, and do not create a new worktree for these setting runs. Each formal setting still uses the `formal` preset; before launch, point `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` at the independently generated `setting.toml`.

## Baseline Setting Template

The formal paper baseline template is fixed:

```text
templates/TadACampaign_v2_formal_baseline.toml
```

Each setting repeat generates:

```text
<output-root>/seed<SEED>/setting.toml
```

Command template:

```bash
SEED="<SEED>"
SEED_OUTPUT_ROOT="<OUTPUT_ROOT>/seed${SEED}"
mkdir -p "$SEED_OUTPUT_ROOT"
python3 scripts/create_formal_setting.py \
  --output "$SEED_OUTPUT_ROOT/setting.toml" \
  --run-output-root "$SEED_OUTPUT_ROOT" \
  --name "<RUN_NAME>_seed${SEED}" \
  --seed "$SEED" \
  --initial-cash "<INITIAL_CASH>" \
  --agent-backend "<BACKEND>" \
  [--agent-model "<MODEL>"] \
  [--agent-reasoning-effort "<REASONING_EFFORT>"]
```

Rules:

- `templates/TadACampaign_v2_formal_baseline.toml` is the baseline source of truth.
- Do not edit `config/experiments/TadACampaign_v2_formal.toml` for paper settings; it remains the built-in public preset.
- `scripts/create_formal_setting.py` is only for generating per-setting/per-seed TOML. It writes the current checkout's `prepared_root` and the repeat's `output_root` as absolute paths so settings under `runs/` do not resolve relative paths incorrectly.
- Paper setting prompts should pass `--seed` and run canonical five-seed repeats. Omit `--seed` only for debugging, preflight, or explicit single-run requests.
- If a setting's `model`, `reasoning_effort`, `profile`, or `verbosity` is `OMIT`, do not pass that argument. The generator keeps those non-default fields out of `[agent]`.
- Before launch, set `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` to the current `<output-root>/seed<SEED>/setting.toml`. The variable applies only to the `formal` preset.

Each seed repeat preserves four configuration records:

```text
<output-root>/seed<SEED>/setting.toml
<run-dir>/setting.toml
<run-dir>/results/host_runtime/source-config.toml
<run-dir>/config.toml
```

Together, these files preserve the setting used to play the benchmark even after other settings are generated later.

## Experiment Set

Main paper experiments use a decision-cash trajectory plot: x-axis is simulated day, y-axis is cash, and markers show `prepare_seed`, `prepare_library`, `mine_library`, `confirm_hit`, `purchase_skill`, and `stop`.

| Figure | Theme | Independent variable | Settings | Main dependent variable | Controls | Purpose |
| --- | --- | --- | --- | --- | --- | --- |
| Fig. 2 | Construct validity of semi-blind policy baselines | algorithmic policy | Stop Now / Random Legal / Budgeted Static Ranker / Scout Confirm Stop / Upside Greedy Explorer / Empirical EV Planner | capital-adjusted profit = `cash_final - initial_cash` | policy backend; initial cash 100k; no skill; no market; same semi-blind observation interface; matched five-seed repeats; same costs/noise/reward | Test whether the benchmark separates scientific operating policies without LLM decision-making. |
| Fig. 3 | Budget effect on agent behavior | starting capital | 30k / 50k / 75k / 100k / 150k / 200k / 300k / 500k / 700k | cash trajectory | Codex; no skill; no market; matched five-seed repeats; same costs/noise/reward | Test whether budget changes behavior: entering screening, preserving confirmation capacity, and stopping time. |
| Fig. 4 | Agent effect on decision behavior | agent type | Codex and OpenCode model variants listed below | cash trajectory | initial cash 100k; no skill; no market; matched five-seed repeats; same costs/noise/reward | Compare when different agents prepare, mine, confirm, and stop. |
| Fig. 5a | Single-skill effect on agent behavior | one forced owned BioSkill at start | No skill / 12 review-screened CPU-local BioSkills | cash trajectory; tool-backed skill artifact; whether action reasoning cites skill results | Codex; initial cash 100k; market purchase surface off; no prompt append; one forced owned skill at a time; matched five-seed repeats | Identify which TadA-relevant BioSkills change downstream experimental strategy. |
| Fig. 5b | Skill-market effect on agent behavior | skill-market setting | No market / 12-BioSkills neutral market / 12-BioSkills marketing market | cash trajectory; purchase timing | Codex; initial cash 100k; same 12-BioSkills pool; same price; matched five-seed repeats | Test whether the agent buys BioSkills, when it buys them, and whether purchase changes later decisions. |

## Output-Root Convention

All formal paper runs go under:

```text
runs/paper_main/
```

Directory convention:

```text
runs/paper_main/
  fig2_construct_validity/
  fig3_budget/
  fig4_agent/
  fig5a_single_skill/
  fig5b_skill_market/
```

Each setting directory contains `seed601/`, `seed602/`, `seed603/`, `seed604/`, and `seed605/`, each with its own generated `setting.toml`, `tmux.log`, run directory, and operator outputs.

## Single-Run Result Structure

Each run directory should contain:

```text
<run-dir>/
  setting.toml
  config.toml
  process/
  results/
  EXPERIMENT_CARD.md
```

Important result files:

- `results/summary.json`
- `results/summary.md`
- `results/action_log.jsonl`
- `results/screen_record_history.jsonl`
- `results/rejection_log.jsonl`
- `results/judge_audit.jsonl`
- `results/runtime_timeline.jsonl`
- `results/cash_curve.csv`
- `results/cash_curve.png`
- `results/operator_summary.md`
- `results/operator_event_log.csv`
- `results/operator_run_summary.csv`

## Pre-Run Setup

Prepare data if needed:

```bash
uv run TadACampaign prepare-data --zip-path data/review-data.zip --output-dir prepared
```

The prepared data must be created in the same checkout used for the run.

For long formal runs, use `tmux`. Any command or experiment expected to exceed three minutes should be managed by `tmux`.

## Copyable Prompt Index

Recommended usage: copy one complete sentence below into a new Codex window. The new Codex instance should read this document, find the row by `setting_id`, and run canonical serial five-seed repeats for seeds `601`, `602`, `603`, `604`, and `605`.

Template:

```text
Please read docs/formal_experiment_prompts.md and run the formal setting with setting_id=<SETTING_ID> as serial five-seed repeats using canonical seeds 601, 602, 603, 604, and 605. Use the output_root, tmux session, setting-generation scope, and operator-output script specified in that document.
```

Single-run debug template:

```text
Please read docs/formal_experiment_prompts.md and run setting_id=<SETTING_ID> as one single-run formal debug episode. Do not run canonical five-seed repeats. Use the setting's base output_root, base tmux session, and the baseline default seed.
```

## Key Runtime Constraints

- Do not create or switch worktrees.
- Do not edit built-in preset files for paper settings.
- Do not call internal runners.
- Do not add public launch paths.
- No-skill and Fig. 5a forced-skill runs must unset `TADACAMPAIGN_AGENT_PROMPT_APPEND`; Fig. 5a must use actual skill files rather than prompt text as a substitute.
- For skill-market settings, write the manifest into `setting.toml` and do not rely on `TADACAMPAIGN_SKILL_MARKET_MANIFEST` as the only evidence.

## Current Formal Defaults

| Field | Value |
| --- | --- |
| `variant` | `dna` |
| `seed` | `20260329` |
| `initial_cash` | setting-specific |
| `base_asset_value` | `100000.0` |
| `baseline_activity` | `1.0` |
| `max_experiment_days` | `180.0` |
| `daily_burn_cost` | `800.0` |
| `prepare_seed_cost` / `prepare_seed_days` | `365.0` / `3.0` |
| `prepare_library_cost` / `prepare_library_days` | `142.0` / `2.0` |
| `confirm_hit_cost` / `confirm_hit_days` | `467.0` / `12.0` |
| `purchase_skill_days` | `1.0` |
| `mine_batch_menu` | `780` / `880` / `1020` / `1280` |
| screening noise | enabled, sigma `0.10`, clip `0.20` |

If a prompt contains an old horizon or old batch size, trust `templates/TadACampaign_v2_formal_baseline.toml` and do not change the horizon, costs, or batch menu.

## Publication Repeat Seeds

Formal paper repeats use this shared seed set:

```text
601
602
603
604
605
```

These are fixed repeat identifiers, not date seeds.

Rules:

- A formal setting without `--seed` uses baseline default `20260329`; that is appropriate for debugging, preflight, and single-instance reproduction.
- Main repeated evaluation uses the five seeds above; all compared methods, budgets, agents, and skill conditions must use the same seed set.
- Do not create permanent per-seed config files under `config/experiments/`. Generate `<seed_output_root>/setting.toml` with `scripts/create_formal_setting.py --seed <SEED>` and pass it through `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE`.
- `operator_event_log.csv` and `operator_run_summary.csv` record `replay_seed`, enabling matched comparisons by `setting_id` and `replay_seed`.

## tmux Launch And Completion

Recommended launch pattern:

```bash
SEED="<SEED>"
SEED_OUTPUT_ROOT="<OUTPUT_ROOT>/seed${SEED}"
mkdir -p "$SEED_OUTPUT_ROOT"
python3 scripts/create_formal_setting.py \
  --output "$SEED_OUTPUT_ROOT/setting.toml" \
  --run-output-root "$SEED_OUTPUT_ROOT" \
  --name "<RUN_NAME>_seed${SEED}" \
  --seed "$SEED" \
  --initial-cash "<INITIAL_CASH>" \
  --agent-backend "<BACKEND>"

SETTING_CONFIG="$(python3 -c 'from pathlib import Path; import sys; print(Path(sys.argv[1]).resolve())' "$SEED_OUTPUT_ROOT/setting.toml")"
tmux new-session -d -s "<TMUX_SESSION>_s<SEED>" \
  "cd '$PWD' && unset TADACAMPAIGN_SKILL_MARKET_MANIFEST && unset TADACAMPAIGN_AGENT_PROMPT_APPEND && export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE='$SETTING_CONFIG' && bash scripts/run_TadACampaign_v2.sh formal '$SEED_OUTPUT_ROOT' 2>&1 | tee '$SEED_OUTPUT_ROOT/tmux.log'"
```

If the setting needs a model or reasoning effort, add `--agent-model "<MODEL>"` or `--agent-reasoning-effort "<REASONING_EFFORT>"`. If the field is `OMIT`, do not pass it.

If the setting needs a forced skill or skill market, add the setting's `--skill-market-manifest`, `--skill-market-enabled/--no-skill-market-enabled`, and `--initial-owned-skill-id` arguments to each seed's `create_formal_setting.py` command. The `tmux` command should still unset `TADACAMPAIGN_SKILL_MARKET_MANIFEST` so the seed-specific `setting.toml` is the only configuration evidence.

Monitor:

```bash
tmux has-session -t "<TMUX_SESSION>_s<SEED>" 2>/dev/null && echo running || echo finished
tmux capture-pane -pt "<TMUX_SESSION>_s<SEED>" -S -120
```

Find the final run directory:

```bash
RUN_DIR="$(find "$SEED_OUTPUT_ROOT" -maxdepth 1 -mindepth 1 -type d -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-)"
test -f "$RUN_DIR/results/summary.json"
test -f "$RUN_DIR/results/action_log.jsonl"
```

## Serial Five-Seed Procedure

For one setting's five independent repeats:

1. Work directly in the current checkout.
2. Ensure `prepared/manifest.json` exists, or run data preparation first.
3. Generate five seed-specific `setting.toml` files using seeds `601` to `605`.
4. Keep all formal defaults unchanged except the setting's listed fields.
5. If model or reasoning effort is `OMIT`, do not keep that field in `[agent]`.
6. If a manifest is required, pass it to `create_formal_setting.py`; forced-skill settings also pass `--no-skill-market-enabled --initial-owned-skill-id "<forced_skill_id>"`.
7. Launch one seed at a time in `tmux`, with `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` pointing to that seed's setting.
8. Before launching, report the checkout path, five seeds, seed-specific names, tmux sessions, seed output roots, and the purpose of the setting.
9. Monitor the current seed until completion, find `RUN_DIR`, write operator outputs, then proceed to the next seed.
10. For every `RUN_DIR`, read `results/summary.json` and `results/action_log.jsonl`.
11. Call `scripts/write_TadACampaign_operator_outputs.py` for each `RUN_DIR`, passing the setting fields and seed output root.
12. Final response should summarize the five absolute `RUN_DIR` paths, five replay seeds, each seed's `confirmed_best_activity`, `cash_final`, `stop_reason`, and `operator_summary.md` path.

## Operator Output Script

Use:

```bash
python3 scripts/write_TadACampaign_operator_outputs.py \
  --run-dir "$RUN_DIR" \
  --figure-id "<FIGURE_ID>" \
  --experiment-theme "<EXPERIMENT_THEME>" \
  --setting-id "<SETTING_ID>" \
  --setting-name "<SETTING_NAME>" \
  --agent-name "<AGENT_NAME>" \
  --initial-cash "<INITIAL_CASH>" \
  --independent-variable "<INDEPENDENT_VARIABLE>" \
  --control-variables "<CONTROL_VARIABLES>" \
  --purpose "<PURPOSE>" \
  --output-root "$SEED_OUTPUT_ROOT" \
  --skill-condition "<SKILL_CONDITION>" \
  --market-condition "<MARKET_CONDITION>" \
  --prompt-append-mode "<PROMPT_APPEND_MODE>" \
  --manifest-path "<MANIFEST_PATH>"
```

The script writes:

- `EXPERIMENT_CARD.md`
- `results/operator_summary.md`
- `results/operator_event_log.csv`
- `results/operator_run_summary.csv`

## Fig. 2: Construct Validity Policy Baselines

Fixed conditions:

- backend: `policy`
- initial cash: `100000.0`
- skill market: off
- prompt append: off
- replay seeds, costs, noise, and reward: canonical five-seed repeats with formal defaults
- information boundary: semi-blind; the policy uses only current judge observation, current legal actions, public history, and action responses that have actually occurred
- forbidden for policy logic: prepared manifest, hidden topology, hidden true activity, and treating seed/library numeric suffixes as value or depth signals
- metric: `profit = cash_final - initial_cash`

| Setting ID | Policy | `[agent].policy` | `name` | tmux prefix | output_root |
| --- | --- | --- | --- | --- | --- |
| `fig2_construct_validity_stop_now` | Stop Now | `stop_now` | `TadACampaign_v2_formal_fig2_construct_validity_stop_now_cash100000` | `TadACampaign_fig2_stop_now` | `runs/paper_main/fig2_construct_validity/stop_now` |
| `fig2_construct_validity_random_legal` | Random Legal | `blind_random_legal` | `TadACampaign_v2_formal_fig2_construct_validity_blind_random_legal_cash100000` | `TadACampaign_fig2_blind_random_legal` | `runs/paper_main/fig2_construct_validity/blind_random_legal` |
| `fig2_construct_validity_budgeted_static_ranker` | Budgeted Static Ranker | `budgeted_static_ranker` | `TadACampaign_v2_formal_fig2_construct_validity_budgeted_static_ranker_cash100000` | `TadACampaign_fig2_budgeted_static_ranker` | `runs/paper_main/fig2_construct_validity/budgeted_static_ranker` |
| `fig2_construct_validity_scout_confirm_stop` | Scout Confirm Stop | `scout_confirm_stop` | `TadACampaign_v2_formal_fig2_construct_validity_scout_confirm_stop_cash100000` | `TadACampaign_fig2_scout_confirm_stop` | `runs/paper_main/fig2_construct_validity/scout_confirm_stop` |
| `fig2_construct_validity_upside_greedy_explorer` | Upside Greedy Explorer | `upside_greedy_explorer` | `TadACampaign_v2_formal_fig2_construct_validity_upside_greedy_explorer_cash100000` | `TadACampaign_fig2_upside_greedy_explorer` | `runs/paper_main/fig2_construct_validity/upside_greedy_explorer` |
| `fig2_construct_validity_empirical_ev_planner` | Empirical EV Planner | `empirical_ev_planner` | `TadACampaign_v2_formal_fig2_construct_validity_empirical_ev_planner_cash100000` | `TadACampaign_fig2_empirical_ev_planner` | `runs/paper_main/fig2_construct_validity/empirical_ev_planner` |

Policy definitions:

- `stop_now`: stop immediately; cash-preservation lower bound.
- `blind_random_legal`: randomly choose among current legal actions using only public observation.
- `budgeted_static_ranker`: use a fixed semi-blind action ranking with budget guards.
- `scout_confirm_stop`: scout, confirm plausible improvements, then stop when closure is no longer credible.
- `upside_greedy_explorer`: pursue upside while preserving confirmation when possible.
- `empirical_ev_planner`: estimate expected value from public evidence and action costs.

The Fig. 2 policy baselines can be launched directly with `scripts/run_construct_validity_baselines.py` or reproduced manually with per-setting `backend = "policy"` settings generated through `scripts/create_formal_setting.py`.

## Fig. 3: Budget Effect

Fixed conditions:

- backend: `codex`
- skill condition: no skill
- market condition: no market
- replay seeds, costs, noise, and reward: canonical five-seed repeats with formal defaults

| Setting ID | Initial cash | `name` | tmux prefix | output_root |
| --- | ---: | --- | --- | --- |
| `fig3_budget_cash30000` | `30000.0` | `TadACampaign_v2_formal_fig3_budget_cash30000` | `TadACampaign_fig3_cash30000` | `runs/paper_main/fig3_budget/cash30000` |
| `fig3_budget_cash50000` | `50000.0` | `TadACampaign_v2_formal_fig3_budget_cash50000` | `TadACampaign_fig3_cash50000` | `runs/paper_main/fig3_budget/cash50000` |
| `fig3_budget_cash75000` | `75000.0` | `TadACampaign_v2_formal_fig3_budget_cash75000` | `TadACampaign_fig3_cash75000` | `runs/paper_main/fig3_budget/cash75000` |
| `fig3_budget_cash100000` | `100000.0` | `TadACampaign_v2_formal_fig3_budget_cash100000` | `TadACampaign_fig3_cash100000` | `runs/paper_main/fig3_budget/cash100000` |
| `fig3_budget_cash150000` | `150000.0` | `TadACampaign_v2_formal_fig3_budget_cash150000` | `TadACampaign_fig3_cash150000` | `runs/paper_main/fig3_budget/cash150000` |
| `fig3_budget_cash200000` | `200000.0` | `TadACampaign_v2_formal_fig3_budget_cash200000` | `TadACampaign_fig3_cash200000` | `runs/paper_main/fig3_budget/cash200000` |
| `fig3_budget_cash300000` | `300000.0` | `TadACampaign_v2_formal_fig3_budget_cash300000` | `TadACampaign_fig3_cash300000` | `runs/paper_main/fig3_budget/cash300000` |
| `fig3_budget_cash500000` | `500000.0` | `TadACampaign_v2_formal_fig3_budget_cash500000` | `TadACampaign_fig3_cash500000` | `runs/paper_main/fig3_budget/cash500000` |
| `fig3_budget_cash700000` | `700000.0` | `TadACampaign_v2_formal_fig3_budget_cash700000` | `TadACampaign_fig3_cash700000` | `runs/paper_main/fig3_budget/cash700000` |

Copyable prompt:

```text
Please read docs/formal_experiment_prompts.md and run the Fig. 3 budget-effect formal setting with setting_id=<SETTING_ID> as serial five-seed repeats using canonical seeds 601, 602, 603, 604, and 605. Use the setting's output_root, tmux session, setting-generation scope, and operator-output script from the document.
```

## Fig. 4: Agent Effect

Fixed conditions:

- initial cash: `100000.0`
- skill condition: no skill
- market condition: no market
- replay seeds, costs, noise, and reward: canonical five-seed repeats with formal defaults

| Setting ID | Agent name | Backend | Model | Reasoning effort | `name` | tmux prefix | output_root |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `fig4_agent_codex` | Codex-GPT-5.5 | `codex` | OMIT | OMIT | `TadACampaign_v2_formal_fig4_agent_codex_cash100000` | `TadACampaign_fig4_agent_codex` | `runs/paper_main/fig4_agent/codex` |
| `fig4_agent_codex_gpt54` | Codex-GPT-5.4 | `codex` | `gpt-5.4` | OMIT | `TadACampaign_v2_formal_fig4_agent_codex_gpt54_cash100000` | `TadACampaign_fig4_agent_gpt54` | `runs/paper_main/fig4_agent/codex_gpt54` |
| `fig4_agent_codex_gpt53` | GPT-5.3-codex | `codex` | `gpt-5.3-codex` | OMIT | `TadACampaign_v2_formal_fig4_agent_codex_gpt53_cash100000` | `TadACampaign_fig4_agent_gpt53` | `runs/paper_main/fig4_agent/codex_gpt53` |
| `fig4_agent_opencode_deepseekv32` | OpenCode-DeepSeek-V3.2 | `opencode` | `deepseek/deepseek-v3.2` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_deepseekv32_cash100000` | `TadACampaign_fig4_agent_deepseekv32` | `runs/paper_main/fig4_agent/opencode_deepseekv32` |
| `fig4_agent_opencode_deepseekv4_flash` | OpenCode-DeepSeek-V4-Flash | `opencode` | `deepseek/deepseek-v4-flash` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_deepseekv4_flash_cash100000` | `TadACampaign_fig4_agent_deepseekv4_flash` | `runs/paper_main/fig4_agent/opencode_deepseekv4_flash` |
| `fig4_agent_opencode_deepseekv4_pro` | OpenCode-DeepSeek-V4-Pro | `opencode` | `deepseek/deepseek-v4-pro` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_deepseekv4_pro_cash100000` | `TadACampaign_fig4_agent_deepseekv4_pro` | `runs/paper_main/fig4_agent/opencode_deepseekv4_pro` |
| `fig4_agent_opencode_minimaxm25` | OpenCode-MiniMax-M2.5 | `opencode` | `minimax/minimax-m2.5` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_minimaxm25_cash100000` | `TadACampaign_fig4_agent_minimaxm25` | `runs/paper_main/fig4_agent/opencode_minimaxm25` |
| `fig4_agent_opencode_longcat_flash_thinking` | OpenCode-LongCat-Flash-Thinking | `opencode` | `longcat/longcat-flash-thinking` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_longcat_flash_thinking_cash100000` | `TadACampaign_fig4_agent_longcat_flash_thinking` | `runs/paper_main/fig4_agent/opencode_longcat_flash_thinking` |
| `fig4_agent_opencode_longcat_flash_lite` | OpenCode-LongCat-Flash-Lite | `opencode` | `longcat/longcat-flash-lite` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_longcat_flash_lite_cash100000` | `TadACampaign_fig4_agent_longcat_flash_lite` | `runs/paper_main/fig4_agent/opencode_longcat_flash_lite` |
| `fig4_agent_opencode_minimaxm27` | OpenCode-MiniMax-M2.7 | `opencode` | `minimax/minimax-m2.7` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_minimaxm27_cash100000` | `TadACampaign_fig4_agent_minimaxm27` | `runs/paper_main/fig4_agent/opencode_minimaxm27` |
| `fig4_agent_opencode_glm5` | OpenCode-GLM-5 | `opencode` | `zhipu/glm-5` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_glm5_cash100000` | `TadACampaign_fig4_agent_glm5` | `runs/paper_main/fig4_agent/opencode_glm5` |
| `fig4_agent_opencode_glm51` | OpenCode-GLM-5.1 | `opencode` | `zhipu/glm-5.1` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_glm51_cash100000` | `TadACampaign_fig4_agent_glm51` | `runs/paper_main/fig4_agent/opencode_glm51` |
| `fig4_agent_opencode_gpt54` | OpenCode-GPT-5.4 | `opencode` | `openai/gpt-5.4` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_gpt54_cash100000` | `TadACampaign_fig4_agent_gpt54` | `runs/paper_main/fig4_agent/opencode_gpt54` |
| `fig4_agent_opencode_gpt53codex` | OpenCode-GPT-5.3-codex | `opencode` | `openai/gpt-5.3-codex` | OMIT | `TadACampaign_v2_formal_fig4_agent_opencode_gpt53codex_cash100000` | `TadACampaign_fig4_agent_gpt53codex` | `runs/paper_main/fig4_agent/opencode_gpt53codex` |

Copyable prompt:

```text
Please read docs/formal_experiment_prompts.md and run the Fig. 4 agent-effect formal setting with setting_id=<SETTING_ID> as serial five-seed repeats using canonical seeds 601, 602, 603, 604, and 605. Use the backend/model fields, output_root, tmux session, setting-generation scope, and operator-output script from the document.
```

## Fig. 5a: Single-Skill Effect

Fig. 5a evaluates a no-skill control and 12 review-screened BioSkills as forced-skill settings. Older non-BioSkills settings are no longer formal Fig. 5a settings because they do not match the current TadA DNA input, CPU-only constraints, and callable decision-support target.

Implementation:

- No-skill control passes no skill-market arguments.
- Each BioSkill setting uses the neutral 12-BioSkills manifest as the package source.
- Each BioSkill setting writes `skill_market_enabled = false` and `initial_owned_skill_ids = ["<forced_skill_id>"]` into `setting.toml`.
- The agent starts with one owned skill and cannot buy skills.
- `TADACAMPAIGN_AGENT_PROMPT_APPEND` is unset; the skill is represented by actual local files, not prompt text.

Formal setting table:

| Setting ID | Skill condition | Forced skill id | `name` | tmux prefix | output_root | Manifest |
| --- | --- | --- | --- | --- | --- | --- |
| `fig5a_single_skill_no_skill` | No skill | unset | `TadACampaign_v2_formal_fig5a_single_skill_no_skill_cash100000` | `TadACampaign_fig5a_no_skill` | `runs/paper_main/fig5a_single_skill/no_skill` | unset |
| `fig5a_single_skill_motif_search` | Motif Search | `bioskills-motif-search` | `TadACampaign_v2_formal_fig5a_single_skill_motif_search_cash100000` | `TadACampaign_fig5a_motif_search` | `runs/paper_main/fig5a_single_skill/motif_search` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_sequence_properties` | Sequence Properties | `bioskills-sequence-properties` | `TadACampaign_v2_formal_fig5a_single_skill_sequence_properties_cash100000` | `TadACampaign_fig5a_sequence_properties` | `runs/paper_main/fig5a_single_skill/sequence_properties` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_pairwise_alignment` | Pairwise Alignment | `bioskills-pairwise-alignment` | `TadACampaign_v2_formal_fig5a_single_skill_pairwise_alignment_cash100000` | `TadACampaign_fig5a_pairwise_alignment` | `runs/paper_main/fig5a_single_skill/pairwise_alignment` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_codon_usage` | Codon Usage | `bioskills-codon-usage` | `TadACampaign_v2_formal_fig5a_single_skill_codon_usage_cash100000` | `TadACampaign_fig5a_codon_usage` | `runs/paper_main/fig5a_single_skill/codon_usage` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_transcription_translation` | Transcription Translation | `bioskills-transcription-translation` | `TadACampaign_v2_formal_fig5a_single_skill_transcription_translation_cash100000` | `TadACampaign_fig5a_transcription_translation` | `runs/paper_main/fig5a_single_skill/transcription_translation` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_reverse_complement` | Reverse Complement | `bioskills-reverse-complement` | `TadACampaign_v2_formal_fig5a_single_skill_reverse_complement_cash100000` | `TadACampaign_fig5a_reverse_complement` | `runs/paper_main/fig5a_single_skill/reverse_complement` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_sequence_slicing` | Sequence Slicing | `bioskills-sequence-slicing` | `TadACampaign_v2_formal_fig5a_single_skill_sequence_slicing_cash100000` | `TadACampaign_fig5a_sequence_slicing` | `runs/paper_main/fig5a_single_skill/sequence_slicing` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_sequence_statistics` | Sequence Statistics | `bioskills-sequence-statistics` | `TadACampaign_v2_formal_fig5a_single_skill_sequence_statistics_cash100000` | `TadACampaign_fig5a_sequence_statistics` | `runs/paper_main/fig5a_single_skill/sequence_statistics` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_filter_sequences` | Filter Sequences | `bioskills-filter-sequences` | `TadACampaign_v2_formal_fig5a_single_skill_filter_sequences_cash100000` | `TadACampaign_fig5a_filter_sequences` | `runs/paper_main/fig5a_single_skill/filter_sequences` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_msa_statistics` | MSA Statistics | `bioskills-msa-statistics` | `TadACampaign_v2_formal_fig5a_single_skill_msa_statistics_cash100000` | `TadACampaign_fig5a_msa_statistics` | `runs/paper_main/fig5a_single_skill/msa_statistics` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_distance_calculations` | Distance Calculations | `bioskills-distance-calculations` | `TadACampaign_v2_formal_fig5a_single_skill_distance_calculations_cash100000` | `TadACampaign_fig5a_distance_calculations` | `runs/paper_main/fig5a_single_skill/distance_calculations` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5a_single_skill_restriction_sites` | Restriction Sites | `bioskills-restriction-sites` | `TadACampaign_v2_formal_fig5a_single_skill_restriction_sites_cash100000` | `TadACampaign_fig5a_restriction_sites` | `runs/paper_main/fig5a_single_skill/restriction_sites` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |

Copyable prompt:

```text
Please read docs/formal_experiment_prompts.md and run the Fig. 5a single-skill-effect formal setting with setting_id=<SETTING_ID> as serial five-seed repeats using canonical seeds 601, 602, 603, 604, and 605. Use the BioSkills manifest preparation steps if needed, the forced-skill setting-generation fields, the output_root, tmux session, and the operator-output script from the document.
```

For forced-skill settings, verify each seed's `setting.toml` contains `[judge].skill_market_manifest`, `[judge].skill_market_enabled = false`, and `[judge].initial_owned_skill_ids = ["<forced_skill_id>"]`. For the no-skill setting, these fields should not be present.

During result review, also inspect `process/agent_workspace/owned_skills_index.json` and any `process/agent_workspace/skill_analysis/` artifacts. If no tool-backed skill artifact exists, record that fact; it is not automatically a run failure.

## Fig. 5b: Skill-Market Effect

Fixed conditions:

- agent: Codex
- initial cash: `100000.0`
- replay seeds, costs, noise, and reward: canonical five-seed repeats with formal defaults
- purpose: test whether the agent buys a skill, which skill it buys, when it buys, and whether purchase changes subsequent experimental strategy

| Setting ID | Market condition | `name` | tmux prefix | output_root | Manifest |
| --- | --- | --- | --- | --- | --- |
| `fig5b_skill_market_no_market` | No market | `TadACampaign_v2_formal_fig5b_skill_market_no_market_cash100000` | `TadACampaign_fig5b_no_market` | `runs/paper_main/fig5b_skill_market/no_market` | unset |
| `fig5b_skill_market_full_neutral` | 12-BioSkills neutral market | `TadACampaign_v2_formal_fig5b_skill_market_full_neutral_cash100000` | `TadACampaign_fig5b_full_neutral_market` | `runs/paper_main/fig5b_skill_market/full_neutral_market` | `/tmp/TadACampaign_skill_market/bioskills_screened12_neutral/skill_market.json` |
| `fig5b_skill_market_full_marketing` | 12-BioSkills marketing market | `TadACampaign_v2_formal_fig5b_skill_market_full_marketing_cash100000` | `TadACampaign_fig5b_full_marketing_market` | `runs/paper_main/fig5b_skill_market/full_marketing_market` | `/tmp/TadACampaign_skill_market/bioskills_screened12_marketing/skill_market.json` |

Fig. 5a forced-skill settings and Fig. 5b market settings use the same pool of 12 review-screened BioSkills. Do not use the default curated market for these figures. Build a manifest containing only the 12 BioSkills with market id `TadACampaign-bioskills-screened12` and price `1000.0`; expected total purchase cost including one day of burn is `1800.0`.

Every BioSkills manifest must contain 12 skills, `prices [1000.0]`, and `total_costs [1800.0]`. If not, fix the manifest or source checkout before running Fig. 5a or Fig. 5b skill settings.

Market settings should write the manifest into each seed-specific `setting.toml` with:

```bash
python3 scripts/create_formal_setting.py \
  --seed "<SEED>" \
  --skill-market-manifest "<manifest>" \
  --skill-market-enabled \
  ...
```

For market settings, unset `TADACAMPAIGN_SKILL_MARKET_MANIFEST` inside `tmux` and export `TADACAMPAIGN_AGENT_PROMPT_APPEND` only for the market-evaluation prompt block. That prompt append asks the agent to evaluate the market carefully; it does not provide skill file content.

Copyable prompt:

```text
Please read docs/formal_experiment_prompts.md and run the Fig. 5b skill-market-effect formal setting with setting_id=<SETTING_ID> as serial five-seed repeats using canonical seeds 601, 602, 603, 604, and 605. Use the Skill Market preparation steps if needed, write the manifest into each seed-specific setting.toml, use the output_root and tmux session from the document, and write operator outputs for every run.
```

During result review, record whether `purchase_skill` appears, which skills were purchased, whether action reasoning cited owned skills after purchase, and whether `process/agent_workspace/skill_analysis/` exists.

## Merge Plotting Data

After all settings complete, merge each run's operator CSV files:

```bash
find runs/paper_main -path '*/results/operator_run_summary.csv' -print
find runs/paper_main -path '*/results/operator_event_log.csv' -print
```

For downstream plotting, preserve at least these fields:

- `figure_id`
- `experiment_theme`
- `setting_id`
- `setting_name`
- `replay_seed`
- `agent_name`
- `initial_cash`
- `skill_condition`
- `market_condition`
- `prompt_append_mode`
- `manifest_path`
- `cash_final`
- `confirmed_best_activity`
- `stop_code`
- `stop_reason`

Figure filters:

- Fig. 3: `figure_id == "Fig. 3"`
- Fig. 4: `figure_id == "Fig. 4"`
- Fig. 5a: `figure_id == "Fig. 5a"`
- Fig. 5b: `figure_id == "Fig. 5b"`

## Common Red Flags

- `stop_reason` starts with `backend_error:`
- a run lacks `results/summary.json` or `results/action_log.jsonl`
- `rejection_log.jsonl` is long, indicating repeated illegal actions
- a formal repeat used a noncanonical seed
- a skill setting lacks expected `owned_skills_index.json` or manifest evidence
- a market setting has no `purchase_skill`; this is not automatically wrong, because Fig. 5b measures whether and when the agent chooses to buy
- `summary.json.provisional_best_activity` is much higher than `confirmed_best_activity` but the agent never attempted confirmation
