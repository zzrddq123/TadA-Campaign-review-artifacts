# Output Reference

After `scripts/run_TadACampaign_v2.sh` completes successfully, it prints the final run-directory path. The fixed top-level layout is:

```text
<run-dir>/
  setting.toml
  config.toml
  process/
  results/
```

## `setting.toml`

This is the source setting used for the run. Formal paper experiments usually generate `<output-root>/setting.toml` from `templates/TadACampaign_v2_formal_baseline.toml`, then launch the `formal` preset through `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE`. The launcher copies that source setting into the final run directory.

If `TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE` is unset, this file stores the built-in source config for the selected preset.

## `config.toml`

This is the runtime configuration snapshot.

Common changes:

- `prepared_root` and `output_root` are resolved to absolute paths
- `[judge].server_url` is written as the actual judge URL
- this file is the final configuration evidence for the run

## `process/`

`process/` stores runtime workspace files and per-step action records.

Common contents:

- `agent_workspace/`
- `step_001/`
- `step_002/`

`agent_workspace/` is refreshed throughout the run and usually contains:

- `agent_playbook.md`
- `biology_context.md`
- `available_actions.json`
- `skill_market.json`
- `owned_skills_index.json`
- `owned_skills/`
- `state.json`
- `history.json`

`biology_context.md` is optional reference context for action-level biology, cost and timing, and branch interpretation. It is not authoritative state; legal actions are determined by `available_actions.json` and `state.json`.

If a setting uses forced skills, `owned_skills_index.json` shows `owned_skill_count > 0` before the first step, and the corresponding files appear under `owned_skills/<skill_id>/source/`. This is an initial experimental condition, not a `purchase_skill` event in `action_log.jsonl`, and it does not increase `total_skill_purchase_price_paid`.

If the agent calls an owned skill's tools, scripts, checklists, or query workflows and creates auxiliary outputs, the recommended location is:

- `skill_analysis/`

`skill_analysis/` is a decision-support and audit artifact, not judge-authoritative state. Absence of this directory does not automatically mean a run failed; it only means no tool-backed skill artifact was observed.

If an agent policy uses file-based planning, `agent_workspace/` may also contain:

- `.agent_record/`
- `skill_analysis/`

Each `step_<N>/` directory usually contains:

- `state.json`
- `history.json`
- `available_actions.json`
- `skill_market.json`
- `owned_skills_index.json`
- `chosen_action.json`
- `judge_response.json`
- `step_meta.json`

`process/agent_workspace/history.json` is a rolling decision summary. To keep long formal runs within context, complete sequences in recent actions and recent screening records are compacted to `sequence_length`, `sequence_prefix`, `sequence_suffix`, and `sequence_sha256`. Confirmable candidates still retain full sequences in `state.pending_confirmations` and `available_actions.confirm_hit`.

`state.json.economic_summary` is the agent-facing budget-closure summary. It includes confirmation cost, configured minimum screen-plus-confirm reserve, currently available minimum screen-plus-confirm reserve, current confirmation reserve, and `budget_regime`. `available_actions.json` also annotates `mine_library.batch_options` with whether executing that batch still leaves cash and time for one `confirm_hit`.

`step_meta.json` is step-level wall-clock audit metadata:

- `step_started_at`
- `step_finished_at`
- `step_duration_seconds`
- `observation_request`
- `action_request`
- `accepted`
- `rejection_code`
- `rejection_reason`
- `terminal`
- `stop_code`
- `codex_thread_id` (Codex compatibility alias only)
- `agent_backend`
- `agent_session_id`

## `results/`

### Core Results

- `summary.json`
- `summary.md`
- `action_log.jsonl`
- `screen_record_history.jsonl`
- `rejection_log.jsonl`
- `judge_audit.jsonl`
- `runtime_timeline.jsonl`
- `seed_manifest.json`
- `cash_curve.csv`
- `cash_curve.png`
- `agent_stdout.log`
- `agent_stderr.log`
- `agent_command.txt`
- `agent_final_result.json`

If the operator follows the paper workflow in `docs/formal_experiment_prompts.md`, additional files may appear:

- `../EXPERIMENT_CARD.md`
- `operator_summary.md`
- `operator_event_log.csv`
- `operator_run_summary.csv`

These are not judge-authoritative state files. They are experiment-tracking and plotting artifacts generated from `summary.json`, `action_log.jsonl`, `config.toml`, and optional `process/agent_workspace/skill_analysis/`.

### Continuation Results

If retry, resume, or handoff occurs, the run usually also contains:

- `agent_resume_meta.json`
- `agent_stdout_attempt<N>.log`
- `agent_final_result_attempt<N>.json`
- `agent_handoff_prompt_attempt<N>.txt`

### Codex Compatibility Results

If the backend is Codex, the run usually also contains:

- `codex_events.jsonl`
- `codex_final_result.json`
- `codex_command.txt`
- `codex_stderr.log`

### Policy-Baseline Results

If the backend is a policy baseline, the run usually contains:

- `agent_stdout.log`: per-step semi-blind algorithmic policy decision and judge-response summary
- `agent_final_result.json`: terminal JSON from the policy backend

Policy baselines do not generate Codex/OpenCode/Claude event streams.

The launcher also copies host-side orchestration evidence to:

- `results/host_runtime/judge.log`
- `results/host_runtime/container.log`
- `results/host_runtime/runtime-config.toml`
- `results/host_runtime/source-config.toml`
- `results/host_runtime/judge-ready.json`
- `results/host_runtime/agents_copy_proof.json`
- `results/host_runtime/agents_inventory.txt`

If continuation occurs, additional Codex compatibility files may appear:

- `codex_resume_meta.json`
- `codex_events_attempt<N>.jsonl`
- `codex_final_result_attempt<N>.json`
- `codex_handoff_prompt_attempt<N>.txt`

## Common `summary.json` Fields

Common fields include:

- `run_name`
- `variant`
- `execution_model`
- `cash_final`
- `reward_earned_total`
- `cost_paid_total`
- `confirmed_best_activity`
- `confirmed_best_sequence`
- `provisional_best_activity`
- `provisional_best_sequence`
- `skill_market_enabled`
- `skill_market_size`
- `skill_catalog_size`
- `initial_owned_skill_ids`
- `owned_skill_count`
- `owned_skill_ids`
- `total_skill_purchase_price_paid`
- `screening_noise_enabled`
- `screening_noise_sigma`
- `screening_noise_clip`
- `day_final`
- `request_count`
- `action_count`
- `rejected_action_count`
- `stop_code`
- `stop_reason`
- `judge_session_id`
- `judge_server_url`
- `run_started_at`
- `run_completed_at`
- `wall_clock_duration_seconds`
- `agent_backend`
- `agent_policy` (policy baseline only)
- `agent_session_id`
- `agent_attempt_count`
- `agent_resume_count`
- `agent_handoff_count`
- `codex_attempt_count` (Codex compatibility alias only)
- `codex_resume_count` (Codex compatibility alias only)
- `codex_handoff_count` (Codex compatibility alias only)
- `codex_thread_id` (Codex compatibility alias only)
- `artifacts`

## `screen_record_history.jsonl`

This records the public version of every screening result:

- before confirmation, common fields are `screen_record_id`, `sequence`, `observed_activity`, and `is_confirmed`
- after confirmation, fields also include `confirmed_activity`, `noise_fraction`, and `is_confirmed_best`
- latent `true_activity` is not exposed before confirmation

## `rejection_log.jsonl`

This file lists judge-rejected actions, one JSON object per line. `rejection_reason` is readable text; `rejection_code` is the stable statistics field. Common `rejection_code` values include:

- `terminal_session`
- `unsupported_action`
- `missing_seed_id`
- `missing_library_id`
- `missing_batch_size`
- `missing_screen_record_id`
- `missing_skill_id`
- `unknown_seed`
- `unknown_library`
- `unknown_screen_record`
- `unknown_skill`
- `seed_not_visible`
- `seed_not_prepared`
- `seed_already_prepared`
- `library_not_prepared`
- `library_already_prepared`
- `library_exhausted`
- `illegal_batch_size`
- `screen_record_not_pending`
- `screen_record_already_confirmed`
- `cash_insufficient`
- `time_insufficient`
- `skill_market_disabled`
- `skill_already_owned`
- `runtime_error`

The same code may apply to multiple actions. For example, `cash_insufficient` can come from `prepare_seed`, `mine_library`, `confirm_hit`, or `purchase_skill`.

## `stop_code`

`summary.json`, terminal `state.json`, terminal payloads, and related audit responses keep readable `stop_reason` text and stable `stop_code` values:

- `agent_stop`: the agent submitted `stop`
- `max_experiment_days`: time horizon reached
- `time_insufficient`: remaining time is insufficient for any legal action
- `no_visible_path`: no visible experimental path remains
- `cash_insufficient`: cash is insufficient for any legal action
- `backend_error`: agent/backend failure forced a stop
- `force_stop`: non-backend-error administrative forced stop

## `judge_audit.jsonl`

This is the judge-side audit trace. Common events include:

- `session.created`
- `observation.fetched`
- `action.accepted`
- `action.rejected`
- `session.force_stopped`
- `skill.bundle.fetched`

Each record also includes:

- `request_received_at`
- `response_sent_at`
- `duration_seconds`

## `runtime_timeline.jsonl`

This is the unified runner/backend wall-clock event stream. Typical events include:

- `run.started`
- `run.finished`
- `judge.request.started`
- `judge.request.finished`
- `agent.attempt.started`
- `agent.attempt.finished`
- `agent.resume.scheduled`
- `agent.handoff.prompt_written`
- `agent.handoff.scheduled`
- `backend.force_stop`

If the backend is Codex, the same run also keeps `codex.*` compatibility events.

This file complements judge audit with client-side timing and agent-attempt information.

## Continuation Artifacts

If a run uses same-thread continuation or a fresh handoff, the most important additional files are:

- `agent_resume_meta.json`
- `runtime_timeline.jsonl`
- `agent_stdout_attempt<N>.log`

If the backend is Codex, also inspect:

- `codex_resume_meta.json`
- `codex_events_attempt<N>.jsonl`

When needed, combine these files with `step_<N>/step_meta.json` to reconstruct the step-level timeline.

## Failure Classification

If `summary.json.stop_reason` starts with `backend_error:`, the experiment ended early because of an agent/backend failure and should not be treated as a successful completion.
