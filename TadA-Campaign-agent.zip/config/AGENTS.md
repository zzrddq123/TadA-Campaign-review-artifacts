# AGENTS.md — TadACampaign Runtime Codex Protocol

## 1. Language
- **User interaction**: Simplified Chinese only
- **Internal work**: English allowed (code, comments, `.agent_record/` docs)

## 2. Core Mandate
**Required Skill**: `planning-with-files`

All tasks MUST use file-based planning. **Traceability** rules:
- Externalize thinking to files, not just context.
- Keep all working docs inside the specific `.agent_record/<THREAD_ID>/` directory.

## 3. Workflow

### Setup
Determine the current agent's thread ID via the `CODEX_THREAD_ID` environment variable or context (use `main` if not provided).
Create the directory `.agent_record/<THREAD_ID>/` and initialize three files inside it:

| File | Purpose |
|------|---------|
| `task_plan.md` | Goals, phases, status (Pending → Done) |
| `progress.md` | Operation log, errors. **Source of Truth** |
| `findings.md` | Key discoveries, architecture decisions, output for parent agents |

*Note: Agents are allowed to read `findings.md` or `progress.md` from other thread directories to share context, but MUST ONLY write to their own assigned `<THREAD_ID>` folder.*

### Execution Cycle
1. **Plan** — Update `<THREAD_ID>/task_plan.md`
2. **Act** — Execute changes/searches
3. **Record** — Log to `<THREAD_ID>/progress.md`; update `<THREAD_ID>/findings.md`

## 4. TadACampaign Runtime Rules
- You are running one full TadACampaign experiment, not returning a single-step JSON.
- Read `agent_playbook.md`, `available_actions.json`, `state.json`, and `history.json` before acting.
- The only supported way to change benchmark state is `./TadACampaign-agent-step`.
- Apart from maintaining `.agent_record/<THREAD_ID>/`, do not manually edit repository files, benchmark state files, or benchmark output artifacts.
- If `./TadACampaign-agent-step` returns `accepted=false`, read the rejection reason and choose a new legal move.
- In a suitable budget/time range, additional exploration can discover higher-activity proteins; higher confirmed activity can produce substantially higher reward and improve final cash.
- Prefer economically justified exploration that preserves a plausible path to `confirm_hit`; stop when the remaining actions no longer offer a credible risk-adjusted path to higher `cash_final`.

## 5. Completion
1. Finalize the docs in your specific `.agent_record/<THREAD_ID>/` directory.
2. When the benchmark reaches terminal state, output exactly one JSON object on a single line with at least `status`, `stop_reason`, `action_count`, and `summary`.
3. Do not include prose, Markdown, file references, apologies, or any text before or after that final JSON object.
4. Human-readable notes and Simplified Chinese status text belong only in your `.agent_record/<THREAD_ID>/progress.md` or `.agent_record/<THREAD_ID>/findings.md` files, not in the final assistant message.
