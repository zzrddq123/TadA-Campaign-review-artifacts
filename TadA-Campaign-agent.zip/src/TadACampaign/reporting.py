"""Result serialization and reporting."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_curve(results_dir: Path, action_history: list[dict[str, Any]], *, initial_cash: float) -> tuple[Path, Path]:
    csv_path = results_dir / "cash_curve.csv"
    png_path = results_dir / "cash_curve.png"

    days = [0.0]
    cash = [float(initial_cash)]
    for action in action_history:
        days.append(float(action.get("elapsed_day_after", action.get("day_after", 0.0))))
        cash.append(float(action.get("cash_after", action.get("cash_after", 0.0))))

    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["day", "cash"])
        for day, cash_point in zip(days, cash, strict=True):
            writer.writerow([day, cash_point])

    plt.figure(figsize=(8, 4))
    plt.plot(days, cash, marker="o")
    plt.xlabel("Day")
    plt.ylabel("Cash")
    plt.title("TadACampaign Cash Curve")
    plt.tight_layout()
    plt.savefig(png_path, dpi=160)
    plt.close()
    return csv_path, png_path


def render_markdown_summary(summary: dict[str, Any], run_dir: Path) -> str:
    lines = [
        f"# {summary['run_name']}",
        "",
        f"- 变体：`{summary['variant']}`",
        f"- Agent backend：`{summary.get('agent_backend', 'codex')}`",
        f"- 执行模型：`{summary.get('execution_model', 'docker_agent_host_judge')}`",
        f"- 终局现金：`{summary['cash_final']:.4f}`",
        f"- 总成本：`{summary['cost_paid_total']:.4f}`",
        f"- 总奖励：`{summary['reward_earned_total']:.4f}`",
        f"- 已确认最佳活性：`{summary['confirmed_best_activity']:.6f}`",
        f"- 暂定最佳活性：`{summary.get('provisional_best_activity', summary['confirmed_best_activity']):.6f}`",
        f"- Screening noise 启用：`{summary.get('screening_noise_enabled', False)}`",
        f"- Screening noise sigma/clip：`{summary.get('screening_noise_sigma', 0.0):.4f}` / `{summary.get('screening_noise_clip', 0.0):.4f}`",
        f"- 终局天数：`{summary['day_final']:.4f}`",
        f"- 待确认数量：`{summary.get('pending_confirmation_count', 0)}`",
        f"- 请求数：`{summary.get('request_count', summary.get('action_count', 0))}`",
        f"- 拒绝动作数：`{summary.get('rejected_action_count', 0)}`",
        f"- 停止代码：`{summary.get('stop_code')}`",
        f"- 停止原因：`{summary['stop_reason']}`",
        f"- 结果目录：`{run_dir / 'results'}`",
    ]
    if summary.get("wall_clock_duration_seconds") is not None:
        lines.append(f"- 墙钟耗时秒数：`{float(summary['wall_clock_duration_seconds']):.3f}`")
    if summary.get("agent_attempt_count") is not None:
        lines.append(
            f"- Agent 尝试次数/续跑次数/交接次数：`{summary.get('agent_attempt_count', 0)}` / "
            f"`{summary.get('agent_resume_count', 0)}` / `{summary.get('agent_handoff_count', 0)}`"
        )
    if summary.get("backend_failure_count") is not None:
        lines.append(
            f"- Backend 失败次数/可恢复失败次数/终止失败次数：`{summary.get('backend_failure_count', 0)}` / "
            f"`{summary.get('backend_retryable_failure_count', 0)}` / `{summary.get('backend_terminal_failure_count', 0)}`"
        )
    if summary.get("backend_recovery_attempt_count") is not None:
        lines.append(f"- Backend 恢复尝试次数：`{summary.get('backend_recovery_attempt_count', 0)}`")
    if summary.get("backend_force_stopped") is not None:
        lines.append(f"- Backend force-stopped：`{summary.get('backend_force_stopped')}`")
    classification_counts = summary.get("backend_failure_classification_counts")
    if isinstance(classification_counts, dict) and classification_counts:
        lines.append(
            "- Backend failure classifications：`"
            + ", ".join(f"{key}={value}" for key, value in sorted(classification_counts.items()))
            + "`"
        )
    if summary.get("backend_final_error"):
        lines.append(f"- Backend final error：`{summary.get('backend_final_error')}`")
    if summary.get("agent_session_id"):
        lines.append(f"- Agent session：`{summary['agent_session_id']}`")
    artifacts = summary.get("artifacts", {})
    agent_stdout = artifacts.get("agent_stdout_log")
    if agent_stdout:
        lines.append(f"- Agent stdout：`{agent_stdout}`")
    codex_events = artifacts.get("codex_events_jsonl")
    if codex_events:
        lines.append(f"- Codex 事件流：`{codex_events}`")
    runtime_timeline = artifacts.get("runtime_timeline_jsonl")
    if runtime_timeline:
        lines.append(f"- Runtime 时间线：`{runtime_timeline}`")
    handoff_drill = artifacts.get("handoff_drill_meta_json")
    if handoff_drill:
        lines.append(f"- Handoff drill 元数据：`{handoff_drill}`")
    judge_audit = artifacts.get("judge_audit_jsonl")
    if judge_audit:
        lines.append(f"- Judge 审计日志：`{judge_audit}`")
    return "\n".join(lines) + "\n"
