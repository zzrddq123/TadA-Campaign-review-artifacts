"""Public CLI entrypoints."""

from __future__ import annotations

import argparse
from pathlib import Path

from .curated_skill_market import prepare_curated_skill_market
from .data import prepare_data
from .runner import summarize_run


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="TadACampaign benchmark CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    prepare_parser = subparsers.add_parser("prepare-data", help="Prepare canonical dna/protein benchmark data")
    prepare_parser.add_argument("--zip-path", default="data/review-data.zip", help="Path to the raw review-data zip")
    prepare_parser.add_argument("--output-dir", default="prepared", help="Output directory for prepared benchmark assets")

    market_parser = subparsers.add_parser(
        "prepare-skill-market",
        help="Build the curated local launch-market bundle from offline upstream clones",
    )
    market_parser.add_argument(
        "--source-root",
        default="/tmp/TadACampaign_skill_scout",
        help="Root containing local upstream repo checkouts",
    )
    market_parser.add_argument(
        "--output-dir",
        default="/tmp/TadACampaign_skill_market/launch21",
        help="Output directory for the curated local market bundle",
    )
    market_parser.add_argument("--force", action="store_true", help="Replace the output directory if it already exists")

    summarize_parser = subparsers.add_parser("summarize", help="Render a markdown summary for a run directory")
    summarize_parser.add_argument("--run-dir", required=True, help="Path to a completed run directory")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "prepare-data":
        output_root = prepare_data(Path(args.zip_path), Path(args.output_dir))
        print(output_root)
        return 0

    if args.command == "prepare-skill-market":
        manifest_path = prepare_curated_skill_market(Path(args.source_root), Path(args.output_dir), force=bool(args.force))
        print(manifest_path)
        return 0

    if args.command == "summarize":
        print(summarize_run(Path(args.run_dir)))
        return 0

    parser.error(f"Unsupported command {args.command!r}")
    return 1
