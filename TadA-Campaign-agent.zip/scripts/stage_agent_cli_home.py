#!/usr/bin/env python3
"""Stage a backend-aware CLI home snapshot."""

from __future__ import annotations

import argparse
from pathlib import Path

from TadACampaign.agent_cli_home import stage_agent_cli_home


def main() -> int:
    parser = argparse.ArgumentParser(description="Stage a backend-aware CLI home snapshot")
    parser.add_argument("--backend", required=True, choices=("codex", "claude", "opencode", "policy"))
    parser.add_argument("--target-root", required=True)
    parser.add_argument("--codex-source-dir")
    parser.add_argument("--snapshot-credentials", type=int, choices=(0, 1), default=1)
    parser.add_argument("--skills-mode", default="planning-with-files")
    parser.add_argument("--mcp-server-filter", choices=("keep_all", "drop_all"), default="drop_all")
    parser.add_argument("--global-agents-file")
    parser.add_argument("--claude-source-dir")
    parser.add_argument("--claude-state-file")
    parser.add_argument("--opencode-config-dir")
    parser.add_argument("--opencode-data-dir")
    parser.add_argument("--clean-target", action="store_true")
    args = parser.parse_args()

    stage_agent_cli_home(
        backend=args.backend,
        target_root=Path(args.target_root),
        codex_source_dir=Path(args.codex_source_dir) if args.codex_source_dir else None,
        include_codex_credentials=bool(args.snapshot_credentials),
        codex_skills_mode=args.skills_mode,
        codex_mcp_server_filter_mode=args.mcp_server_filter,
        global_agents_path=Path(args.global_agents_file) if args.global_agents_file else None,
        claude_source_dir=Path(args.claude_source_dir) if args.claude_source_dir else None,
        claude_state_file=Path(args.claude_state_file) if args.claude_state_file else None,
        opencode_config_dir=Path(args.opencode_config_dir) if args.opencode_config_dir else None,
        opencode_data_dir=Path(args.opencode_data_dir) if args.opencode_data_dir else None,
        clean_target=args.clean_target,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
