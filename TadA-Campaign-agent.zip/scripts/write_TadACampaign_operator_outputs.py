#!/usr/bin/env python3
"""Write operator-facing metadata and summary files for a completed run."""

from __future__ import annotations

import argparse
import csv
import json
import tomllib
from pathlib import Path
from typing import Any

SKILL_ANALYSIS_EXTENSIONS = {".json", ".md", ".txt", ".csv", ".log"}


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            payload = json.loads(line)
            if isinstance(payload, dict):
                rows.append(payload)
    return rows


def _fmt(value: Any) -> str:
    if value is None or value == "":
        return "-"
    if isinstance(value, float):
        return f"{value:.6g}"
    return str(value)


def _md_escape(value: Any) -> str:
    return _fmt(value).replace("|", "\\|").replace("\n", " ")


def _action_text(record: dict[str, Any]) -> str:
    parts = [f"action={record.get('action', '-')}"]
    for key, label in [
        ("seed_id", "seed_id"),
        ("library_id", "library_id"),
        ("requested_batch_size", "batch_size"),
        ("actual_batch_size", "actual_batch_size"),
        ("screen_record_id", "screen_record_id"),
        ("skill_id", "skill_id"),
        ("display_name", "display_name"),
    ]:
        value = record.get(key)
        if value not in (None, ""):
            parts.append(f"{label}={value}")
    return "; ".join(parts)


def _scan_skill_analysis_artifacts(run_dir: Path) -> list[dict[str, Any]]:
    analysis_dir = run_dir / "process" / "agent_workspace" / "skill_analysis"
    if not analysis_dir.is_dir():
        return []
    artifacts: list[dict[str, Any]] = []
    for path in sorted(candidate for candidate in analysis_dir.rglob("*") if candidate.is_file()):
        if path.suffix.lower() not in SKILL_ANALYSIS_EXTENSIONS:
            continue
        item: dict[str, Any] = {
            "path": path.relative_to(run_dir).as_posix(),
            "bytes": path.stat().st_size,
            "kind": path.suffix.lower().lstrip(".") or "file",
        }
        if path.suffix.lower() == ".json":
            item.update(_summarize_skill_analysis_json(path))
        artifacts.append(item)
    return artifacts


def _summarize_skill_analysis_json(path: Path) -> dict[str, Any]:
    try:
        payload = _load_json(path)
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict):
        return {}
    summary: dict[str, Any] = {}
    for key in ("summary", "finding", "findings", "key_findings", "decision_notes", "usage_semantics"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            summary[key] = value.strip()
        elif isinstance(value, list):
            summary[key] = [str(item) for item in value[:5]]
    return summary


def _artifact_findings_text(item: dict[str, Any]) -> str:
    parts: list[str] = []
    for key in ("summary", "finding", "findings", "key_findings", "decision_notes"):
        value = item.get(key)
        if isinstance(value, str) and value:
            parts.append(value)
        elif isinstance(value, list) and value:
            parts.append("; ".join(str(entry) for entry in value))
    return " | ".join(parts)


def _skill_analysis_paths_text(artifacts: list[dict[str, Any]]) -> str:
    return "; ".join(str(item.get("path", "")) for item in artifacts if item.get("path"))


def _backend_classification_counts_text(summary: dict[str, Any]) -> str:
    counts = summary.get("backend_failure_classification_counts")
    if not isinstance(counts, dict) or not counts:
        return ""
    return ", ".join(f"{key}={value}" for key, value in sorted(counts.items()))


def _json_text(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    if value is None:
        return ""
    return str(value)


def _has_skill_reporting_surface(args: argparse.Namespace, summary: dict[str, Any]) -> bool:
    manifest_path = str(getattr(args, "manifest_path", "") or "").strip().lower()
    skill_condition = str(getattr(args, "skill_condition", "") or "").strip().lower().replace(" ", "_")
    market_condition = str(getattr(args, "market_condition", "") or "").strip().lower().replace(" ", "_")
    if manifest_path not in {"", "-", "unset", "none", "null"}:
        return True
    if skill_condition not in {"", "-", "no_skill", "none", "unset"}:
        return True
    if market_condition not in {"", "-", "no_market", "none", "unset"}:
        return True
    if int(summary.get("skill_catalog_size", 0) or 0) > 0:
        return True
    if int(summary.get("owned_skill_count", 0) or 0) > 0:
        return True
    if float(summary.get("total_skill_purchase_price_paid", 0.0) or 0.0) > 0.0:
        return True
    return False


def _write_experiment_card(run_dir: Path, args: argparse.Namespace) -> None:
    card = f"""# Experiment Card

- figure_id: `{args.figure_id}`
- experiment_theme: `{args.experiment_theme}`
- setting_id: `{args.setting_id}`
- setting_name: `{args.setting_name}`
- purpose: {args.purpose}
- independent_variable: `{args.independent_variable}`
- agent_name: `{args.agent_name}`
- initial_cash: `{args.initial_cash:g}`
- skill_condition: `{args.skill_condition}`
- market_condition: `{args.market_condition}`
- prompt_append_mode: `{args.prompt_append_mode}`
- manifest_path: `{args.manifest_path}`
- output_root: `{args.output_root}`
- run_dir: `{run_dir}`
- config_snapshot: `config.toml`
- main_results: `results/summary.json`, `results/action_log.jsonl`
- process_records: `process/agent_workspace/`, `process/step_*`
- control_variables: {args.control_variables}
"""
    (run_dir / "EXPERIMENT_CARD.md").write_text(card, encoding="utf-8")


def _build_event_rows(
    *,
    run_dir: Path,
    actions: list[dict[str, Any]],
    summary: dict[str, Any],
    config: dict[str, Any],
    args: argparse.Namespace,
    skill_analysis_artifacts: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[str]]:
    cash_before = float(args.initial_cash)
    day_before = 0.0
    best_before = float(config.get("baseline_activity", 1.0))
    event_rows: list[dict[str, Any]] = []
    skill_reporting_surface = _has_skill_reporting_surface(args, summary)
    summary_lines = [
        f"# Operator Summary: {args.setting_id}",
        "",
        f"- figure_id: `{args.figure_id}`",
        f"- experiment_theme: `{args.experiment_theme}`",
        f"- setting_name: `{args.setting_name}`",
        f"- run_dir: `{run_dir}`",
        f"- final cash: `{_fmt(summary.get('cash_final'))}`",
        f"- final day: `{_fmt(summary.get('day_final'))}`",
        f"- action count: `{_fmt(summary.get('action_count', len(actions)))}`",
        f"- stop_reason: `{_fmt(summary.get('stop_reason'))}`",
        f"- confirmed_best_activity: `{_fmt(summary.get('confirmed_best_activity'))}`",
        f"- stop_code: `{_fmt(summary.get('stop_code'))}`",
    ]
    if summary.get("backend_force_stopped") is not None:
        summary_lines.append(f"- backend force stopped: `{_fmt(summary.get('backend_force_stopped'))}`")
    if summary.get("backend_failure_count") is not None:
        summary_lines.append(
            "- backend failures/retryable/terminal: "
            f"`{_fmt(summary.get('backend_failure_count'))}` / "
            f"`{_fmt(summary.get('backend_retryable_failure_count', 0))}` / "
            f"`{_fmt(summary.get('backend_terminal_failure_count', 0))}`"
        )
    if summary.get("backend_recovery_attempt_count") is not None:
        summary_lines.append(f"- backend recovery attempts: `{_fmt(summary.get('backend_recovery_attempt_count'))}`")
    classification_counts = _backend_classification_counts_text(summary)
    if classification_counts:
        summary_lines.append(f"- backend failure classifications: `{classification_counts}`")
    if summary.get("backend_final_error"):
        summary_lines.append(f"- backend final error: `{_fmt(summary.get('backend_final_error'))}`")
    if skill_reporting_surface:
        summary_lines.extend(
            [
                f"- skill market enabled: `{_fmt(summary.get('skill_market_enabled'))}`",
                f"- skill market size: `{_fmt(summary.get('skill_market_size'))}`",
                f"- skill catalog size: `{_fmt(summary.get('skill_catalog_size'))}`",
                f"- initial owned skill ids: `{_fmt(summary.get('initial_owned_skill_ids'))}`",
                f"- owned skill count: `{_fmt(summary.get('owned_skill_count'))}`",
                f"- owned skill ids: `{_fmt(summary.get('owned_skill_ids'))}`",
                f"- total skill purchase price paid: `{_fmt(summary.get('total_skill_purchase_price_paid'))}`",
                f"- optional skill analysis artifact count: `{len(skill_analysis_artifacts)}`",
            ]
        )
    summary_lines.extend(
        [
            "",
            "| Step | Action | Day | Cash Before | Cash After | Best Activity Before | Best Activity After |",
            "| --- | --- | --- | --- | --- | --- | --- |",
        ]
    )

    for step, record in enumerate(actions, start=1):
        action = str(record.get("action", ""))
        cash_after = float(record.get("cash_after", cash_before))
        day_after = float(record.get("elapsed_day_after", record.get("day_after", day_before)))
        best_row_before = float(record.get("confirmed_best_before", best_before))
        best_row_after = float(record.get("confirmed_best_after", best_row_before))
        reward = float(record.get("reward_earned", 0.0) or 0.0)
        total_cost = cash_before - cash_after + reward

        summary_lines.append(
            f"| {step} | {_md_escape(_action_text(record))} | {_md_escape(day_after)} | "
            f"{_md_escape(cash_before)} | {_md_escape(cash_after)} | "
            f"{_md_escape(best_row_before)} | {_md_escape(best_row_after)} |"
        )
        event_row = {
            "figure_id": args.figure_id,
            "run_id": run_dir.name,
            "setting_id": args.setting_id,
            "setting_name": args.setting_name,
            "agent_name": args.agent_name,
            "replay_seed": config.get("seed", ""),
            "step_idx": step,
            "day_before": day_before,
            "day_after": day_after,
            "cash_before": cash_before,
            "cash_after": cash_after,
            "action_type": action,
            "target_seed": record.get("seed_id", ""),
            "target_library": record.get("library_id", ""),
            "mine_batch_size": record.get("requested_batch_size", record.get("actual_batch_size", "")),
            "screen_record_id": record.get("screen_record_id", ""),
            "observed_activity": record.get("observed_activity", ""),
            "confirmed_activity": record.get("confirmed_activity", ""),
            "reward": reward,
            "direct_cost": "",
            "burn_cost": "",
            "total_cost": total_cost,
            "confirmed_best_before": best_row_before,
            "confirmed_best_after": best_row_after,
            "legal_action_count": "",
            "invalid_retry_count": summary.get("rejected_action_count", 0),
        }
        if skill_reporting_surface:
            event_row["skill_id"] = record.get("skill_id", "")
            event_row["skill_name"] = record.get("display_name", "")
        event_rows.append(event_row)
        cash_before = cash_after
        day_before = day_after
        best_before = best_row_after

    if skill_reporting_surface:
        summary_lines.extend(["", "## Optional Skill Tool-Use Artifacts", ""])
        if skill_analysis_artifacts:
            summary_lines.extend(["| Artifact | Bytes | Key Results |", "| --- | ---: | --- |"])
            for item in skill_analysis_artifacts:
                summary_lines.append(
                    f"| {_md_escape(item.get('path'))} | {_md_escape(item.get('bytes'))} | "
                    f"{_md_escape(_artifact_findings_text(item) or '-')} |"
                )
        else:
            summary_lines.append("- 未观察到 `process/agent_workspace/skill_analysis/` 中的 tool-backed skill artifact；这不自动表示实验失败。")

    return event_rows, summary_lines


def _write_csv(path: Path, rows: list[dict[str, Any]], fieldnames: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_operator_outputs(args: argparse.Namespace) -> Path:
    run_dir = args.run_dir.expanduser().resolve()
    results_dir = run_dir / "results"
    summary = _load_json(results_dir / "summary.json")
    actions = _load_jsonl(results_dir / "action_log.jsonl")
    config = tomllib.loads((run_dir / "config.toml").read_text(encoding="utf-8"))
    skill_analysis_artifacts = _scan_skill_analysis_artifacts(run_dir)
    skill_reporting_surface = _has_skill_reporting_surface(args, summary)

    _write_experiment_card(run_dir, args)
    event_rows, summary_lines = _build_event_rows(
        run_dir=run_dir,
        actions=actions,
        summary=summary,
        config=config,
        args=args,
        skill_analysis_artifacts=skill_analysis_artifacts,
    )
    (results_dir / "operator_summary.md").write_text("\n".join(summary_lines) + "\n", encoding="utf-8")

    event_fields = [
        "figure_id",
        "run_id",
        "setting_id",
        "setting_name",
        "agent_name",
        "replay_seed",
        "step_idx",
        "day_before",
        "day_after",
        "cash_before",
        "cash_after",
        "action_type",
        "target_seed",
        "target_library",
        "mine_batch_size",
        "screen_record_id",
        "observed_activity",
        "confirmed_activity",
        "reward",
        "direct_cost",
        "burn_cost",
        "total_cost",
        "confirmed_best_before",
        "confirmed_best_after",
        "legal_action_count",
        "invalid_retry_count",
    ]
    if skill_reporting_surface:
        insert_at = event_fields.index("screen_record_id")
        event_fields[insert_at:insert_at] = ["skill_id", "skill_name"]
    _write_csv(results_dir / "operator_event_log.csv", event_rows, event_fields)

    run_summary = {
        "figure_id": args.figure_id,
        "run_id": run_dir.name,
        "setting_id": args.setting_id,
        "setting_name": args.setting_name,
        "agent_name": args.agent_name,
        "replay_seed": config.get("seed", ""),
        "initial_cash": args.initial_cash,
        "terminal_day": summary.get("day_final"),
        "terminal_cash": summary.get("cash_final"),
        "confirmed_best_activity": summary.get("confirmed_best_activity"),
        "max_frontier_depth": summary.get("max_seed_depth_reached"),
        "num_prepare_seed": sum(1 for item in actions if item.get("action") == "prepare_seed"),
        "num_prepare_library": sum(1 for item in actions if item.get("action") == "prepare_library"),
        "num_mine_library": sum(1 for item in actions if item.get("action") == "mine_library"),
        "num_confirm_hit": sum(1 for item in actions if item.get("action") == "confirm_hit"),
        "total_mined_sequences": sum(
            int(item.get("actual_batch_size", 0) or 0)
            for item in actions
            if item.get("action") == "mine_library"
        ),
        "total_confirmed_hits": sum(
            1
            for item in actions
            if item.get("action") == "confirm_hit" and item.get("confirmed_activity") is not None
        ),
        "confirmation_precision": "",
        "num_invalid_actions": summary.get("rejected_action_count"),
        "stop_code": summary.get("stop_code"),
        "stop_reason": summary.get("stop_reason"),
    }
    for key in [
        "backend_force_stopped",
        "backend_failure_count",
        "backend_retryable_failure_count",
        "backend_terminal_failure_count",
        "backend_recovery_attempt_count",
        "backend_missing_final_json_handoff_count",
        "backend_recovery_success",
        "backend_final_failure_classification",
        "backend_final_error",
        "backend_failure_classifications",
        "backend_failure_classification_counts",
    ]:
        if key in summary:
            run_summary[key] = _json_text(summary.get(key))
    if skill_reporting_surface:
        run_summary.update(
            {
                "num_purchase_skill": sum(1 for item in actions if item.get("action") == "purchase_skill"),
                "skill_market_enabled": summary.get("skill_market_enabled"),
                "skill_market_size": summary.get("skill_market_size"),
                "skill_catalog_size": summary.get("skill_catalog_size"),
                "initial_owned_skill_ids": json.dumps(summary.get("initial_owned_skill_ids", []), ensure_ascii=False),
                "owned_skill_count": summary.get("owned_skill_count"),
                "owned_skill_ids": json.dumps(summary.get("owned_skill_ids", []), ensure_ascii=False),
                "total_skill_purchase_price_paid": summary.get("total_skill_purchase_price_paid"),
                "skill_analysis_artifact_count": len(skill_analysis_artifacts),
                "skill_analysis_artifacts": _skill_analysis_paths_text(skill_analysis_artifacts),
            }
        )
    _write_csv(results_dir / "operator_run_summary.csv", [run_summary], list(run_summary))
    return results_dir / "operator_summary.md"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--figure-id", required=True)
    parser.add_argument("--experiment-theme", required=True)
    parser.add_argument("--setting-id", required=True)
    parser.add_argument("--setting-name", required=True)
    parser.add_argument("--agent-name", required=True)
    parser.add_argument("--initial-cash", type=float, required=True)
    parser.add_argument("--independent-variable", required=True)
    parser.add_argument("--control-variables", required=True)
    parser.add_argument("--purpose", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--skill-condition", default="-")
    parser.add_argument("--market-condition", default="-")
    parser.add_argument("--prompt-append-mode", default="-")
    parser.add_argument("--manifest-path", default="-")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    summary_path = write_operator_outputs(args)
    print(summary_path.read_text(encoding="utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
