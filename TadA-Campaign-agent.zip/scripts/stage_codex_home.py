#!/usr/bin/env python3
"""Stage a minimal Codex home snapshot."""

from __future__ import annotations

import argparse
from pathlib import Path

from TadACampaign.codex_home import stage_codex_home


def main() -> int:
    parser = argparse.ArgumentParser(description="Stage a minimal Codex home snapshot")
    parser.add_argument("source_dir")
    parser.add_argument("target_dir")
    parser.add_argument("--snapshot-credentials", type=int, choices=(0, 1), default=1)
    parser.add_argument("--skills-mode", default="planning-with-files")
    parser.add_argument("--mcp-server-filter", choices=("keep_all", "drop_all"), default="drop_all")
    parser.add_argument("--global-agents-file")
    parser.add_argument("--clean-target", action="store_true")
    args = parser.parse_args()

    stage_codex_home(
        source_dir=Path(args.source_dir),
        target_dir=Path(args.target_dir),
        include_credentials=bool(args.snapshot_credentials),
        skills_mode=args.skills_mode,
        mcp_server_filter_mode=args.mcp_server_filter,
        global_agents_path=Path(args.global_agents_file) if args.global_agents_file else None,
        clean_target=args.clean_target,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
