#!/usr/bin/env python3
"""Prepare, launch, and collect Fig. 2 construct-validity policy baselines."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import time
from pathlib import Path

from create_formal_setting import create_setting

REPO_ROOT = Path(__file__).resolve().parents[1]
CANONICAL_SEEDS = (20260101, 20260102, 20260103, 20260104, 20260105)
POLICIES = (
    ("stop_now", "Stop Now"),
    ("blind_random_legal", "Random Legal"),
    ("budgeted_static_ranker", "Budgeted Static Ranker"),
    ("scout_confirm_stop", "Scout Confirm Stop"),
    ("upside_greedy_explorer", "Upside Greedy Explorer"),
    ("empirical_ev_planner", "Empirical EV Planner"),
)
DEFAULT_OUTPUT_ROOT = REPO_ROOT / "runs" / "paper_main" / "fig2_construct_validity"
INITIAL_CASH = 100000.0


def _policy_slug(policy: str) -> str:
    return policy.replace("_", "-")


def _tmux_session(policy: str, seed: int) -> str:
    return f"TadACampaign_fig2_{policy}_{seed}"


def _setting_name(policy: str, seed: int) -> str:
    return f"TadACampaign_v2_formal_fig2_construct_validity_{policy}_cash100000_seed{seed}"


def _setting_path(output_root: Path, policy: str, seed: int) -> Path:
    return output_root / policy / f"seed{seed}" / "setting.toml"


def _seed_output_root(output_root: Path, policy: str, seed: int) -> Path:
    return output_root / policy / f"seed{seed}"


def prepare_settings(output_root: Path) -> list[Path]:
    paths: list[Path] = []
    for policy, _ in POLICIES:
        for seed in CANONICAL_SEEDS:
            seed_output_root = _seed_output_root(output_root, policy, seed)
            seed_output_root.mkdir(parents=True, exist_ok=True)
            args = argparse.Namespace(
                baseline=REPO_ROOT / "templates" / "TadACampaign_v2_formal_baseline.toml",
                output=seed_output_root / "setting.toml",
                prepared_root=REPO_ROOT / "prepared",
                run_output_root=seed_output_root,
                name=_setting_name(policy, seed),
                seed=seed,
                initial_cash=INITIAL_CASH,
                agent_backend="policy",
                agent_policy=policy,
                agent_model=None,
                agent_reasoning_effort=None,
                agent_profile=None,
                agent_verbosity=None,
                skill_market_manifest=None,
                skill_market_enabled=True,
                initial_owned_skill_ids=[],
            )
            paths.append(create_setting(args))
    return paths


def _tmux_has_session(session: str) -> bool:
    result = subprocess.run(["tmux", "has-session", "-t", session], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return result.returncode == 0


def latest_run_dir(seed_output_root: Path) -> Path | None:
    if not seed_output_root.is_dir():
        return None
    candidates = [
        path
        for path in seed_output_root.iterdir()
        if path.is_dir() and (path / "results" / "summary.json").is_file()
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda path: path.stat().st_mtime)


def _launch_one(output_root: Path, policy: str, seed: int, *, force: bool, skip_completed: bool) -> bool:
    seed_output_root = _seed_output_root(output_root, policy, seed)
    if skip_completed and latest_run_dir(seed_output_root) is not None and not force:
        print(f"skip completed run: {policy} seed{seed}")
        return False

    session = _tmux_session(policy, seed)
    if _tmux_has_session(session):
        if not force:
            print(f"skip existing tmux session: {session}")
            return False
        subprocess.run(["tmux", "kill-session", "-t", session], check=False)

    setting_path = _setting_path(output_root, policy, seed)
    log_path = seed_output_root / "tmux.log"
    command = (
        f"cd {REPO_ROOT} && "
        "unset TADACAMPAIGN_SKILL_MARKET_MANIFEST TADACAMPAIGN_AGENT_PROMPT_APPEND && "
        f"export TADACAMPAIGN_FORMAL_CONFIG_OVERRIDE={setting_path} && "
        f"bash scripts/run_TadACampaign_v2.sh formal {seed_output_root} 2>&1 | tee {log_path}"
    )
    subprocess.run(["tmux", "new-session", "-d", "-s", session, command], check=True)
    print(f"launched {session}: {seed_output_root}")
    return True


def launch(output_root: Path, *, force: bool = False) -> None:
    prepare_settings(output_root)
    for policy, _ in POLICIES:
        for seed in CANONICAL_SEEDS:
            _launch_one(output_root, policy, seed, force=force, skip_completed=False)


def launch_serial(output_root: Path, *, force: bool = False, poll_seconds: float = 30.0) -> None:
    prepare_settings(output_root)
    for policy, _ in POLICIES:
        for seed in CANONICAL_SEEDS:
            session = _tmux_session(policy, seed)
            started = _launch_one(output_root, policy, seed, force=force, skip_completed=True)
            if not started and not _tmux_has_session(session):
                continue
            while _tmux_has_session(session):
                time.sleep(max(poll_seconds, 1.0))
            run_dir = latest_run_dir(_seed_output_root(output_root, policy, seed))
            if run_dir is None:
                raise RuntimeError(f"{policy} seed{seed} finished without results/summary.json")
            print(f"completed {policy} seed{seed}: {run_dir}")


def collect(output_root: Path) -> Path:
    aggregate_rows: list[dict[str, object]] = []
    for policy, display_name in POLICIES:
        for seed in CANONICAL_SEEDS:
            seed_output_root = _seed_output_root(output_root, policy, seed)
            run_dir = latest_run_dir(seed_output_root)
            if run_dir is None:
                print(f"missing completed run for {policy} seed{seed}")
                continue
            summary = json.loads((run_dir / "results" / "summary.json").read_text(encoding="utf-8"))
            subprocess.run(
                [
                    "python3",
                    str(REPO_ROOT / "scripts" / "write_TadACampaign_operator_outputs.py"),
                    "--run-dir",
                    str(run_dir),
                    "--figure-id",
                    "Fig. 2",
                    "--experiment-theme",
                    "Construct validity of semi-blind policy baselines",
                    "--setting-id",
                    f"fig2_construct_validity_{policy}",
                    "--setting-name",
                    display_name,
                    "--agent-name",
                    display_name,
                    "--initial-cash",
                    str(INITIAL_CASH),
                    "--independent-variable",
                    "semi_blind_policy",
                    "--control-variables",
                    "initial_cash=100000; no skill; no skill market; matched canonical 5-seed repeats; same horizon/cost/noise/reward setting.",
                    "--purpose",
                    "Measure whether the benchmark distinguishes semi-blind scientific operating policies without using LLM decision-making.",
                    "--output-root",
                    str(seed_output_root),
                    "--skill-condition",
                    "no_skill",
                    "--market-condition",
                    "no_market",
                    "--prompt-append-mode",
                    "unset",
                    "--manifest-path",
                    "unset",
                ],
                check=True,
                cwd=REPO_ROOT,
                stdout=subprocess.DEVNULL,
            )
            cash_final = float(summary["cash_final"])
            aggregate_rows.append(
                {
                    "policy": policy,
                    "policy_label": display_name,
                    "seed": seed,
                    "run_dir": str(run_dir),
                    "initial_cash": INITIAL_CASH,
                    "cash_final": cash_final,
                    "profit": cash_final - INITIAL_CASH,
                    "confirmed_best_activity": summary.get("confirmed_best_activity"),
                    "stop_code": summary.get("stop_code"),
                    "stop_reason": summary.get("stop_reason"),
                }
            )
    output_root.mkdir(parents=True, exist_ok=True)
    aggregate_path = output_root / "construct_validity_policy_summary.csv"
    with aggregate_path.open("w", encoding="utf-8", newline="") as handle:
        fieldnames = [
            "policy",
            "policy_label",
            "seed",
            "run_dir",
            "initial_cash",
            "cash_final",
            "profit",
            "confirmed_best_activity",
            "stop_code",
            "stop_reason",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(aggregate_rows)
    print(aggregate_path)
    return aggregate_path


def status(output_root: Path) -> None:
    for policy, _ in POLICIES:
        for seed in CANONICAL_SEEDS:
            session = _tmux_session(policy, seed)
            run_dir = latest_run_dir(_seed_output_root(output_root, policy, seed))
            tmux_state = "running" if _tmux_has_session(session) else "not-running"
            run_state = str(run_dir) if run_dir is not None else "no-completed-run"
            print(f"{policy} seed{seed}: {tmux_state}; {run_state}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "launch", "launch-serial", "collect", "status"))
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--force", action="store_true", help="Kill and restart existing tmux sessions on launch")
    parser.add_argument("--poll-seconds", type=float, default=30.0, help="Polling interval for launch-serial")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    output_root = args.output_root.expanduser().resolve()
    if args.command == "prepare":
        for path in prepare_settings(output_root):
            print(path)
        return 0
    if args.command == "launch":
        launch(output_root, force=bool(args.force))
        return 0
    if args.command == "launch-serial":
        launch_serial(output_root, force=bool(args.force), poll_seconds=float(args.poll_seconds))
        return 0
    if args.command == "collect":
        collect(output_root)
        return 0
    if args.command == "status":
        status(output_root)
        return 0
    raise AssertionError(args.command)


if __name__ == "__main__":
    raise SystemExit(main())
