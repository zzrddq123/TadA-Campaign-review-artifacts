#!/usr/bin/env python3
"""Create a per-run formal setting TOML from the baseline template."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BASELINE = REPO_ROOT / "templates" / "TadACampaign_v2_formal_baseline.toml"
DEFAULT_PREPARED_ROOT = REPO_ROOT / "prepared"


def _json_string(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _json_string_array(values: list[str]) -> str:
    return json.dumps(values, ensure_ascii=False)


def _ensure_trailing_newline(text: str) -> str:
    return text if text.endswith("\n") else text + "\n"


def _table_spans(lines: list[str]) -> dict[str, tuple[int, int]]:
    spans: dict[str, tuple[int, int]] = {}
    current: str | None = None
    start = 0
    header_re = re.compile(r"^\s*\[([^\[\]\n]+)\]\s*(?:#.*)?$")
    for index, line in enumerate(lines):
        match = header_re.match(line)
        if match is None:
            continue
        if current is not None:
            spans[current] = (start, index)
        current = match.group(1).strip()
        start = index
    if current is not None:
        spans[current] = (start, len(lines))
    return spans


def _set_root_key(text: str, key: str, raw_value: str) -> str:
    lines = text.splitlines(keepends=True)
    for index, line in enumerate(lines):
        if re.match(r"^\s*\[", line):
            break
        if re.match(rf"^\s*{re.escape(key)}\s*=", line):
            lines[index] = f"{key} = {raw_value}\n"
            return _ensure_trailing_newline("".join(lines))
    insert_at = next((i for i, line in enumerate(lines) if re.match(r"^\s*\[", line)), len(lines))
    lines.insert(insert_at, f"{key} = {raw_value}\n")
    return _ensure_trailing_newline("".join(lines))


def _set_table_key(text: str, table: str, key: str, raw_value: str) -> str:
    lines = text.splitlines(keepends=True)
    spans = _table_spans(lines)
    if table not in spans:
        if lines and not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        if lines and lines[-1].strip():
            lines.append("\n")
        lines.extend([f"[{table}]\n", f"{key} = {raw_value}\n"])
        return _ensure_trailing_newline("".join(lines))

    start, end = spans[table]
    for index in range(start + 1, end):
        if re.match(rf"^\s*{re.escape(key)}\s*=", lines[index]):
            lines[index] = f"{key} = {raw_value}\n"
            return _ensure_trailing_newline("".join(lines))
    lines.insert(end, f"{key} = {raw_value}\n")
    return _ensure_trailing_newline("".join(lines))


def _delete_table_key(text: str, table: str, key: str) -> str:
    lines = text.splitlines(keepends=True)
    spans = _table_spans(lines)
    if table not in spans:
        return _ensure_trailing_newline("".join(lines))
    start, end = spans[table]
    kept = [
        line
        for index, line in enumerate(lines)
        if not (start < index < end and re.match(rf"^\s*{re.escape(key)}\s*=", line))
    ]
    return _ensure_trailing_newline("".join(kept))


def create_setting(args: argparse.Namespace) -> Path:
    baseline_path = args.baseline.expanduser().resolve()
    output_path = args.output.expanduser().resolve()
    prepared_root = getattr(args, "prepared_root", DEFAULT_PREPARED_ROOT)
    run_output_root = getattr(args, "run_output_root", None)
    text = baseline_path.read_text(encoding="utf-8")

    text = _set_root_key(text, "name", _json_string(args.name))
    if getattr(args, "seed", None) is not None:
        text = _set_root_key(text, "seed", str(int(args.seed)))
    text = _set_root_key(text, "prepared_root", _json_string(str(prepared_root.expanduser().resolve())))
    if run_output_root is not None:
        text = _set_root_key(text, "output_root", _json_string(str(run_output_root.expanduser().resolve())))
    text = _set_root_key(text, "initial_cash", str(float(args.initial_cash)))
    text = _set_table_key(text, "agent", "backend", _json_string(args.agent_backend))
    agent_policy = getattr(args, "agent_policy", None)
    if agent_policy is None:
        text = _delete_table_key(text, "agent", "policy")
    else:
        text = _set_table_key(text, "agent", "policy", _json_string(agent_policy))

    for field_name, option_value in [
        ("model", args.agent_model),
        ("reasoning_effort", args.agent_reasoning_effort),
        ("profile", args.agent_profile),
        ("verbosity", args.agent_verbosity),
    ]:
        if option_value is None or option_value == "OMIT":
            text = _delete_table_key(text, "agent", field_name)
        else:
            text = _set_table_key(text, "agent", field_name, _json_string(option_value))

    if args.skill_market_manifest is None:
        text = _delete_table_key(text, "judge", "skill_market_manifest")
        text = _delete_table_key(text, "judge", "skill_market_enabled")
        text = _delete_table_key(text, "judge", "initial_owned_skill_ids")
    else:
        manifest_path = args.skill_market_manifest.expanduser().resolve()
        text = _set_table_key(text, "judge", "skill_market_manifest", _json_string(str(manifest_path)))
        text = _set_table_key(text, "judge", "skill_market_enabled", "true" if args.skill_market_enabled else "false")
        if args.initial_owned_skill_ids:
            text = _set_table_key(
                text,
                "judge",
                "initial_owned_skill_ids",
                _json_string_array(args.initial_owned_skill_ids),
            )
        else:
            text = _delete_table_key(text, "judge", "initial_owned_skill_ids")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(text, encoding="utf-8")
    return output_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, default=DEFAULT_BASELINE)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prepared-root", type=Path, default=DEFAULT_PREPARED_ROOT)
    parser.add_argument("--run-output-root", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument(
        "--seed",
        type=int,
        help="Override the formal environment seed in the generated per-setting TOML. Omit to keep the baseline seed.",
    )
    parser.add_argument("--initial-cash", type=float, required=True)
    parser.add_argument("--agent-backend", default="codex", choices=("codex", "claude", "opencode", "policy"))
    parser.add_argument("--agent-policy")
    parser.add_argument("--agent-model")
    parser.add_argument("--agent-reasoning-effort")
    parser.add_argument("--agent-profile")
    parser.add_argument("--agent-verbosity")
    parser.add_argument("--skill-market-manifest", type=Path)
    parser.add_argument(
        "--skill-market-enabled",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Expose purchase_skill actions for unowned skills in the manifest. Use --no-skill-market-enabled for forced-skill Fig. 5a settings.",
    )
    parser.add_argument(
        "--initial-owned-skill-id",
        dest="initial_owned_skill_ids",
        action="append",
        default=[],
        help="Skill id to materialize into owned_skills at run start; may be passed multiple times.",
    )
    return parser


def main() -> int:
    path = create_setting(build_parser().parse_args())
    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
